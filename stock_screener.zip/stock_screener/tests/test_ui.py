"""User-visible behavior checks without live network access."""
from __future__ import annotations

from pathlib import Path

from streamlit.testing.v1 import AppTest

from ashare.models import ScreenResult, now_shanghai
from ashare.ui.common import PAGES, results_frame

APP = Path(__file__).resolve().parents[1] / "app.py"


def test_results_keep_data_errors_distinct_and_pass_first():
    stamp = now_shanghai()
    data = dict(name="示例", latest_price=10.0, as_of=stamp, strategy_id="test", strategy_version="1", provider="mock")
    results = [ScreenResult(symbol="B", status="DATA_ERROR", reason="missing quote", **data), ScreenResult(symbol="A", status="PASS", **data), ScreenResult(symbol="C", status="FAIL", **data)]
    frame = results_frame(results)
    assert frame["Result"].tolist() == ["PASS", "FAIL", "DATA_ERROR"]
    assert frame.iloc[-1]["Reason"] == "missing quote"
    assert frame.iloc[0]["Quote Timestamp"] == "未知 / 未提供"


def test_six_pages_open_without_unrequested_data_download(monkeypatch, tmp_path):
    from ashare.service import ResearchService

    monkeypatch.setenv("MARKET_DATA_PROVIDER", "mock")
    monkeypatch.setenv("STORAGE_DIR", str(tmp_path))

    def forbidden_download(*args, **kwargs):
        raise AssertionError("Opening a page must not fetch the universe or warm history")

    monkeypatch.setattr(ResearchService, "universe", forbidden_download)
    monkeypatch.setattr(ResearchService, "warm_history", forbidden_download)
    app = AppTest.from_file(str(APP), default_timeout=30).run()
    assert not app.exception
    assert "模拟数据" in app.warning[0].value
    for page in PAGES:
        app.selectbox(key="page_navigation").set_value(page).run()
        assert not app.exception, f"{page}: {app.exception}"


def test_ui_can_load_mock_screen_and_save_new_version(monkeypatch, tmp_path):
    monkeypatch.setenv("MARKET_DATA_PROVIDER", "mock")
    monkeypatch.setenv("STORAGE_DIR", str(tmp_path))
    app = AppTest.from_file(str(APP), default_timeout=45).run()
    next(button for button in app.button if button.label == "加载 / 更新股票池").click().run()
    assert not app.exception
    assert app.session_state["stock_universe"]
    # One explicit watchlist keeps this interaction test focused and deterministic.
    app.radio(key="screen_scope").set_value("自选股票").run()
    symbol = app.session_state["stock_universe"][0].symbol
    app.multiselect(key="watchlist").set_value([symbol]).run()
    next(button for button in app.button if button.label == "准备 / 增量更新历史数据").click().run()
    assert not app.exception
    assert app.session_state["last_warmup"]["success"] == 1
    next(button for button in app.button if button.label == "运行筛选").click().run()
    assert not app.exception
    assert len(app.session_state["screen_results"]) == 1
    app.selectbox(key="page_navigation").set_value("策略构建 · Strategy Builder").run()
    assert not app.exception
    original_count = len(app.session_state["research_service"].strategies.list())
    next(button for button in app.button if button.label == "保存为新版本").click().run()
    assert not app.exception
    assert any("已保存" in message.value for message in app.success)
    assert len(app.session_state["research_service"].strategies.list()) == original_count + 1
    app.selectbox(key="page_navigation").set_value("个股详情 · Stock Detail").run()
    next(button for button in app.button if button.label == "准备该股历史数据并刷新因子").click().run()
    assert not app.exception
    assert len(app.get("plotly_chart")) == 3
    assert len(app.session_state["detail_result"].factors) == 8
    app.selectbox(key="page_navigation").set_value("实时筛选 · Realtime Screener").run()
    next(button for button in app.button if button.label == "▶ 开始定时扫描").click().run()
    assert not app.exception
    assert app.session_state["research_service"].scanner.running
    next(button for button in app.button if button.label == "■ 停止").click().run()
    assert not app.exception
    assert not app.session_state["research_service"].scanner.running


def test_sidebar_edit_recalculates_draft_and_saves_immutable_version(tmp_path):
    from ashare.service import ResearchService
    from ashare.settings import Settings
    from ashare.strategies.schema import Rule, RuleGroup, Strategy
    service = ResearchService(Settings(market_data_provider="mock", storage_dir=tmp_path))
    stocks = service.universe()
    symbol = stocks[0].symbol
    service.warm_history([symbol])
    quote = service.provider.get_realtime_quote(symbol)
    history = service._load_history(symbol)
    prior = history.loc[history.index < __import__("pandas").Timestamp(quote.timestamp.date())].iloc[-1]
    service.provider.quote_overrides[symbol] = quote.model_copy(update={"volume": float(prior.volume) * 2, "amount": float(prior.volume) * 2 * quote.latest_price})
    strategy = Strategy(strategy_id="ui_volume", name="量能条件", version="1.0.0", rules=RuleGroup(rules=[Rule(factor="daily_volume_expansion")]))
    service.strategies.save(strategy)
    app = AppTest.from_file(str(APP), default_timeout=40)
    app.session_state["research_service"] = service
    app.session_state["stock_universe"] = stocks
    app.session_state["screen_scope"] = "自选股票"
    app.session_state["watchlist"] = [symbol]
    app.run()
    next(button for button in app.button if button.label == "运行筛选").click().run()
    assert app.session_state["screen_results"][0].status == "PASS"
    quote_calls = service.provider.quote_calls
    history_calls = service.provider.history_calls
    next(field for field in app.number_input if field.label == "成交量倍数下限").set_value(3.0)
    next(button for button in app.button if button.label == "应用并重算").click().run()
    assert not app.exception
    assert app.session_state["workspace_dirty"]
    changed = app.session_state["screen_results"][0]
    assert changed.status == "FAIL"
    assert changed.factors["daily_volume_expansion"].parameters["minimum_ratio"] == 3.0
    assert service.provider.quote_calls == quote_calls
    assert service.provider.history_calls == history_calls
    assert service.strategies.get("ui_volume", "1.0.0").rules.leaves()[0].params["minimum_ratio"] == 1.5
    # A draft change without recalculation leaves an explicit old-results notice.
    next(field for field in app.number_input if field.label == "成交量倍数下限").set_value(4.0)
    next(button for button in app.button if button.label == "应用修改").click().run()
    assert any("下方仍是上次筛选结果" in item.value for item in app.warning)
    next(button for button in app.button if button.label == "保存当前修改为新版本").click().run()
    assert not app.exception
    assert not app.session_state["workspace_dirty"]
    assert service.strategies.get("ui_volume", "1.0.1").rules.leaves()[0].params["minimum_ratio"] == 4.0
    assert service.strategies.get("ui_volume", "1.0.0").rules.leaves()[0].params["minimum_ratio"] == 1.5


def test_readable_result_counts_use_rules_not_factor_boolean():
    from ashare.models import FactorResult
    from ashare.ui.results import summary_frame, factor_matrix
    timestamp = now_shanghai()
    factor = FactorResult(factor_id="daily_volume_expansion", passed=True, value=2.0, timestamp=timestamp)
    result = ScreenResult(symbol="sh600000", name="测试股票", status="FAIL", as_of=timestamp,
                          strategy_id="example", strategy_version="1", provider="mock",
                          factors={factor.factor_id: factor}, failed_factors=[factor.factor_id],
                          rules={"children":[{"factor":factor.factor_id,"passed":False,"field":"value","actual":2.0,"expected":3.0,"operator":">="}]})
    names = {factor.factor_id:"当日成交量放大"}
    assert summary_frame([result], names).iloc[0]["满足条件"] == "0 / 1"
    assert summary_frame([result], names).iloc[0]["未通过因子 / 异常"] == "当日成交量放大"
    assert factor_matrix([result], names).iloc[0]["当日成交量放大"] == "×"


def test_draft_parameter_validation_preserves_nested_group_and_source():
    import pytest
    from ashare.factors.registry import default_registry
    from ashare.strategies.schema import Rule, RuleGroup, Strategy
    from ashare.ui.workspace import replace_rule
    original = Strategy(strategy_id="nested", name="Nested", version="1", rules=RuleGroup(logic="OR", rules=[RuleGroup(rules=[Rule(factor="daily_volume_expansion")])]))
    changed = replace_rule(original, (0, 0), Rule(factor="daily_volume_expansion", params={"minimum_ratio":2}), default_registry())
    assert changed.rules.logic == "OR"
    assert changed.rules.rules[0].rules[0].params["minimum_ratio"] == 2
    assert original.rules.rules[0].rules[0].params == {}
    with pytest.raises(ValueError):
        replace_rule(original, (0, 0), Rule(factor="daily_volume_expansion", params={"minimum_ratio":-1}), default_registry())
