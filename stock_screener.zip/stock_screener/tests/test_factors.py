from dataclasses import replace

import numpy as np
import pandas as pd
import pytest

from ashare.factors import BaseFactor, FactorParameters, FactorRegistry, default_registry
from ashare.factors.technical.swing import causal_zigzag
from ashare.models import FactorContext, FactorMetadata, SHANGHAI


def make_bars(close, freq="B", volume=None, partial=True):
    index = pd.date_range(end="2025-12-30", periods=len(close), freq=freq)
    values = np.asarray(close, dtype=float)
    frame = pd.DataFrame({"open": values, "close": values, "high": values + 1,
                          "low": values - 0.1, "volume": 1000.0 if volume is None else volume,
                          "amount": values * 1000, "is_partial": False}, index=index)
    frame["available_at"] = index.tz_localize(SHANGHAI) + pd.Timedelta(hours=15)
    if partial and len(frame):
        frame.loc[index[-1], "is_partial"] = True
    return frame


def context(daily=None, weekly=None, monthly=None):
    return FactorContext(
        symbol="000001.SZ", as_of=pd.Timestamp("2025-12-30 15:00", tz=SHANGHAI),
        daily_bars=make_bars(np.linspace(10, 60, 80)) if daily is None else daily,
        weekly_bars=make_bars(np.linspace(10, 40, 30), "W-FRI") if weekly is None else weekly,
        monthly_bars=make_bars(np.linspace(10, 50, 25), "ME") if monthly is None else monthly,
    )


@pytest.fixture
def registry():
    return default_registry()


def test_all_eight_registered_and_versioned(registry):
    assert {m.factor_id for m in registry.list()} == {
        "monthly_ma_bullish_alignment", "price_above_monthly_ma5_ma10", "swing_gain_below_100pct",
        "weekly_ma10_rising", "weekly_pullback", "daily_ma5_cross_ma10", "daily_macd_above_zero",
        "daily_volume_expansion",
    }
    for metadata in registry.list():
        assert registry.get(metadata.factor_id, metadata.version).metadata == metadata


def test_monthly_alignment_and_partial_month(registry):
    ctx = context()
    factor = registry.get("monthly_ma_bullish_alignment")
    result = factor.calculate(ctx)
    assert result.passed is True
    assert result.details["monthly_ma5"] == pytest.approx(ctx.monthly_bars.close.tail(5).mean())
    assert result.details["current_bar_partial"] is True
    changed = ctx.monthly_bars.copy()
    changed.iloc[-1, changed.columns.get_loc("close")] = 1
    assert factor.calculate(replace(ctx, monthly_bars=changed)).passed is False


def test_price_above_monthly_averages(registry):
    result = registry.get("price_above_monthly_ma5_ma10").calculate(context())
    assert result.passed is True
    assert result.details["latest_price"] == 60
    assert result.details["distance_to_ma5_pct"] > 0
    ctx = context(daily=make_bars([1]))
    assert registry.get("price_above_monthly_ma5_ma10").calculate(ctx).passed is False


def test_weekly_average_rising_and_lookback(registry):
    factor = registry.get("weekly_ma10_rising")
    ctx = context()
    result = factor.calculate(ctx, {"slope_lookback_weeks": 3})
    expected = ctx.weekly_bars.close.iloc[-10:].mean() - ctx.weekly_bars.close.iloc[-13:-3].mean()
    assert result.passed is True
    assert result.details["slope"] == pytest.approx(expected)
    falling = make_bars(np.linspace(30, 10, 20), "W-FRI")
    assert factor.calculate(context(weekly=falling)).passed is False


def test_weekly_pullback_positive_magnitude_and_rising_ma(registry):
    weeks = make_bars(np.arange(10, 22), "W-FRI")
    weeks["high"] = weeks.close + 5
    ctx = context(daily=make_bars([21]), weekly=weeks)
    result = registry.get("weekly_pullback").calculate(ctx)
    assert result.passed is True
    assert result.details["drawdown"] == pytest.approx(1 - 21 / 26)
    assert result.details["signed_return_from_high"] == pytest.approx(21 / 26 - 1)
    assert result.details["weekly_ma10_slope"] > 0
    falling = weeks.copy()
    falling["close"] = falling.close.to_numpy()[::-1]
    assert registry.get("weekly_pullback").calculate(replace(ctx, weekly_bars=falling)).passed is False


def test_cross_requires_today_not_prolonged_bullish(registry):
    factor = registry.get("daily_ma5_cross_ma10")
    ctx = context(daily=make_bars([10] * 10 + [20]))
    result = factor.calculate(ctx)
    assert result.passed is True
    assert result.details["ma5_previous"] == result.details["ma10_previous"] == 10
    assert factor.calculate(context(daily=make_bars(np.arange(1, 31)))).passed is False
    # A subsequent tick can retract a current partial-bar cross.
    assert factor.calculate(context(daily=make_bars([10] * 10 + [9]))).passed is False


def test_macd_convention_and_incremental_current_bar(registry):
    factor = registry.get("daily_macd_above_zero")
    ctx = context()
    first = factor.calculate(ctx)
    assert first.passed is True
    fast = ctx.daily_bars.close.ewm(span=12, adjust=False).mean()
    slow = ctx.daily_bars.close.ewm(span=26, adjust=False).mean()
    expected_dif = fast - slow
    expected_dea = expected_dif.ewm(span=9, adjust=False).mean()
    assert first.details["dif"] == pytest.approx(expected_dif.iloc[-1])
    assert first.details["dea"] == pytest.approx(expected_dea.iloc[-1])
    assert first.details["histogram"] == pytest.approx(2 * (expected_dif.iloc[-1] - expected_dea.iloc[-1]))
    changed = ctx.daily_bars.copy()
    changed.iloc[-1, changed.columns.get_loc("close")] = 30
    second = factor.calculate(replace(ctx, daily_bars=changed))
    assert second.details["completed_prefix_cache_hit"] is True
    assert second.details["dif"] != first.details["dif"]
    assert first.parameters == {"fast_period": 12, "slow_period": 26, "signal_period": 9}


def test_volume_is_cumulative_vs_full_previous_day(registry):
    factor = registry.get("daily_volume_expansion")
    ctx = context(daily=make_bars([10, 11], volume=[1000, 1700]))
    result = factor.calculate(ctx)
    assert result.value == pytest.approx(1.7)
    assert result.passed is True
    assert result.details["today_volume"] == 1700
    low = context(daily=make_bars([10, 11], volume=[1000, 300]))
    result = factor.calculate(low)
    assert result.value == pytest.approx(0.3)
    assert result.passed is False
    zero = context(daily=make_bars([10, 11], volume=[0, 300]))
    assert factor.calculate(zero).status == "DATA_ERROR"


def test_swing_confirmed_and_tentative_endpoints(registry):
    factor = registry.get("swing_gain_below_100pct")
    weeks = make_bars([100, 112, 130, 117], "W-FRI", partial=False)
    result = factor.calculate(context(weekly=weeks))
    assert result.value == pytest.approx(1.3)
    assert result.passed is True
    assert result.details["swing_low"] == 100
    assert result.details["swing_high"] == 130
    assert result.details["swing_high_state"] == "confirmed"
    assert pd.Timestamp(result.details["high_confirmed_at"]) > pd.Timestamp(result.details["swing_high_date"], tz=SHANGHAI)
    rising = factor.calculate(context(weekly=make_bars([100, 112, 150], "W-FRI")))
    assert rising.details["swing_high_state"] == "tentative"
    assert rising.details["high_confirmed_at"] is None
    assert factor.calculate(context(weekly=make_bars([100, 112, 210], "W-FRI"))).passed is False


def test_partial_week_confirmation_explicit(registry):
    result = registry.get("swing_gain_below_100pct").calculate(
        context(weekly=make_bars([100, 112, 130, 117], "W-FRI", partial=True)))
    assert result.details["swing_high_state"] == "provisionally_confirmed"
    assert result.details["swing_high_pivot"]["confirmation_is_partial"] is True


def test_zigzag_exact_ten_percent_boundary(registry):
    result = registry.get("swing_gain_below_100pct").calculate(
        context(weekly=make_bars([100, 110], "W-FRI", partial=False)))
    assert result.status == "PASS"
    assert result.value == pytest.approx(1.1)


def test_zigzag_prefix_invariance_confirmation_not_backdated():
    bars = make_bars([100, 112, 125, 110, 98, 112, 134, 116, 100, 120, 145], "W-FRI", partial=False)
    full = causal_zigzag(bars)
    for stop in range(1, len(bars) + 1):
        prefix = causal_zigzag(bars.iloc[:stop])
        cutoff = bars.available_at.iloc[stop - 1]
        visible_full_pivots = [p for p in full.confirmed_pivots if pd.Timestamp(p["confirmed_at"]) <= cutoff]
        assert prefix.confirmed_pivots == visible_full_pivots
        for pivot in prefix.confirmed_pivots:
            assert pd.Timestamp(pivot["confirmed_at"]) <= cutoff
            assert pd.Timestamp(pivot["observed_at"]) <= pd.Timestamp(pivot["confirmed_at"])


@pytest.mark.parametrize("factor_id", [m.factor_id for m in default_registry().list()])
def test_every_factor_insufficient_data_and_unknown_params(registry, factor_id):
    empty = make_bars([])
    ctx = context(daily=empty, weekly=empty, monthly=empty)
    factor = registry.get(factor_id)
    result = factor.calculate(ctx)
    assert result.status == "NOT_ENOUGH_DATA"
    assert result.passed is None
    invalid = factor.calculate(context(), {"this_parameter_does_not_exist": 42})
    assert invalid.status == "DATA_ERROR"
    assert invalid.passed is None


def test_no_confirmed_swing_is_insufficient(registry):
    result = registry.get("swing_gain_below_100pct").calculate(context(weekly=make_bars([100, 101, 102], "W-FRI")))
    assert result.status == "NOT_ENOUGH_DATA"


def test_future_and_nonfinite_data_rejected(registry):
    ctx = context()
    bars = ctx.daily_bars.copy()
    bars.loc[bars.index[-1], "available_at"] = ctx.as_of + pd.Timedelta(seconds=1)
    assert registry.get("daily_macd_above_zero").calculate(replace(ctx, daily_bars=bars)).status == "DATA_ERROR"
    bars = ctx.daily_bars.copy()
    bars.loc[bars.index[-1], "close"] = np.nan
    assert registry.get("daily_macd_above_zero").calculate(replace(ctx, daily_bars=bars)).status == "DATA_ERROR"


def test_result_explanation_is_json_serializable(registry):
    result = registry.get("daily_macd_above_zero").calculate(context())
    assert result.model_dump_json()
    assert result.data_timestamp is not None
    assert result.version == "1.0.0"
    assert result.adjustment == "raw"
    assert result.details["raw_inputs"][-1]["is_partial"] is True
    assert result.details["parameter_snapshot"] == result.parameters


def test_plugin_registration_requires_no_screener_change():
    registry = default_registry("examples.custom_factor")
    assert len(registry.list()) == 9
    result = registry.get("daily_return_below_limit").calculate(context(), {"maximum_return": 1})
    assert result.status == "PASS"
    assert type(result.value) is float
    with pytest.raises(ValueError, match="already registered"):
        registry.register(type(registry.get("daily_return_below_limit")))


def test_categorical_plugin_and_semantic_version_resolution():
    class Category(BaseFactor):
        metadata = FactorMetadata(factor_id="regime", name="Regime", description="Test extension",
                                  category="custom", timeframe="daily", output_type="categorical", version="1.9.0")

        def _calculate(self, context, params):
            return True, "uptrend", {"example": True}, "Example categorical output"

    class CategoryV2(Category):
        metadata = Category.metadata.model_copy(update={"version": "1.10.0"})

    registry = FactorRegistry()
    registry.register(Category)
    registry.register(CategoryV2)
    assert registry.get("regime").metadata.version == "1.10.0"
    assert registry.get("regime", "1.9.0").calculate(context()).value == "uptrend"
