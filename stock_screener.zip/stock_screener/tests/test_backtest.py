import pandas as pd
import pytest

from ashare.backtest.metrics import forward_returns, summarize
from ashare.backtest.point_in_time import known_observations
from ashare.data.calendar import ExchangeCalendar


def test_forward_labels_use_exchange_sessions_and_do_not_fill_suspension():
    cal=ExchangeCalendar()
    dates=cal.sessions("2025-06-02","2025-07-01")
    bars=pd.DataFrame({"close":range(10,10+len(dates))},index=dates)
    outcome=forward_returns(bars,dates[0],(5,),cal)["5"]
    assert outcome["return"]==pytest.approx(.5)
    assert outcome["maximum_drawdown"]==0
    assert forward_returns(bars.drop(dates[5]),dates[0],(5,),cal)["5"]["return"] is None


def test_financial_revision_after_cutoff_unavailable():
    frame=pd.DataFrame({"value":[1,2,3],"available_at":["2025-04-01T18:00:00+08:00","2025-07-01T18:00:00+08:00","2025-09-01T18:00:00+08:00"]})
    assert list(known_observations(frame,"2025-06-30").value)==[1]
    with pytest.raises(ValueError):
        known_observations(pd.DataFrame({"value":[1]}),"2025-06-30")


def test_summary_ignores_missing_outcomes():
    assert summarize([.2,-.1,None])["win_rate"]==.5
    assert summarize([None])["count"]==0
