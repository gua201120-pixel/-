from datetime import timedelta

import pandas as pd
import pytest

from ashare.models import Quote, Stock, as_timestamp
from ashare.service import ResearchService
from ashare.settings import Settings
from ashare.strategies.schema import Rule, RuleGroup, Strategy


@pytest.fixture
def service(tmp_path, monkeypatch):
    stamp=as_timestamp("2025-06-30 13:30")
    monkeypatch.setattr("ashare.service.now_shanghai",lambda:stamp.to_pydatetime())
    monkeypatch.setattr("ashare.screening.realtime_screener.now_shanghai",lambda:stamp.to_pydatetime())
    engine=ResearchService(Settings(market_data_provider="mock",storage_dir=tmp_path,history_start="2022-01-01"))
    engine.provider.as_of=stamp
    engine.universe()
    engine.warm_history(["sh600000"])
    return engine


def volume_strategy():
    return Strategy(strategy_id="volume",name="volume",version="1",rules=RuleGroup(rules=[Rule(factor="daily_volume_expansion")]))


def make_quote(service, ratio, stamp="2025-06-30 13:30"):
    previous=service._load_history("sh600000").iloc[-1]
    price=float(previous.close)
    timestamp=as_timestamp(stamp).to_pydatetime()
    return Quote(symbol="sh600000",name="模拟",timestamp=timestamp,received_at=timestamp,provider_timestamp=timestamp,
                 latest_price=price,open=price,high=price,low=price,previous_close=price,
                 volume=float(previous.volume)*ratio,amount=float(previous.volume)*ratio*price,quality="simulated")


def test_batch_realtime_updates_volume_without_history_download(service):
    provider=service.provider
    strategy=volume_strategy()
    before=provider.history_calls
    provider.quote_overrides["sh600000"]=make_quote(service,1)
    first=service.screen(strategy,symbols=["sh600000"],persist=False)[0]
    assert first.status=="FAIL"
    assert first.factors["daily_volume_expansion"].value==pytest.approx(1)
    provider.quote_overrides["sh600000"]=make_quote(service,2)
    second=service.screen(strategy,symbols=["sh600000"],persist=False)[0]
    assert second.status=="PASS"
    assert second.factors["daily_volume_expansion"].value==pytest.approx(2)
    assert provider.history_calls==before
    assert provider.quote_calls==2
    service.screen(strategy,symbols=["sh600000"],persist=False)
    assert service.last_scan_stats["reused"]==1


def test_numeric_rule_failures_use_rule_threshold_not_factor_default(service):
    service.provider.quote_overrides["sh600000"]=make_quote(service,2)
    strategy=volume_strategy()
    strategy.rules.rules=[Rule(factor="daily_volume_expansion",field="value",operator=">",value=3)]
    result=service.screen(strategy,["sh600000"],persist=False)[0]
    assert result.factors["daily_volume_expansion"].passed is True
    assert result.status=="FAIL"
    assert result.failed_factors==["daily_volume_expansion"]


def test_historical_has_no_quote_calls_or_future_bars(service):
    original=service.provider.quote_calls
    result=service.screen(volume_strategy(),["sh600000"],as_of="2025-06-26",persist=False)[0]
    assert result.status in {"PASS","FAIL"}
    assert service.provider.quote_calls==original
    assert result.quote_timestamp is None
    assert service.context("sh600000","2025-06-26").daily_bars.index.max()==pd.Timestamp("2025-06-26")
    with pytest.raises(ValueError,match="explicit symbols"):
        service.screen(volume_strategy(),as_of="2025-06-26",persist=False)
    intraday=service.screen(volume_strategy(),["sh600000"],as_of="2025-06-26 10:30",persist=False)[0]
    assert intraday.status=="DATA_ERROR"


def test_isolates_missing_history_and_invalid_quotes(service):
    service.provider.quote_overrides["sh600000"]=make_quote(service,2).model_copy(update={"latest_price":None})
    results=service.screen(volume_strategy(),["sh600000","sz000001"],persist=False)
    assert {r.symbol:r.status for r in results}=={"sh600000":"DATA_ERROR","sz000001":"NOT_ENOUGH_DATA"}


def test_stale_cannot_enter_pass_list(service):
    service.provider.quote_overrides["sh600000"]=make_quote(service,2,"2025-06-30 13:00")
    result=service.screen(volume_strategy(),["sh600000"],persist=False)[0]
    assert result.status=="STALE"
    assert result.factors["daily_volume_expansion"].passed is True


def test_missing_batch_response_does_not_present_old_cache_as_fresh(service, monkeypatch):
    service.provider.quote_overrides["sh600000"]=make_quote(service,2)
    service.screen(volume_strategy(),["sh600000"],persist=False)
    monkeypatch.setattr(service.provider,"get_realtime_quotes",lambda symbols:{})
    assert service.screen(volume_strategy(),["sh600000"],persist=False)[0].status=="DATA_ERROR"


def test_closed_scanner_does_not_poll_and_stop_works(service, monkeypatch):
    service.provider.quality="unknown"
    monkeypatch.setattr("ashare.screening.realtime_screener.now_shanghai",lambda:as_timestamp("2025-06-29 13:30").to_pydatetime())
    service.scanner.start()
    assert service.scanner.tick(volume_strategy(),["sh600000"]) is None
    assert service.provider.quote_calls==0
    assert service.scanner.state=="WAITING_NON_TRADING_DAY"
    service.scanner.stop()
    assert service.scanner.tick(volume_strategy(),["sh600000"]) is None


def test_default_strategy_all_conditions_fail_one(service, monkeypatch):
    from ashare.models import FactorResult
    service.provider.quote_overrides["sh600000"]=make_quote(service,2)
    strategy=service.strategies.get("multi_timeframe_trend_setup_v1")
    for rule in strategy.rules.leaves():
        factor=service.factors.get(rule.factor)
        def calculate(context,params=None,factor=factor):
            return FactorResult(factor_id=factor.metadata.factor_id,passed=True,value=True,timestamp=context.as_of.to_pydatetime())
        monkeypatch.setattr(factor,"calculate",calculate)
    assert service.screen(strategy,["sh600000"],persist=False)[0].status=="PASS"
    factor=service.factors.get("weekly_pullback")
    monkeypatch.setattr(factor,"calculate",lambda ctx,params=None:FactorResult(factor_id="weekly_pullback",passed=False,value=False,status="FAIL",timestamp=ctx.as_of.to_pydatetime()))
    service._result_cache.clear()
    assert service.screen(strategy,["sh600000"],persist=False)[0].status=="FAIL"


@pytest.mark.parametrize("now,quote_time", [("2025-06-30 15:01","2025-06-30 09:35"), ("2025-06-30 12:00","2025-06-30 09:35")])
def test_morning_quote_is_stale_at_lunch_and_close(service, monkeypatch, now, quote_time):
    monkeypatch.setattr("ashare.service.now_shanghai",lambda:as_timestamp(now).to_pydatetime())
    service.provider.quote_overrides["sh600000"]=make_quote(service,2,quote_time)
    assert service.screen(volume_strategy(),["sh600000"],persist=False)[0].status=="STALE"


def test_weekend_quote_builds_last_session_and_preserves_timestamps(service, monkeypatch):
    monkeypatch.setattr("ashare.service.now_shanghai",lambda:as_timestamp("2025-06-29 12:00").to_pydatetime())
    history=service._load_history("sh600000").loc[:"2025-06-26"].copy()
    service._history["sh600000"]=history
    service.provider.quote_overrides["sh600000"]=make_quote(service,2,"2025-06-27 15:00")
    result=service.screen(volume_strategy(),["sh600000"],persist=False)[0]
    assert result.status=="PASS"
    assert result.quote_timestamp==as_timestamp("2025-06-27")
    assert result.factors["daily_volume_expansion"].data_timestamp==as_timestamp("2025-06-27")


def test_financial_factor_can_be_added_by_registration_only(service, monkeypatch):
    from ashare.factors.base import BaseFactor, FactorParameters, NotEnoughData
    from ashare.models import FactorMetadata
    class FinancialFactor(BaseFactor):
        metadata=FactorMetadata(factor_id="example_financial",name="Example financial",description="PIT dataset requirement",category="fundamental",timeframe="event",output_type="numeric",required_datasets=["financial"])
        def _calculate(self,context,params):
            if context.financial_data.empty:
                raise NotEnoughData("No published observation")
            value=float(context.financial_data.iloc[-1].value)
            return value>0,value,{"published_rows":len(context.financial_data)},"Latest known observation"
    service.factors.register(FinancialFactor)
    monkeypatch.setattr(service.provider,"get_dataset",lambda name,symbol:pd.DataFrame({"value":[1,-99],"available_at":["2025-06-20T18:00:00+08:00","2025-07-01T18:00:00+08:00"]}))
    strategy=Strategy(strategy_id="financial",name="Financial",version="1",rules=RuleGroup(rules=[Rule(factor="example_financial")]))
    result=service.screen(strategy,["sh600000"],as_of="2025-06-26",persist=False)[0]
    assert result.status=="PASS"
    assert result.factors["example_financial"].value==1
    assert result.factors["example_financial"].details["published_rows"]==1


def test_transition_is_retried_if_database_write_failed(service, monkeypatch):
    service.provider.quote_overrides["sh600000"]=make_quote(service,2)
    real_save=service.research.save_run
    count=[0]
    def flaky(*args):
        count[0]+=1
        if count[0]==1:
            raise OSError("temporary database failure")
        return real_save(*args)
    monkeypatch.setattr(service.research,"save_run",flaky)
    strategy=volume_strategy()
    with pytest.raises(OSError):
        service.scanner.tick(strategy,["sh600000"],force=True)
    service.scanner.tick(strategy,["sh600000"],force=True)
    assert count[0]==2


def test_new_clock_dependent_factor_is_not_cached_by_quote(service, monkeypatch):
    from ashare.factors.base import BaseFactor
    from ashare.models import FactorMetadata
    class ClockFactor(BaseFactor):
        metadata=FactorMetadata(factor_id="elapsed",name="Elapsed",description="Time-sensitive future factor",category="custom",timeframe="event",output_type="numeric")
        def _calculate(self,context,params):
            return True,float(context.as_of.second),{},"Exchange clock second"
    service.factors.register(ClockFactor)
    service.provider.quote_overrides["sh600000"]=make_quote(service,2)
    strategy=Strategy(strategy_id="clock",name="Clock",version="1",rules=RuleGroup(rules=[Rule(factor="elapsed")]))
    first=service.screen(strategy,["sh600000"],persist=False)[0]
    monkeypatch.setattr("ashare.service.now_shanghai",lambda:as_timestamp("2025-06-30 13:30:05").to_pydatetime())
    second=service.screen(strategy,["sh600000"],persist=False)[0]
    assert first.factors["elapsed"].value==0
    assert second.factors["elapsed"].value==5


def test_future_receipt_cannot_enter_historical_context(service):
    quote=make_quote(service,2).model_copy(update={"received_at":as_timestamp("2025-06-30 13:31").to_pydatetime()})
    with pytest.raises(ValueError,match="received/published"):
        service.builder.build("sh600000",service._load_history("sh600000"),"2025-06-30 13:30",quote)
