from datetime import date, datetime, timedelta

import httpx
import numpy as np
import pandas as pd
import pytest

from ashare.models import Quote, SHANGHAI, as_timestamp
from ashare.data import BarStore, ContextBuilder, DataError, ExchangeCalendar, QuoteCache, UnsupportedAdjustmentError
from ashare.data.calendar import CalendarCoverageError
from ashare.data.development_provider import DevelopmentProvider, parse_tencent_quotes, tencent_volume_multiplier
from ashare.data.mock_provider import MockProvider
from ashare.data.resample import normalize_bars, resample_bars


@pytest.fixture
def calendar():
    return ExchangeCalendar()


def bars(dates, closes=None):
    closes = np.array(closes if closes is not None else range(10, 10 + len(dates)), dtype=float)
    return normalize_bars(pd.DataFrame({"open": closes - 0.1, "high": closes + 1,
                                        "low": closes - 1, "close": closes,
                                        "volume": 100., "amount": closes * 100},
                                       index=pd.DatetimeIndex(dates)))


def quote(stamp="2025-06-30 13:30", volume=250., price=14., **changes):
    values = dict(symbol="sh600000", timestamp=as_timestamp(stamp).to_pydatetime(),
                  provider_timestamp=as_timestamp(stamp).to_pydatetime(), received_at=as_timestamp(stamp).to_pydatetime(),
                  open=13., high=max(price, 15), low=min(price, 12), latest_price=price, volume=volume,
                  amount=price * volume if volume is not None else None, quality="simulated")
    values.update(changes)
    return Quote(**values)


def test_calendar_holiday_lunch_weekend_and_unknown(calendar):
    assert not calendar.is_session(date(2026, 2, 23))
    assert calendar.is_session(date(2026, 2, 24))
    assert not calendar.is_session(date(2026, 2, 28))  # civil make-up workday remains closed
    assert calendar.previous_session(date(2026, 2, 24)) == date(2026, 2, 13)
    assert calendar.market_status("2026-09-11 10:30") == "OPEN"
    assert calendar.market_status("2026-09-11 12:00") == "LUNCH_BREAK"
    assert calendar.market_status("2026-09-11 15:00") == "CLOSED"
    assert calendar.market_status("2026-09-12 10:30") == "NON_TRADING_DAY"
    assert calendar.market_status("2027-01-04 10:30") == "UNKNOWN"
    with pytest.raises(CalendarCoverageError):
        calendar.is_session(date(2027, 1, 4))


def test_weekly_aggregation_holiday_and_suspension(calendar):
    # National holiday finishes on Wednesday; there are only Thursday/Friday
    # sessions in this week. A suspended Friday must not generate another bar.
    daily = bars(["2025-10-09"])
    before = resample_bars(daily, "weekly", "2025-10-09", calendar)
    after = resample_bars(daily, "weekly", "2025-10-10", calendar)
    assert before.is_partial.iloc[-1]
    assert not after.is_partial.iloc[-1]
    assert after.volume.iloc[-1] == 100
    assert after.session_count.iloc[-1] == 1
    assert after.index[-1] == pd.Timestamp("2025-10-09")
    assert after.period_end.iloc[-1] == pd.Timestamp("2025-10-10")


def test_monthly_partial_and_final(calendar):
    daily = bars(["2025-06-02", "2025-06-27", "2025-06-30"], [10, 12, 11])
    result = resample_bars(daily, "monthly", "2025-06-30", calendar)
    assert len(result) == 1
    row = result.iloc[0]
    assert row.open == 9.9 and row.close == 11 and row.high == 13 and row.low == 9
    assert row.volume == 300
    assert not row.is_partial
    assert resample_bars(daily.iloc[:-1], "monthly", "2025-06-27", calendar).is_partial.iloc[0]


def test_context_replaces_current_daily_cumulative_quote(calendar):
    history = bars(["2025-06-26", "2025-06-27", "2025-06-30", "2025-07-01"], [10, 11, 99, 100])
    builder = ContextBuilder(calendar)
    first = builder.build("sh600000", history, "2025-06-30 13:30", quote())
    second = builder.build("sh600000", history, "2025-06-30 13:31", quote("2025-06-30 13:31", volume=300, price=16))
    assert list(first.daily_bars.close) == [10, 11, 14]
    assert second.daily_bars.volume.iloc[-1] == 300  # replacement, not 250 + 300
    assert second.daily_bars.close.iloc[-1] == 16
    assert second.weekly_bars.close.iloc[-1] == 16
    assert second.monthly_bars.volume.iloc[-1] == 500
    assert second.weekly_bars.is_partial.iloc[-1]
    assert second.monthly_bars.is_partial.iloc[-1]
    assert builder.cache_hits >= 2
    assert all(first.daily_bars.available_at <= first.as_of)


def test_historical_prefix_and_future_quote_are_safe(calendar):
    history = bars(["2025-06-26", "2025-06-27", "2025-06-30", "2025-07-01"])
    builder = ContextBuilder(calendar)
    earlier = builder.build("sh600000", history, "2025-06-27")
    prefix = builder.build("sh600000", history.iloc[:2], "2025-06-27")
    pd.testing.assert_frame_equal(earlier.daily_bars, prefix.daily_bars)
    pd.testing.assert_frame_equal(earlier.monthly_bars, prefix.monthly_bars)
    with pytest.raises(DataError, match="after requested"):
        builder.build("sh600000", history, "2025-06-30 10:00", quote())
    with pytest.raises(DataError, match="recorded same-session"):
        builder.build("sh600000", history, "2025-06-30 10:00")
    with pytest.raises(DataError, match="exchange timestamp"):
        builder.build("sh600000", history, "2025-06-30 13:30", quote(timestamp=None))


def test_unavailable_bars_and_fundamentals_do_not_leak(calendar):
    history = bars(["2025-06-26", "2025-06-27"])
    history.loc[pd.Timestamp("2025-06-27"), "available_at"] = as_timestamp("2025-07-01")
    financial = pd.DataFrame({"metric": ["profit", "profit"], "value": [100, 200],
                              "available_at": ["2025-06-01 08:00", "2025-07-01 08:00"]})
    context = ContextBuilder(calendar).build("sh600000", history, "2025-06-30", metadata={"financial_data": financial})
    assert len(context.daily_bars) == 1
    assert list(context.financial_data.value) == [100]
    with pytest.raises(DataError, match="available_at"):
        ContextBuilder(calendar).build("sh600000", history, "2025-06-30", metadata={"financial_data": financial.drop(columns="available_at")})


def test_reverse_asof_delayed_availability_does_not_poison_period_cache(calendar):
    history = bars(["2025-06-20", "2025-06-23", "2025-06-26", "2025-06-27"], [10, 100, 11, 12])
    history.loc[pd.Timestamp("2025-06-23"), "available_at"] = as_timestamp("2025-06-27 12:00")
    builder = ContextBuilder(calendar)
    builder.build("sh600000", history, "2025-06-27")
    earlier = builder.build("sh600000", history, "2025-06-26")
    direct = ContextBuilder(calendar).build("sh600000", history, "2025-06-26")
    assert earlier.monthly_bars.high.iloc[-1] == 12
    pd.testing.assert_frame_equal(earlier.weekly_bars, direct.weekly_bars)
    pd.testing.assert_frame_equal(earlier.monthly_bars, direct.monthly_bars)


def test_financial_missing_available_at_is_error(calendar):
    with pytest.raises(DataError, match="missing available_at"):
        ContextBuilder(calendar).build("sh600000", bars(["2025-06-27"]), "2025-06-30",
            metadata={"financial_data": pd.DataFrame({"metric": ["profit"], "available_at": [pd.NaT]})})


def test_suspension_does_not_fabricate_bar(calendar):
    history = bars(["2025-06-26", "2025-06-27"])
    context = ContextBuilder(calendar).build("sh600000", history, "2025-06-30 13:30", quote(suspended=True))
    assert len(context.daily_bars) == 2
    assert context.metadata["suspended"]


@pytest.mark.parametrize("as_of", ["2025-06-28 10:30", "2025-06-30 09:00"])
def test_weekend_and_preopen_use_latest_completed_session_quote(calendar, as_of):
    history = bars(["2025-06-25", "2025-06-26"], [10, 11])
    snapshot = quote("2025-06-27 15:00", price=14, volume=500)
    context = ContextBuilder(calendar).build("sh600000", history, as_of, snapshot)
    assert context.daily_bars.index[-1] == pd.Timestamp("2025-06-27")
    assert context.daily_bars.close.iloc[-1] == 14
    assert context.weekly_bars.close.iloc[-1] == 14
    assert context.daily_bars.volume.iloc[-1] == 500
    assert not context.daily_bars.is_partial.iloc[-1]
    assert context.realtime_quote == snapshot
    with pytest.raises(DataError, match="expected latest"):
        ContextBuilder(calendar).build("sh600000", history, as_of, quote("2025-06-26 15:00"))


@pytest.mark.parametrize("patch", [{"latest_price": None}, {"volume": None}, {"latest_price": -1}, {"high": 2}])
def test_invalid_quote_is_controlled(calendar, patch):
    with pytest.raises(DataError):
        ContextBuilder(calendar).build("sh600000", bars(["2025-06-27"]), "2025-06-30 13:30", quote(**patch))


def test_adjusted_raw_splice_is_forbidden(calendar):
    with pytest.raises(UnsupportedAdjustmentError):
        ContextBuilder(calendar).build("sh600000", bars(["2025-06-27"]), "2025-06-30", adjustment="qfq")
    with pytest.raises(UnsupportedAdjustmentError):
        MockProvider().get_daily_bars("sh600000", adjustment="hfq")


def test_quote_cache_rejects_time_and_volume_regression():
    cache = QuoteCache()
    assert cache.update(quote())
    assert not cache.update(quote("2025-06-30 13:29"))
    assert not cache.update(quote("2025-06-30 13:31", volume=100))
    assert not cache.update(quote(timestamp=None))
    assert cache.update(quote("2025-06-30 13:31", volume=300))
    assert cache.get("sh600000").volume == 300
    assert cache.update(quote("2025-07-01 09:35", volume=10))
    returned = cache.get("sh600000")
    returned.volume = 999
    assert cache.get("sh600000").volume == 10


def test_incremental_parquet_store(tmp_path):
    provider = MockProvider(as_of="2025-06-30 15:00")
    store = BarStore(tmp_path, provider.name)
    first = store.sync(provider, "sh600000", "2025-06-20", "2025-06-27")
    assert provider.history_calls == 1
    same = store.sync(provider, "sh600000", "2025-06-20", "2025-06-27")
    assert provider.history_calls == 1
    pd.testing.assert_frame_equal(first, same)
    final = store.sync(provider, "sh600000", "2025-06-20", "2025-06-30")
    assert provider.history_calls == 2
    assert final.index.is_unique and len(final) == len(first) + 1
    reloaded = BarStore(tmp_path, provider.name).load("sh600000")
    pd.testing.assert_frame_equal(final, reloaded)
    assert reloaded.attrs["historical_revision"]


def test_store_disjoint_sync_does_not_claim_undownloaded_gap(tmp_path):
    provider = MockProvider(as_of="2025-06-30 15:00")
    store = BarStore(tmp_path, provider.name)
    store.sync(provider, "sh600000", "2025-06-02", "2025-06-06")
    combined = store.sync(provider, "sh600000", "2025-06-23", "2025-06-27")
    assert pd.Timestamp("2025-06-16") in combined.index
    calls = provider.history_calls
    middle = store.sync(provider, "sh600000", "2025-06-09", "2025-06-20")
    assert provider.history_calls == calls
    assert pd.Timestamp("2025-06-16") in middle.index


def test_mock_history_deterministic_across_fetch_ranges():
    provider = MockProvider(as_of="2025-06-30 13:30")
    full = provider.get_daily_bars("sh600000", "2024-01-01", "2025-06-30")
    part = provider.get_daily_bars("sh600000", "2025-06-01", "2025-06-30")
    pd.testing.assert_frame_equal(full.loc[part.index], part)
    quotes = provider.get_realtime_quotes(["sh600000", "bj920001"])
    assert provider.quote_calls == 1 and len(quotes) == 2
    assert all(quote.quality == "simulated" for quote in quotes.values())


def tencent_payload(symbol="sh600000", timestamp="20250630133000"):
    values = [""] * 60
    for index, value in {1: "浦发银行", 2: symbol[2:], 3: "10", 4: "9", 5: "9.5", 6: "1000", 30: timestamp,
                         31: "1", 32: "11.11", 33: "10.5", 34: "9", 35: "10/1000/1000000", 37: "100"}.items():
        values[index] = value
    return f'v_{symbol}="' + "~".join(values) + '";'


def test_tencent_quote_timestamp_units_and_unknown_latency():
    parsed = parse_tencent_quotes(tencent_payload())
    observed = parsed["sh600000"]
    assert observed.volume == 100000 and observed.amount == 1000000
    assert observed.timestamp == as_timestamp("2025-06-30 13:30")
    assert observed.provider_timestamp == observed.timestamp
    assert observed.quality == "unknown" and observed.reported_latency_seconds is None
    assert parse_tencent_quotes(tencent_payload(timestamp=""))["sh600000"].timestamp is None
    assert tencent_volume_multiplier("sh688001") == 1
    assert tencent_volume_multiplier("sz000001") == 100
    assert parse_tencent_quotes(tencent_payload("sh688001"))["sh688001"].volume == 1000


def test_quote_fetch_is_batched_and_missing_symbols_isolated(tmp_path):
    requests = []
    def respond(request):
        requests.append(request)
        return httpx.Response(200, content=tencent_payload().encode("gb18030"))
    client = httpx.Client(transport=httpx.MockTransport(respond))
    provider = DevelopmentProvider(client=client)
    result = provider.get_realtime_quotes(["sh600000", "sz000001", "bj920001"])
    assert len(requests) == 1
    assert "sh600000,sz000001,bj920001" in str(requests[0].url)
    assert list(result) == ["sh600000"]
    assert set(provider.last_errors) == {"sz000001", "bj920001"}


def test_batch_poll_circuit_breaker_stops_after_exhausted_request(monkeypatch):
    from ashare.data.base_provider import ProviderError
    provider = DevelopmentProvider(client=httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(503))))
    requests = []
    def fail(*args, **kwargs):
        requests.append(1)
        raise ProviderError("network unavailable")
    monkeypatch.setattr(provider, "_get", fail)
    symbols = [f"sh{600000 + i:06d}" for i in range(450)]
    assert provider.get_realtime_quotes(symbols) == {}
    assert len(requests) == 1
    assert len(provider.last_errors) == 450
