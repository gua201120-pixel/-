from datetime import datetime

import pytest
from pydantic import ValidationError

from ashare.models import FactorResult, SHANGHAI
from ashare.screening.rule_engine import RuleEngine
from ashare.strategies.schema import Rule, RuleGroup, Strategy
from ashare.strategies.registry import StrategyRegistry


@pytest.mark.parametrize("actual,op,expected,want", [
    (2,"==",2,True), (2,"!=",3,True), (2,">",1,True), (2,">=",2,True),
    (2,"<",3,True), (2,"<=",2,True), (2,"between",[2,3],True),
    (4,"not_between",[2,3],True), ("up","in",["up","sideways"],True),
    ("down","not_in",["up","sideways"],True), (3,">",3,False),
    (True,"in",[1],False),
])
def test_all_operators(actual, op, expected, want):
    assert RuleEngine().compare(actual,op,expected) is want


@pytest.mark.parametrize("actual,op,expected", [(True,"==",1), (None,"!=",2), (float("nan"),">",0), ("up",">",2)])
def test_types_fail_closed(actual,op,expected):
    with pytest.raises(ValueError):
        RuleEngine().compare(actual,op,expected)


def result(factor, passed=None, status="PASS", value=None):
    return FactorResult(factor_id=factor,passed=passed,value=value,status=status,
                        timestamp=datetime(2025,6,30,15,tzinfo=SHANGHAI))


def test_nested_logic_and_unknown():
    group=RuleGroup(logic="AND",rules=[Rule(factor="a"),RuleGroup(logic="OR",rules=[Rule(factor="b"),Rule(factor="c")])])
    data={"a":result("a",True),"b":result("b",False,"FAIL"),"c":result("c",True)}
    assert RuleEngine().evaluate(group,lambda rule:data[rule.factor]).passed is True
    data["c"]=result("c",None,"NOT_ENOUGH_DATA")
    assert RuleEngine().evaluate(group,lambda rule:data[rule.factor]).status=="NOT_ENOUGH_DATA"
    data["b"]=result("b",True)
    assert RuleEngine().evaluate(group,lambda rule:data[rule.factor]).passed is True


def test_disabled_rule_does_not_resolve():
    def resolve(rule):
        assert rule.factor=="a"
        return result("a",True)
    group=RuleGroup(rules=[Rule(factor="a"),Rule(factor="b",enabled=False)])
    assert RuleEngine().evaluate(group,resolve).passed is True


def test_schema_validation():
    with pytest.raises(ValidationError):
        Rule(factor="x",field="value",operator="between",value=[5,2])
    with pytest.raises(ValidationError):
        Rule(factor="x",operator=">=",value=1)
    with pytest.raises(ValidationError):
        Strategy(strategy_id="x",name="x",version="1",rules=RuleGroup())


@pytest.mark.parametrize("operator,value", [("==",float("nan")),("!=",float("inf")),("in",[1,float("nan")]),("not_in",[None])])
def test_nonfinite_or_invalid_operands_cannot_poison_persisted_strategy(operator,value):
    with pytest.raises(ValidationError):
        Rule(factor="x",field="value",operator=operator,value=value)


def test_immutable_versions_and_parameter_snapshot(tmp_path):
    from ashare.factors.registry import default_registry
    registry=StrategyRegistry(tmp_path/"db.sqlite", default_registry())
    current=registry.get("multi_timeframe_trend_setup_v1")
    assert len(current.rules.leaves())==8
    volume=next(r for r in current.rules.leaves() if r.factor=="daily_volume_expansion")
    assert volume.params["minimum_ratio"]==1.5
    with pytest.raises(FileExistsError):
        registry.save(current)
    newer=current.model_copy(deep=True)
    newer.version="2.0.0"
    next(r for r in newer.rules.leaves() if r.factor=="daily_volume_expansion").params["minimum_ratio"]=2
    registry.save(newer)
    assert registry.get(current.strategy_id,"1.0.0").rules.leaves()[-1].params["minimum_ratio"]==1.5
    assert registry.get(current.strategy_id,"2.0.0").rules.leaves()[-1].params["minimum_ratio"]==2
