"""Cooperative polling: UI/CLI owns the loop; no sleeping inside factor logic."""
from __future__ import annotations

import logging
from time import monotonic
from typing import TYPE_CHECKING

from ashare.models import now_shanghai

if TYPE_CHECKING:
    from ashare.service import ResearchService

log = logging.getLogger(__name__)


class RealtimeScanner:
    def __init__(self, service: ResearchService):
        self.service = service
        self.running = False
        self._next_due = 0.0
        self._failures = 0
        self._states: dict[tuple, str] = {}
        self._state_day = None
        self.state = "STOPPED"

    @property
    def interval(self) -> float:
        return max(self.service.settings.realtime_refresh_seconds, self.service.provider.min_poll_seconds)

    @property
    def last_results(self):
        return self.service.last_results

    @property
    def last_update(self):
        return self.service.last_update

    @property
    def last_scan_stats(self):
        return self.service.last_scan_stats

    def start(self):
        self.running = True
        self._next_due = 0
        self.state = "RUNNING"
        log.info("scanner_start provider=%s effective_interval=%s", self.service.provider.name, self.interval)

    def stop(self):
        self.running = False
        self.state = "STOPPED"
        log.info("scanner_stop")

    def tick(self, strategy, symbols=None, force=False):
        if not force and (not self.running or monotonic() < self._next_due):
            return None
        market = self.service.calendar.market_status(now_shanghai())
        if not force and market != "OPEN" and self.service.provider.quality != "simulated":
            self.state = "WAITING_" + market
            self._next_due = monotonic() + 30
            return None
        self.state = "SCANNING"
        results = self.service.screen(strategy, symbols=symbols, persist=False)
        day = results[0].as_of.date() if results else None
        if day != self._state_day:
            self._states.clear()
            self._state_day = day
        changes = []
        for result in results:
            key = (result.strategy_id, result.strategy_version, result.symbol)
            if self._states.get(key) != result.status:
                changes.append(result)
        if changes:
            if isinstance(strategy, str):
                strategy = self.service.strategies.get(strategy)
            self.service.research.save_run(strategy, changes, "realtime_status_transition")
        for result in results:
            self._states[(result.strategy_id, result.strategy_version, result.symbol)] = result.status
        failed = results and all(r.status == "DATA_ERROR" for r in results)
        self._failures = min(self._failures + 1, 5) if failed else 0
        self._next_due = monotonic() + min(300, self.interval * 2 ** self._failures)
        self.state = "BACKOFF" if failed else "RUNNING"
        return results
