"""Provider-independent screening orchestration."""
