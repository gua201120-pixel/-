"""A factor added to the registry requires no changes in this module."""
from __future__ import annotations

import hashlib
import json
import logging

from ashare.factors.registry import FactorRegistry
from ashare.models import FactorContext, FactorResult, ScreenResult, Stock
from ashare.strategies.schema import Rule, Strategy
from .rule_engine import RuleEngine

log = logging.getLogger(__name__)


def rule_key(rule: Rule) -> str:
    text = json.dumps([rule.factor, rule.factor_version, rule.params], sort_keys=True)
    return rule.factor + ":" + hashlib.sha256(text.encode()).hexdigest()[:10]


class Screener:
    def __init__(self, factors: FactorRegistry):
        self.factors = factors
        self.rules = RuleEngine()

    def screen_context(self, stock: Stock, context: FactorContext, strategy: Strategy, provider: str) -> ScreenResult:
        calculations: dict[str, FactorResult] = {}
        display: dict[str, FactorResult] = {}

        def resolve(rule: Rule) -> FactorResult:
            key = rule_key(rule)
            if key not in calculations:
                try:
                    factor = self.factors.get(rule.factor, rule.factor_version)
                    result = factor.calculate(context, rule.params)
                    if result.status not in ("PASS", "FAIL"):
                        log.warning("factor_data_status symbol=%s factor=%s status=%s reason=%s", stock.symbol, rule.factor, result.status, result.reason)
                except Exception as exc:
                    log.exception("factor_error symbol=%s factor=%s", stock.symbol, rule.factor)
                    result = FactorResult(factor_id=rule.factor, status="DATA_ERROR", reason=str(exc), timestamp=context.as_of.to_pydatetime(), adjustment=context.adjustment)
                calculations[key] = result
                display_key = rule.factor if rule.factor not in display else key
                display[display_key] = result
            return calculations[key]

        evaluation = self.rules.evaluate(strategy.rules, resolve)
        q = context.realtime_quote
        def failed_leaves(node):
            if "factor" in node:
                return [node["factor"]] if node["passed"] is not True else []
            return [name for child in node.get("children", []) for name in failed_leaves(child)]
        failed = list(dict.fromkeys(failed_leaves(evaluation.as_dict())))
        status = evaluation.status
        result = ScreenResult(
            symbol=stock.symbol, name=stock.name,
            latest_price=float(context.daily_bars.iloc[-1].close) if not context.daily_bars.empty else None,
            quote_timestamp=q.timestamp if q else None, received_at=q.received_at if q else None,
            as_of=context.as_of.to_pydatetime(), status=status, reason=evaluation.reason,
            factors=display, failed_factors=failed, rules=evaluation.as_dict(),
            strategy_id=strategy.strategy_id, strategy_version=strategy.version, provider=provider,
            metadata={**context.metadata, "adjustment": context.adjustment},
        )
        log.debug("strategy_evaluation symbol=%s strategy=%s version=%s status=%s", stock.symbol, strategy.strategy_id, strategy.version, status)
        return result
