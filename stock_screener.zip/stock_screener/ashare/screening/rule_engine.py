from __future__ import annotations

import math
import operator
from dataclasses import dataclass, field
from typing import Any, Callable

from ashare.models import FactorResult
from ashare.strategies.schema import Rule, RuleGroup


@dataclass
class RuleEvaluation:
    passed: bool | None
    status: str
    reason: str
    children: list[dict[str, Any]] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {"passed": self.passed, "status": self.status, "reason": self.reason, "children": self.children}


class RuleEngine:
    comparators = {"==": operator.eq, "!=": operator.ne, ">": operator.gt, ">=": operator.ge, "<": operator.lt, "<=": operator.le}

    @staticmethod
    def _same_type(left: Any, right: Any) -> bool:
        if type(left) is bool or type(right) is bool:
            return type(left) is bool and type(right) is bool
        return type(left) is type(right) or type(left) in (int, float) and type(right) in (int, float)

    def compare(self, actual: Any, op: str, expected: Any) -> bool:
        if actual is None or isinstance(actual, float) and not math.isfinite(actual):
            raise ValueError("factor value missing/non-finite")
        if op in ("in", "not_in"):
            member = any(self._same_type(actual, item) and actual == item for item in expected)
            return member if op == "in" else not member
        if op in ("between", "not_between"):
            if type(actual) not in (float, int):
                raise ValueError("numeric range applied to non-numeric output")
            between = expected[0] <= actual <= expected[1]
            return between if op == "between" else not between
        if op not in self.comparators:
            raise ValueError(f"Unknown operator: {op}")
        if not self._same_type(actual, expected):
            raise ValueError(f"type mismatch: {type(actual).__name__} / {type(expected).__name__}")
        return bool(self.comparators[op](actual, expected))

    def evaluate(self, group: RuleGroup, resolve: Callable[[Rule], FactorResult]) -> RuleEvaluation:
        children: list[dict[str, Any]] = []
        for rule in group.rules if group.enabled else []:
            if not rule.enabled:
                continue
            if isinstance(rule, RuleGroup):
                child = self.evaluate(rule, resolve)
                if child.status != "DISABLED":
                    children.append(child.as_dict())
                continue
            result = resolve(rule)
            item = {"factor": rule.factor, "field": rule.field, "operator": rule.operator, "expected": rule.value, "actual": getattr(result, rule.field), "params": result.parameters}
            if result.status not in ("PASS", "FAIL"):
                item.update(passed=None, status=result.status, reason=result.reason)
            else:
                try:
                    passed = self.compare(getattr(result, rule.field), rule.operator, rule.value)
                    item.update(passed=passed, status="PASS" if passed else "FAIL", reason=f"{item['actual']!r} {rule.operator} {rule.value!r}: {passed}")
                except (ValueError, TypeError) as exc:
                    item.update(passed=None, status="DATA_ERROR", reason=str(exc))
            children.append(item)
        if not children:
            return RuleEvaluation(None, "DISABLED", "No enabled rules", children)
        values = [c["passed"] for c in children]
        # An OR true determines the outcome. AND keeps required data errors
        # visible even when another known rule fails, so bad data is not FAIL.
        if group.logic == "OR" and True in values:
            return RuleEvaluation(True, "PASS", "At least one alternative passed", children)
        if None in values:
            bad = next(c for c in children if c["passed"] is None)
            return RuleEvaluation(None, bad["status"], "Outcome unknown: " + bad["reason"], children)
        if group.logic == "AND" and False in values:
            return RuleEvaluation(False, "FAIL", "At least one hard rule failed", children)
        passed = all(values) if group.logic == "AND" else any(values)
        return RuleEvaluation(passed, "PASS" if passed else "FAIL", "All hard rules passed" if passed else "No alternative passed", children)
