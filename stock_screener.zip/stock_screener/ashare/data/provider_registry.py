"""One extension point for authorized licensed providers; factors never change."""
from collections.abc import Callable

from ashare.data.base_provider import MarketDataProvider, ProviderError
from ashare.data.development_provider import DevelopmentProvider
from ashare.data.mock_provider import MockProvider

_PROVIDERS: dict[str, Callable] = {"development": DevelopmentProvider, "mock": MockProvider}


def register_provider(name: str, factory: Callable, *, replace: bool = False) -> None:
    if name in _PROVIDERS and not replace:
        raise ValueError(f"Provider {name} already registered")
    _PROVIDERS[name] = factory


def create_provider(name: str, settings=None) -> MarketDataProvider:
    if name not in _PROVIDERS:
        raise ProviderError(f"Provider {name!r} not installed; choose {', '.join(_PROVIDERS)} or register your licensed adapter")
    return _PROVIDERS[name](settings=settings)


def available_providers() -> list[str]:
    return sorted(_PROVIDERS)
