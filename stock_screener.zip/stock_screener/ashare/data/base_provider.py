"""Only this layer may call a market data vendor. All units are CNY/shares."""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Sequence
from datetime import date
from typing import Protocol

import pandas as pd

from ashare.models import Quote, Stock


class DataError(ValueError):
    """Bad, incomplete or unavailable market observations; never ordinary FAIL."""


class ProviderError(DataError):
    """A bounded vendor request or schema validation failed."""


class UnsupportedAdjustmentError(DataError):
    pass


class MarketDataProvider(ABC):
    name = "base"
    quality = "unknown"
    min_poll_seconds = 5.0
    supports_adjustment = frozenset({"raw"})

    def normalize_symbol(self, symbol: str) -> str:
        """Adapters may accept aliases; returned symbols are provider canonical."""
        return symbol

    def validate_adjustment(self, adjustment: str) -> None:
        if adjustment not in self.supports_adjustment:
            raise UnsupportedAdjustmentError(
                f"{self.name} does not support {adjustment}: synchronized, point-in-time "
                "corporate-action factors are required for both bars and quotes. Use raw."
            )

    @abstractmethod
    def get_stock_list(self, force_refresh: bool = False) -> list[Stock]: ...

    @abstractmethod
    def get_daily_bars(self, symbol: str, start_date: str | date | None = None,
                       end_date: str | date | None = None, adjustment: str = "raw") -> pd.DataFrame: ...

    def get_realtime_quote(self, symbol: str) -> Quote:
        quotes = self.get_realtime_quotes([symbol])
        if symbol not in quotes:
            raise ProviderError(f"No quote returned for {symbol}")
        return quotes[symbol]

    @abstractmethod
    def get_realtime_quotes(self, symbols: Sequence[str] | None = None) -> dict[str, Quote]: ...

    def get_financial_data(self, symbol: str) -> pd.DataFrame:
        """Future adapters must return publication/available_at, never just report date."""
        return pd.DataFrame(columns=["metric", "value", "report_date", "available_at"])

    def get_dataset(self, name: str, symbol: str) -> pd.DataFrame:
        """Lazy dataset extension point used only by factors declaring a need."""
        if name == "financial":
            return self.get_financial_data(symbol)
        raise ProviderError(f"{self.name} has no dataset adapter for {name!r}")


class StreamingMarketDataProvider(Protocol):
    async def subscribe(self, symbols: Sequence[str]) -> None: ...
    async def unsubscribe(self, symbols: Sequence[str]) -> None: ...
    def stream_quotes(self) -> AsyncIterator[Quote]: ...
