"""Finite exchange calendar: XSHG history plus SSE's published 2026 holidays.

No weekday fallback outside coverage. SH/SZ/BJ follow these cash-equity session
dates in this MVP; auctions are intentionally not marked continuous OPEN.
"""
from __future__ import annotations

from datetime import date, time, timedelta
from functools import lru_cache

import exchange_calendars as xcals
import pandas as pd

from ashare.models import as_timestamp


class CalendarCoverageError(ValueError):
    pass


@lru_cache(maxsize=1)
def _known_sessions() -> pd.DatetimeIndex:
    historical = xcals.get_calendar("XSHG", start="2000-01-01", end="2025-12-31").sessions
    if historical.tz is not None:
        historical = historical.tz_localize(None)
    # SSE: https://www.sse.com.cn/disclosure/dealinstruc/closed/c/c_20251222_10802510.shtml
    closed = [("2026-01-01", "2026-01-03"), ("2026-02-15", "2026-02-23"),
              ("2026-04-04", "2026-04-06"), ("2026-05-01", "2026-05-05"),
              ("2026-06-19", "2026-06-21"), ("2026-09-25", "2026-09-27"),
              ("2026-10-01", "2026-10-07")]
    holidays = {d for start, end in closed for d in pd.date_range(start, end)}
    supplement = pd.DatetimeIndex([d for d in pd.bdate_range("2026-01-01", "2026-12-31")
                                  if d not in holidays])
    return historical.append(supplement).sort_values().unique()


class ExchangeCalendar:
    first_date = date(2000, 1, 1)
    last_date = date(2026, 12, 31)

    def __init__(self) -> None:
        self._sessions = _known_sessions()
        self._dates = frozenset(self._sessions.date)

    def _covered(self, day: date) -> None:
        if not self.first_date <= day <= self.last_date:
            raise CalendarCoverageError(f"Exchange calendar covers {self.first_date} through {self.last_date}; got {day}")

    def is_session(self, day: date | str | pd.Timestamp) -> bool:
        day = pd.Timestamp(day).date()
        self._covered(day)
        return day in self._dates

    def sessions(self, start: date | str, end: date | str) -> pd.DatetimeIndex:
        start, end = pd.Timestamp(start).normalize(), pd.Timestamp(end).normalize()
        self._covered(start.date())
        self._covered(end.date())
        return self._sessions[(self._sessions >= start) & (self._sessions <= end)]

    sessions_in_range = sessions

    def previous_session(self, day: date | str) -> date:
        """Strictly preceding exchange session, including when day is a holiday."""
        day = pd.Timestamp(day).date()
        self._covered(day)
        position = self._sessions.searchsorted(pd.Timestamp(day)) - 1
        if position < 0:
            raise CalendarCoverageError("Previous session precedes validated calendar coverage")
        return self._sessions[position].date()

    def last_session(self, day: date | str) -> date:
        day = pd.Timestamp(day).date()
        return day if self.is_session(day) else self.previous_session(day)

    def market_status(self, as_of) -> str:
        stamp = as_timestamp(as_of)
        try:
            if not self.is_session(stamp.date()):
                return "NON_TRADING_DAY"
        except CalendarCoverageError:
            return "UNKNOWN"
        clock = stamp.time()
        if time(9, 30) <= clock < time(11, 30) or time(13) <= clock < time(15):
            return "OPEN"
        if time(11, 30) <= clock < time(13):
            return "LUNCH_BREAK"
        return "PRE_OPEN" if clock < time(9, 30) else "CLOSED"

    @lru_cache(maxsize=4096)
    def period_last_session(self, period: pd.Period) -> date:
        days = self.sessions(max(period.start_time.date(), self.first_date),
                             min(period.end_time.date(), self.last_date))
        if not len(days):
            raise CalendarCoverageError(f"No sessions in {period}")
        # Do not claim completeness if the period extends beyond known coverage.
        if period.end_time.date() > self.last_date:
            raise CalendarCoverageError(f"Period {period} extends beyond calendar coverage")
        return days[-1].date()
