"""Incremental Parquet history. Reads never trigger a vendor request."""
from __future__ import annotations

import json
import re
from datetime import timedelta
from pathlib import Path
from threading import RLock
from uuid import uuid4

import pandas as pd

from ashare.models import now_shanghai
from ashare.data.base_provider import DataError, MarketDataProvider
from ashare.data.resample import empty_bars, history_revision, normalize_bars


class BarStore:
    def __init__(self, root: Path, provider_name: str = "default") -> None:
        self.root = Path(root) / "bars" / self._component(provider_name)
        self.root.mkdir(parents=True, exist_ok=True)
        self._cache: dict[tuple[str, str], tuple[int, pd.DataFrame]] = {}
        self._lock = RLock()
        self._symbol_locks: dict[tuple[str, str], RLock] = {}

    def _symbol_lock(self, symbol: str, adjustment: str) -> RLock:
        with self._lock:
            return self._symbol_locks.setdefault((symbol, adjustment), RLock())

    @staticmethod
    def _component(value: str) -> str:
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", value) or value in {".", ".."}:
            raise ValueError("Invalid cache namespace or symbol")
        return value

    def _path(self, symbol: str, adjustment: str) -> Path:
        self._component(adjustment)
        folder = self.root / adjustment
        folder.mkdir(exist_ok=True)
        return folder / f"{self._component(symbol)}.parquet"

    def load(self, symbol: str, adjustment: str = "raw") -> pd.DataFrame:
        path = self._path(symbol, adjustment)
        with self._lock:
            if not path.exists():
                return empty_bars()
            modified = path.stat().st_mtime_ns
            key = (symbol, adjustment)
            if key not in self._cache or self._cache[key][0] != modified:
                frame = normalize_bars(pd.read_parquet(path))
                frame.attrs["historical_revision"] = history_revision(frame)
                self._cache[key] = (modified, frame)
            return self._cache[key][1].copy()

    def save(self, symbol: str, bars: pd.DataFrame, adjustment: str = "raw") -> None:
        frame = normalize_bars(bars)
        if not frame.empty and bool(frame.is_partial.any()):
            raise DataError("BarStore accepts completed history only; partial quotes stay in memory")
        path = self._path(symbol, adjustment)
        temporary = path.with_suffix(f".{uuid4().hex}.tmp")
        with self._lock:
            try:
                frame.to_parquet(temporary, index=True)
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)
            self._cache.pop((symbol, adjustment), None)

    def sync(self, provider: MarketDataProvider, symbol: str, start_date, end_date,
             adjustment: str = "raw") -> pd.DataFrame:
        """Fetch uncovered date intervals, persist complete bars, and resume safely.

        Coverage records successful empty intervals too (e.g. suspension), avoiding
        repeated downloads. Missing sessions are never forward filled.
        """
        provider.validate_adjustment(adjustment)
        start, end = pd.Timestamp(start_date).normalize(), pd.Timestamp(end_date).normalize()
        now = pd.Timestamp(now_shanghai())
        latest_complete = now.tz_localize(None).normalize()
        if now.hour < 15:
            latest_complete -= pd.Timedelta(days=1)
        end = min(end, latest_complete)
        if start > end:
            return self.load(symbol, adjustment)
        path = self._path(symbol, adjustment)
        manifest = path.with_suffix(".json")
        with self._symbol_lock(symbol, adjustment):
            old = self.load(symbol, adjustment)
            covered = json.loads(manifest.read_text(encoding="utf-8")) if manifest.exists() and path.exists() else {}
            ranges = [(start, end)]
            if covered:
                first, last = pd.Timestamp(covered["coverage_start"]), pd.Timestamp(covered["coverage_end"])
                ranges = []
                if start < first:
                    ranges.append((start, first - pd.Timedelta(days=1)))
                if end > last:
                    ranges.append((last + pd.Timedelta(days=1), end))
            if not ranges:
                return old
            parts = [old] if not old.empty else []
            for begin, finish in ranges:
                incoming = normalize_bars(provider.get_daily_bars(symbol, begin.date(), finish.date(), adjustment))
                incoming = incoming[(incoming.index >= begin) & (incoming.index <= finish)
                                    & (incoming.available_at <= now) & ~incoming.is_partial]
                if not incoming.empty:
                    parts.append(incoming)
            combined = normalize_bars(pd.concat(parts)) if parts else empty_bars()
            self.save(symbol, combined, adjustment)
            coverage_start = min(start, pd.Timestamp(covered.get("coverage_start", start)))
            coverage_end = max(end, pd.Timestamp(covered.get("coverage_end", end)))
            provenance = {"provider": provider.name, "adjustment": adjustment,
                          "coverage_start": str(coverage_start.date()), "coverage_end": str(coverage_end.date()),
                          "acquired_at": now.isoformat(), "revision": history_revision(combined),
                          "availability_policy": "Public finalized daily bars assumed available at exchange close; revisions not archived",
                          "rows": len(combined)}
            temporary = manifest.with_suffix(f".{uuid4().hex}.tmp")
            try:
                temporary.write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding="utf-8")
                temporary.replace(manifest)
            finally:
                temporary.unlink(missing_ok=True)
            return self.load(symbol, adjustment)
