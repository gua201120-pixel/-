"""Thread-safe cumulative quote cache. Never sum repeated daily volume."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from threading import RLock

from ashare.models import Quote


class QuoteCache:
    def __init__(self) -> None:
        self._quotes: dict[str, Quote] = {}
        self._lock = RLock()
        self.rejected_updates = 0

    def update(self, quote: Quote) -> bool:
        with self._lock:
            old = self._quotes.get(quote.symbol)
            invalid = quote.timestamp is None
            if old and old.timestamp and quote.timestamp:
                invalid = invalid or quote.timestamp < old.timestamp
                if quote.timestamp == old.timestamp:
                    invalid = invalid or quote.received_at < old.received_at
                if quote.timestamp.date() == old.timestamp.date() and quote.volume is not None and old.volume is not None:
                    invalid = invalid or quote.volume < old.volume
            if invalid:
                self.rejected_updates += 1
                return False
            self._quotes[quote.symbol] = quote.model_copy(deep=True)
            return True

    def update_many(self, quotes: Mapping[str, Quote] | Iterable[Quote]) -> int:
        values = quotes.values() if isinstance(quotes, Mapping) else quotes
        return sum(self.update(quote) for quote in values)

    def get(self, symbol: str) -> Quote | None:
        with self._lock:
            quote = self._quotes.get(symbol)
            return quote.model_copy(deep=True) if quote else None

    def snapshot(self) -> dict[str, Quote]:
        with self._lock:
            return {key: value.model_copy(deep=True) for key, value in self._quotes.items()}

    def clear(self) -> None:
        with self._lock:
            self._quotes.clear()
