"""Prepare the same point-in-time factor context for realtime and replay."""
from __future__ import annotations

from collections import OrderedDict
from datetime import time

import numpy as np
import pandas as pd

from ashare.models import FactorContext, Quote, SHANGHAI, as_timestamp
from ashare.data.base_provider import DataError, UnsupportedAdjustmentError
from ashare.data.calendar import ExchangeCalendar
from ashare.data.resample import OHLCV, history_revision, normalize_bars, resample_bars


class ContextBuilder:
    def __init__(self, calendar: ExchangeCalendar, max_cache_entries: int = 12000) -> None:
        self.calendar = calendar
        self.max_cache_entries = max_cache_entries
        self._period_cache: OrderedDict[tuple, pd.DataFrame] = OrderedDict()
        self._normalized_cache: OrderedDict[tuple, pd.DataFrame] = OrderedDict()
        self.cache_hits = 0

    def _aggregate(self, symbol: str, completed: pd.DataFrame, current: pd.DataFrame | None,
                   timeframe: str, stamp: pd.Timestamp, revision: str) -> pd.DataFrame:
        frequency = "W-FRI" if timeframe == "weekly" else "M"
        # A filtered-prefix key is necessary when replay runs backwards within
        # a period and a previously included observation had delayed availability.
        # For fixed revision, inclusion is monotone in as_of; count identifies it.
        key = (symbol, timeframe, revision, stamp.date(), len(completed),
               str(completed.index[-1]) if not completed.empty else "")
        if key not in self._period_cache:
            self._period_cache[key] = resample_bars(completed, timeframe, stamp, self.calendar)
            if len(self._period_cache) > self.max_cache_entries:
                self._period_cache.popitem(last=False)
        else:
            self.cache_hits += 1
            self._period_cache.move_to_end(key)
        baseline = self._period_cache[key]
        if current is None or current.empty:
            result = baseline.copy()
            if not result.empty:
                close_at = as_timestamp(result.period_end.iloc[-1].date())
                result.loc[result.index[-1], "is_partial"] = stamp < close_at
            return result
        current_date = current.index[-1]
        current_period = current_date.to_period(frequency)
        record = current.iloc[-1].to_dict()
        prefix = baseline
        if not baseline.empty and baseline.index[-1].to_period(frequency) == current_period:
            previous = baseline.iloc[-1]
            record.update(open=previous.open, high=max(previous.high, record["high"]),
                          low=min(previous.low, record["low"]),
                          volume=previous.volume + record["volume"], amount=previous.amount + record["amount"],
                          available_at=max(previous.available_at, record["available_at"]),
                          session_count=int(previous.session_count) + 1)
            prefix = baseline.iloc[:-1]
        else:
            record["session_count"] = 1
        end = self.calendar.period_last_session(current_period)
        record["period_end"] = pd.Timestamp(end)
        record["is_partial"] = bool(record["is_partial"] or stamp < as_timestamp(end))
        tail = pd.DataFrame([record], index=pd.DatetimeIndex([current_date], name="date"))
        return pd.concat([prefix, tail]) if not prefix.empty else tail

    def build(self, symbol: str, bars: pd.DataFrame, as_of, quote: Quote | None = None,
              adjustment: str = "raw", metadata: dict | None = None) -> FactorContext:
        if adjustment != "raw":
            raise UnsupportedAdjustmentError("ContextBuilder requires raw bars/quotes until a PIT adjustment policy is installed")
        stamp = as_timestamp(as_of)
        self.calendar._covered(stamp.date())
        info = dict(metadata or {})
        revision = bars.attrs.get("historical_revision") or history_revision(bars)
        normalized_key = (symbol, adjustment, revision)
        if normalized_key not in self._normalized_cache:
            self._normalized_cache[normalized_key] = normalize_bars(bars)
            if len(self._normalized_cache) > self.max_cache_entries // 2:
                self._normalized_cache.popitem(last=False)
        else:
            self._normalized_cache.move_to_end(normalized_key)
        frame = self._normalized_cache[normalized_key]
        # Availability and date filters BOTH matter: future dates with malformed
        # availability cannot leak through, nor can today's final bar at 10:30.
        day = pd.Timestamp(stamp.date())
        completed = frame[(frame.index <= day) & (frame.available_at <= stamp) & ~frame.is_partial].copy()
        intraday = self.calendar.is_session(stamp.date()) and time(9, 30) <= stamp.time() < time(15)
        if intraday:
            completed = completed[completed.index < day]
        daily = completed.copy()
        selected_quote = None
        current = None
        if quote is not None:
            if quote.symbol != symbol:
                raise DataError("Quote symbol does not match requested context")
            if quote.timestamp is None:
                raise DataError("Quote has no exchange timestamp; receive time cannot substitute for it")
            quote_time = as_timestamp(quote.timestamp)
            if quote_time > stamp:
                raise DataError("Quote occurs after requested as_of")
            if quote.received_at > stamp or quote.provider_timestamp is not None and quote.provider_timestamp > stamp:
                raise DataError("Quote was not yet received/published at requested as_of")
            expected_day = self.calendar.last_session(stamp.date())
            if self.calendar.is_session(stamp.date()) and stamp.time() < time(9, 30):
                expected_day = self.calendar.previous_session(stamp.date())
            if quote_time.date() != expected_day:
                raise DataError("Quote is not from the expected latest exchange session")
            quote_day = pd.Timestamp(quote_time.date())
            if quote.suspended:
                info["suspended"] = True
                selected_quote = quote
            else:
                if not self.calendar.is_session(quote_time.date()):
                    raise DataError("Quote timestamp is on an exchange holiday")
                if quote_time.time() < time(9, 30):
                    raise DataError("Auction/pre-open quote cannot construct a continuous-trading daily bar")
                values = {"open": quote.open, "high": quote.high, "low": quote.low,
                          "close": quote.latest_price, "volume": quote.volume, "amount": quote.amount}
                if any(values[field] is None for field in ["open", "high", "low", "close", "volume"]):
                    raise DataError("Quote lacks OHLC or cumulative volume")
                # Unknown amount is preserved as NaN. Liquidity filters must fail
                # closed if enabled; technical price/volume factors still work.
                values["amount"] = np.nan if values["amount"] is None else values["amount"]
                prices = [values[field] for field in ("open", "high", "low", "close")]
                if (any(not np.isfinite(value) or value <= 0 for value in prices)
                    or values["high"] < max(prices) or values["low"] > min(prices)
                    or not np.isfinite(values["volume"]) or values["volume"] < 0
                    or values["amount"] < 0 or np.isinf(values["amount"])):
                    raise DataError("Invalid quote OHLC/cumulative volume/amount")
                values["available_at"] = quote_time
                values["is_partial"] = quote_time.time() < time(15)
                current = pd.DataFrame([values], index=pd.DatetimeIndex([quote_day], name="date"))
                completed = completed[completed.index < quote_day]
                daily = pd.concat([completed, current]) if not completed.empty else current.copy()
                selected_quote = quote
        if intraday and selected_quote is None:
            raise DataError("Historical daily OHLC cannot reconstruct intraday as_of; a recorded same-session quote is required")
        # Unknown security-master vintages are explicit research limitations.
        info.update({"historical_revision": revision,
                     "point_in_time_policy": "available_at <= as_of; finalized public daily bar availability assumed at 15:00",
                     "historical_revision_limit": "Public historical revisions/corporate actions are not vintage archived",
                     "metadata_point_in_time": bool(info.get("metadata_point_in_time", False)),
                     "daily_last_session": daily.index[-1].date().isoformat() if not daily.empty else None})
        financial = info.pop("financial_data", pd.DataFrame())
        if not isinstance(financial, pd.DataFrame):
            financial = pd.DataFrame(financial)
        if not financial.empty:
            if "available_at" not in financial:
                raise DataError("Fundamentals require available_at publication timestamps")
            financial = financial.copy()
            if financial.available_at.isna().any():
                raise DataError("Fundamentals contain missing available_at publication timestamps")
            financial["available_at"] = [as_timestamp(value) for value in financial.available_at]
            financial = financial[financial.available_at <= stamp]
        weekly = self._aggregate(symbol, completed, current, "weekly", stamp, revision)
        monthly = self._aggregate(symbol, completed, current, "monthly", stamp, revision)
        return FactorContext(symbol=symbol, as_of=stamp, daily_bars=daily,
                             weekly_bars=weekly, monthly_bars=monthly, realtime_quote=selected_quote,
                             metadata=info, adjustment=adjustment, financial_data=financial)
