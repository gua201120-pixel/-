"""Deterministic synthetic fixtures; every object prominently says simulated."""
from __future__ import annotations

import hashlib
from collections.abc import Sequence
from datetime import time

import numpy as np
import pandas as pd

from ashare.models import Quote, Stock, as_timestamp, now_shanghai
from ashare.data.base_provider import MarketDataProvider, ProviderError
from ashare.data.calendar import ExchangeCalendar
from ashare.data.development_provider import canonical_symbol
from ashare.data.resample import normalize_bars


class MockProvider(MarketDataProvider):
    name = "mock"
    quality = "simulated"
    min_poll_seconds = 1.0

    normalize_symbol = staticmethod(canonical_symbol)

    def __init__(self, settings=None, as_of=None, size: int = 12) -> None:
        self.calendar = ExchangeCalendar()
        self.as_of = as_of
        self.size = size
        self.history_calls = 0
        self.quote_calls = 0
        self.last_errors: dict[str, str] = {}
        self.quote_overrides: dict[str, Quote] = {}

    def get_stock_list(self, force_refresh: bool = False) -> list[Stock]:
        codes = ["sh600000", "sz000001", "sh600519", "sh688001", "sz300750", "bj920001",
                 "sz002594", "sh601318", "sz000333", "sh600036", "sh601888", "sz000651"]
        return [Stock(symbol=code, code=code[2:], name=f"模拟股票 {i + 1}", exchange=code[:2].upper(),
                      list_date=pd.Timestamp("2000-01-04").date(), industry="模拟行业", metadata_as_of=now_shanghai())
                for i, code in enumerate(codes[:self.size])]

    def get_daily_bars(self, symbol: str, start_date=None, end_date=None, adjustment: str = "raw") -> pd.DataFrame:
        self.validate_adjustment(adjustment)
        symbol = canonical_symbol(symbol)
        self.history_calls += 1
        days = self.calendar.sessions(start_date or "2021-01-01", end_date or self._clock().date())
        seed = int(hashlib.sha256(symbol.encode()).hexdigest()[:8], 16)
        x = (days - pd.Timestamp("2000-01-01")).days.to_numpy(dtype=float)
        phase = seed % 100 / 9.0
        trend = 7 + (seed % 80) / 8 + 0.0018 * x
        close = trend * (1 + 0.12 * np.sin(x / 46 + phase) + 0.035 * np.sin(x / 7 + phase))
        opening = close * (1 - 0.009 * np.sin(x / 3 + phase))
        volume = np.round(1000000 * (1.1 + 0.4 * np.cos(x / 8 + phase)))
        frame = pd.DataFrame({"open": opening, "close": close, "high": np.maximum(opening, close) * 1.012,
                              "low": np.minimum(opening, close) * 0.988, "volume": volume,
                              "amount": volume * (opening + close) / 2}, index=days)
        result = normalize_bars(frame)
        result.attrs["simulated"] = True
        return result

    def _clock(self) -> pd.Timestamp:
        return as_timestamp(self.as_of or now_shanghai())

    def get_realtime_quotes(self, symbols: Sequence[str] | None = None) -> dict[str, Quote]:
        self.quote_calls += 1
        current = self._clock()
        day = self.calendar.last_session(current.date())
        if day == current.date() and current.time() < time(9, 30):
            day = self.calendar.previous_session(day)
        live = day == current.date() and current.time() < time(15)
        stamp = current if live else as_timestamp(day)
        if live:
            morning_minutes = min(max((stamp.hour - 9) * 60 + stamp.minute - 30, 0), 120)
            afternoon_minutes = min(max((stamp.hour - 13) * 60 + stamp.minute, 0), 120)
            fraction = max((morning_minutes + afternoon_minutes) / 240, 0.002)
        else:
            fraction = 1.0
        stocks = {stock.symbol: stock for stock in self.get_stock_list()}
        requested = list(symbols) if symbols is not None else list(stocks)
        result = {}
        for requested_symbol in requested:
            symbol = canonical_symbol(requested_symbol)
            if symbol in self.quote_overrides:
                result[symbol] = self.quote_overrides[symbol].model_copy(deep=True)
                continue
            previous_day = self.calendar.previous_session(day)
            history = self.get_daily_bars(symbol, previous_day, day)
            self.history_calls -= 1  # Local generation is not a history network request.
            row = history.iloc[-1]
            price = row.open + (row.close - row.open) * fraction
            previous = history.iloc[-2].close
            result[symbol] = Quote(symbol=symbol, name=stocks.get(symbol, Stock(symbol=symbol, code=symbol[2:], name="模拟股票", exchange=symbol[:2])).name,
                                   timestamp=stamp.to_pydatetime(), provider_timestamp=stamp.to_pydatetime(), received_at=current.to_pydatetime(),
                                   latest_price=price, open=row.open, high=max(row.open, price) * (1 + 0.012 * fraction),
                                   low=min(row.open, price) * (1 - 0.012 * fraction), previous_close=previous,
                                   volume=float(round(row.volume * fraction)), amount=float(row.amount * fraction),
                                   change=price - previous, change_pct=(price / previous - 1) * 100,
                                   provider=self.name, quality="simulated", extra={"synthetic": True})
        return result
