"""Normalize daily observations and derive periods without inventing sessions."""
from __future__ import annotations

import hashlib

import numpy as np
import pandas as pd

from ashare.models import SHANGHAI, as_timestamp
from ashare.data.base_provider import DataError
from ashare.data.calendar import ExchangeCalendar

OHLCV = ["open", "high", "low", "close", "volume", "amount"]
BAR_COLUMNS = OHLCV + ["available_at", "is_partial"]


def empty_bars() -> pd.DataFrame:
    frame = pd.DataFrame({column: pd.Series(dtype="float64") for column in OHLCV},
                         index=pd.DatetimeIndex([], name="date"))
    frame["available_at"] = pd.Series(index=frame.index, dtype="datetime64[ns, Asia/Shanghai]")
    frame["is_partial"] = pd.Series(index=frame.index, dtype=bool)
    return frame


def normalize_bars(bars: pd.DataFrame) -> pd.DataFrame:
    if bars.empty:
        return empty_bars()
    frame = bars.copy()
    if "date" in frame:
        frame = frame.set_index("date")
    frame.index = pd.DatetimeIndex(pd.to_datetime(frame.index))
    if frame.index.tz is not None:
        frame.index = frame.index.tz_convert(SHANGHAI).tz_localize(None)
    frame.index = frame.index.normalize()
    frame.index.freq = None  # Sparse exchange/suspension series has no inferred cadence.
    frame.index.name = "date"
    if not set(OHLCV) <= set(frame.columns):
        raise DataError(f"Missing daily bar fields: {set(OHLCV) - set(frame.columns)}")
    frame = frame[~frame.index.duplicated(keep="last")].sort_index()
    for column in OHLCV:
        frame[column] = pd.to_numeric(frame[column], errors="coerce").astype(float)
    prices = frame[["open", "high", "low", "close"]]
    invalid = (~np.isfinite(prices)).any(axis=1) | (prices <= 0).any(axis=1)
    invalid |= (frame.high < prices[["open", "close", "low"]].max(axis=1))
    invalid |= (frame.low > prices[["open", "close", "high"]].min(axis=1))
    invalid |= ~np.isfinite(frame.volume) | (frame.volume < 0)
    # Amount may be unavailable from an adapter but must never be fabricated.
    invalid |= (frame.amount < 0) | np.isinf(frame.amount)
    if invalid.any():
        raise DataError(f"Invalid OHLC/volume at {frame.index[invalid][0].date()}")
    if "available_at" not in frame:
        frame["available_at"] = (frame.index + pd.Timedelta(hours=15)).tz_localize(SHANGHAI)
    else:
        frame["available_at"] = [as_timestamp(value) if not pd.isna(value) else pd.NaT
                                 for value in frame.available_at]
        if frame.available_at.isna().any():
            raise DataError("Missing daily bar availability timestamp")
    if "is_partial" not in frame:
        frame["is_partial"] = False
    frame["is_partial"] = frame.is_partial.astype(bool)
    return frame[BAR_COLUMNS]


def history_revision(bars: pd.DataFrame) -> str:
    return hashlib.sha256(pd.util.hash_pandas_object(bars, index=True).values.tobytes()).hexdigest()[:24]


def resample_bars(daily: pd.DataFrame, timeframe: str, as_of, calendar: ExchangeCalendar) -> pd.DataFrame:
    """Label each period by its last observed session, never its future end date."""
    if daily.empty:
        return empty_bars()
    frequency = {"weekly": "W-FRI", "monthly": "M"}.get(timeframe, timeframe)
    if frequency not in {"W-FRI", "M"}:
        raise ValueError("Timeframe must be weekly or monthly")
    stamp = as_timestamp(as_of)
    groups = daily.groupby(daily.index.to_period(frequency), sort=True)
    result = groups.agg(open=("open", "first"), high=("high", "max"), low=("low", "min"),
                        close=("close", "last"), volume=("volume", "sum"), amount=("amount", "sum"),
                        available_at=("available_at", "max"), is_partial=("is_partial", "any"),
                        session_count=("close", "size"))
    # Unknown cash turnover must remain unknown, including mixed-known periods.
    missing_amount = groups.amount.count() != groups.size()
    result.loc[missing_amount, "amount"] = np.nan
    period_ends = pd.DatetimeIndex([calendar.period_last_session(period) for period in result.index])
    closes = (period_ends + pd.Timedelta(hours=15)).tz_localize(SHANGHAI)
    result["is_partial"] = result.is_partial.to_numpy() | (closes > stamp)
    result["period_end"] = period_ends
    date_values = pd.Series(daily.index, index=daily.index).groupby(daily.index.to_period(frequency)).last()
    result.index = pd.DatetimeIndex(date_values, name="date")
    result.index.freq = None
    return result
