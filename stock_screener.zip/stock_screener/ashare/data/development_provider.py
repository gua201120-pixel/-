"""Credential-free Tencent adapter, explicitly uncertified latency/availability.

Endpoints/schema are independently verified against AKShare's official source:
https://github.com/akfamily/akshare/blob/main/akshare/stock/stock_zh_a_tx.py
https://github.com/akfamily/akshare/blob/main/akshare/stock_feature/stock_hist_tx.py

Direct httpx calls ensure every request has a timeout (including the universe).
No endpoint timestamp is replaced with local time. Historical acquisition is
explicit; quote refresh performs ONLY batched quote calls.
"""
from __future__ import annotations

import json
import logging
import math
import re
import time
from collections.abc import Sequence
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock

import httpx
import numpy as np
import pandas as pd

from ashare.models import Quote, SHANGHAI, Stock, now_shanghai
from ashare.data.base_provider import MarketDataProvider, ProviderError
from ashare.data.resample import empty_bars, normalize_bars

log = logging.getLogger(__name__)


def canonical_symbol(symbol: str) -> str:
    value = symbol.strip().lower()
    if re.fullmatch(r"\d{6}\.(sh|sz|bj)", value):
        code, exchange = value.split(".")
        value = exchange + code
    if re.fullmatch(r"\d{6}", value):
        value = ("sh" if value.startswith("6") else "bj" if value.startswith(("4", "8", "9")) else "sz") + value
    if not re.fullmatch(r"(sh|sz|bj)\d{6}", value):
        raise ProviderError(f"Invalid A-share symbol: {symbol}")
    if value[:2] == "sh" and not value[2:].startswith("6") or value[:2] == "sz" and not value[2:].startswith(("0", "3")):
        raise ProviderError(f"Only A-share stock symbols are supported: {symbol}")
    return value


def _number(value: str | None) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (ValueError, TypeError):
        return None


def tencent_volume_multiplier(symbol: str) -> int:
    # STAR quotes and newfqkline histories are already in shares. SH main board,
    # SZ (including 000001 stocks), and BJ use lots. Checked against cash turnover.
    return 1 if symbol.startswith("sh688") else 100


def parse_tencent_quotes(text: str, received_at: datetime | None = None) -> dict[str, Quote]:
    received = received_at or now_shanghai()
    result: dict[str, Quote] = {}
    for symbol, body in re.findall(r'v_((?:sh|sz|bj)\d{6})="([^"]*)"', text):
        fields = body.split("~")
        if len(fields) < 38:
            continue
        stamp = None
        if re.fullmatch(r"\d{14}", fields[30]):
            try:
                stamp = datetime.strptime(fields[30], "%Y%m%d%H%M%S").replace(tzinfo=SHANGHAI)
            except ValueError:
                pass
        multiplier = tencent_volume_multiplier(symbol)
        volume = _number(fields[6])
        # The slash tuple carries cash amount in CNY with greater precision than
        # field 37 (10k CNY). Keep its exact public-feed observation when present.
        tuple_fields = fields[35].split("/")
        amount = _number(tuple_fields[2]) if len(tuple_fields) >= 3 else None
        if amount is None:
            field_amount = _number(fields[37])
            amount = field_amount * 10000 if field_amount is not None else None
        opening, latest = _number(fields[5]), _number(fields[3])
        extra = {"timestamp_source": "Tencent field 30 (feed observation time; exchange certification unavailable)",
                 "volume_multiplier": multiplier,
                 "bid_prices": [_number(fields[i]) for i in (9, 11, 13, 15, 17)],
                 "ask_prices": [_number(fields[i]) for i in (19, 21, 23, 25, 27)]}
        result[symbol] = Quote(symbol=symbol, name=fields[1], timestamp=stamp, provider_timestamp=stamp,
                               received_at=received, latest_price=latest, open=opening,
                               high=_number(fields[33]), low=_number(fields[34]),
                               previous_close=_number(fields[4]),
                               volume=volume * multiplier if volume is not None else None,
                               amount=amount, change=_number(fields[31]), change_pct=_number(fields[32]),
                               provider="development", quality="unknown", reported_latency_seconds=None,
                               # Lack of prints is not proof of suspension. Infer
                               # only an explicit unavailable open + zero volume
                               # after continuous trading began; label inference.
                               suspended=bool(stamp and stamp.hour >= 10 and volume == 0 and opening == 0),
                               extra=extra)
        if result[symbol].suspended:
            result[symbol].extra["suspension_evidence"] = "inferred: zero open/volume after 10:00; verify with official security status"
    return result


class DevelopmentProvider(MarketDataProvider):
    name = "development"
    quality = "unknown"
    min_poll_seconds = 5.0
    batch_size = 200

    normalize_symbol = staticmethod(canonical_symbol)

    def __init__(self, settings=None, client: httpx.Client | None = None) -> None:
        self.timeout = getattr(settings, "request_timeout_seconds", 12.0)
        self.storage_dir = Path(getattr(settings, "storage_dir", "storage"))
        self._client = client or httpx.Client(timeout=self.timeout, follow_redirects=True,
                                             headers={"User-Agent": "Mozilla/5.0", "Referer": "https://gu.qq.com/"})
        self._request_lock = Lock()
        self._last_request = 0.0
        self._universe: list[Stock] | None = None
        self.last_errors: dict[str, str] = {}
        self.request_count = 0

    def _get(self, url: str, params: dict | None = None) -> httpx.Response:
        error = None
        for attempt in range(3):
            try:
                with self._request_lock:
                    delay = 0.10 - (time.monotonic() - self._last_request)
                    if delay > 0:
                        time.sleep(delay)
                    self._last_request = time.monotonic()
                response = self._client.get(url, params=params, timeout=self.timeout)
                self.request_count += 1
                response.raise_for_status()
                return response
            except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError) as exc:
                error = exc
                if isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code not in {408, 429, 500, 502, 503, 504}:
                    break
                if attempt < 2:
                    time.sleep(0.5 * 2 ** attempt)
        raise ProviderError(f"Tencent request failed after bounded retries: {error}") from error

    def get_stock_list(self, force_refresh: bool = False) -> list[Stock]:
        if self._universe is not None and not force_refresh:
            return [item.model_copy(deep=True) for item in self._universe]
        cache = self.storage_dir / "universe_development.json"
        if cache.exists() and not force_refresh:
            try:
                stored = json.loads(cache.read_text(encoding="utf-8"))
                acquired = datetime.fromisoformat(stored["acquired_at"])
                if now_shanghai() - acquired < timedelta(hours=24):
                    self._universe = [Stock.model_validate(item) for item in stored["stocks"]]
                    return [item.model_copy(deep=True) for item in self._universe]
            except (ValueError, KeyError, TypeError):
                log.warning("Invalid universe cache; refreshing", exc_info=True)
        stocks: dict[str, Stock] = {}
        received = now_shanghai()
        total, offset = 1, 0
        while offset < total:
            payload = self._get("https://proxy.finance.qq.com/cgi/cgi-bin/rank/hs/getBoardRankList",
                                {"_appver": "11.17.0", "board_code": "aStock", "sort_type": "price",
                                 "direct": "down", "offset": str(offset), "count": str(self.batch_size)}).json()
            try:
                total = int(payload["data"]["total"])
                rows = payload["data"]["rank_list"]
                if not rows or total <= 0 or total > 15000:
                    raise ValueError("Invalid universe pagination")
                for row in rows:
                    symbol = canonical_symbol(row["code"])
                    name = str(row["name"])
                    stocks[symbol] = Stock(symbol=symbol, code=symbol[2:], name=name,
                                           exchange=symbol[:2].upper(), is_st="ST" in name.upper(),
                                           status="delisted" if "退" in name else "active",
                                           metadata_as_of=received)
            except (KeyError, TypeError, ValueError) as exc:
                raise ProviderError(f"Invalid Tencent universe response at offset {offset}: {exc}") from exc
            offset += self.batch_size
        if len(stocks) < total:
            # Sorted ranks can move during pagination. Fail explicitly; never
            # silently call a partial subset the full-market universe.
            raise ProviderError(f"Universe changed during pagination: {len(stocks)}/{total}; retry after prices stabilize")
        if {stock.exchange for stock in stocks.values()} != {"SH", "SZ", "BJ"}:
            raise ProviderError("Universe does not cover all SH/SZ/BJ exchanges")
        self._universe = sorted(stocks.values(), key=lambda stock: stock.symbol)
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps({"acquired_at": received.isoformat(),
                                    "pit_security_master": False,
                                    "stocks": [stock.model_dump(mode="json") for stock in self._universe]},
                                   ensure_ascii=False), encoding="utf-8")
        return [item.model_copy(deep=True) for item in self._universe]

    def get_realtime_quotes(self, symbols: Sequence[str] | None = None) -> dict[str, Quote]:
        symbols = list(symbols) if symbols is not None else [stock.symbol for stock in self.get_stock_list()]
        normalized = list(dict.fromkeys(canonical_symbol(symbol) for symbol in symbols))
        quotes: dict[str, Quote] = {}
        self.last_errors = {}
        for index in range(0, len(normalized), self.batch_size):
            batch = normalized[index:index + self.batch_size]
            try:
                response = self._get("https://qt.gtimg.cn/q=" + ",".join(batch))
                parsed = parse_tencent_quotes(response.content.decode("gb18030", errors="replace"), now_shanghai())
                quotes.update({symbol: quote for symbol, quote in parsed.items() if symbol in batch})
                for symbol in batch:
                    if symbol not in quotes:
                        self.last_errors[symbol] = "Vendor omitted quote or quote schema invalid"
            except (ProviderError, ValueError) as exc:
                log.warning("Quote batch failed: %s", exc)
                # One exhausted bounded request opens this poll's circuit. A
                # network outage must not repeat 3 retries across 28 batches.
                self.last_errors.update({symbol: str(exc) for symbol in normalized[index:]})
                break
        return quotes

    def get_realtime_quote(self, symbol: str) -> Quote:
        canonical = canonical_symbol(symbol)
        return super().get_realtime_quote(canonical)

    def get_daily_bars(self, symbol: str, start_date=None, end_date=None, adjustment: str = "raw") -> pd.DataFrame:
        self.validate_adjustment(adjustment)
        symbol = canonical_symbol(symbol)
        start = pd.Timestamp(start_date or "2021-01-01").normalize()
        end = pd.Timestamp(end_date or now_shanghai().date()).normalize()
        if start > end:
            return empty_bars()
        rows = []
        # Bounded two-year chunks keep the 640-observation endpoint below its
        # truncation limit. Filter each chunk since Tencent may ignore start_date.
        for year in range(start.year, end.year + 1, 2):
            finish = min(pd.Timestamp(year=year + 1, month=12, day=31), end)
            payload = self._get("https://proxy.finance.qq.com/ifzqgtimg/appstock/app/newfqkline/get",
                                {"param": f"{symbol},day,{year}-01-01,{finish.date()},640,"}).json()
            try:
                series = payload["data"][symbol].get("day", [])
                if not isinstance(series, list):
                    raise ValueError("day is not an array")
                for row in series:
                    if len(row) < 9:
                        raise ValueError("Daily OHLCV/amount schema incomplete")
                    if float(row[5]) == 0:
                        continue  # vendor suspension placeholders are not trades
                    rows.append({"date": row[0], "open": row[1], "close": row[2], "high": row[3],
                                 "low": row[4], "volume": float(row[5]) * tencent_volume_multiplier(symbol),
                                 "amount": float(row[8]) * 10000})
            except (KeyError, TypeError, ValueError) as exc:
                raise ProviderError(f"Invalid historical response for {symbol}: {exc}") from exc
        if not rows:
            return empty_bars()
        frame = normalize_bars(pd.DataFrame(rows))
        frame = frame[(frame.index >= start) & (frame.index <= end)]
        # Zero turnover sessions are not fabricated stock bars. Some vendors emit
        # placeholders for suspension; remove them, preserving the gap.
        frame = frame[frame.volume > 0]
        now = pd.Timestamp(now_shanghai())
        frame = frame[frame.available_at <= now]
        active = (frame.volume > 0) & (frame.amount > 0)
        average_price = frame.amount / frame.volume
        # Public endpoints round amounts/volumes. Wide 5% tolerance also allows
        # closing/block transactions; a factor-100 unit mismatch must fail closed.
        mismatch = active & ((average_price < frame.low * 0.95) | (average_price > frame.high * 1.05))
        if mismatch.any():
            raise ProviderError(f"Price/turnover units inconsistent for {symbol} on {frame.index[mismatch][0].date()}")
        frame.attrs["provider"] = self.name
        return frame

    def close(self) -> None:
        self._client.close()
