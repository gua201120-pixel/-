"""A session draft shared by every page; saved strategy versions stay immutable."""
from __future__ import annotations

import json
from typing import Any

import streamlit as st

from ashare.models import now_shanghai
from ashare.strategies.schema import Rule, RuleGroup, Strategy

PARAMETER_LABELS = {
    "fast_period": "短期均线周期", "medium_period": "中期均线周期", "slow_period": "长期均线周期",
    "period": "均线周期", "signal_period": "信号线周期", "slope_lookback_weeks": "斜率比较间隔（周）",
    "lookback_weeks": "高点回看周期（周）", "ma_period": "趋势均线周期（周）",
    "zigzag_threshold": "转折确认幅度（%）", "max_ratio": "最高 / 最低价格比上限",
    "min_drawdown": "最小回调幅度（%）", "max_drawdown": "最大回调幅度（%）",
    "minimum_ratio": "成交量倍数下限", "lookback_days": "回看周期（日）",
    "maximum_return": "涨幅上限（%）",
}
PERCENT_PARAMETERS = {"zigzag_threshold", "min_drawdown", "max_drawdown", "maximum_return"}
PERIODS = {"daily": "日", "weekly": "周", "monthly": "月", "mixed": "多周期", "event": "事件"}


def rule_paths(group: RuleGroup, prefix: tuple[int, ...] = (), active: bool = True):
    for i, rule in enumerate(group.rules):
        path = prefix + (i,)
        if isinstance(rule, RuleGroup):
            yield from rule_paths(rule, path, active and group.enabled)
        else:
            yield path, rule, active and group.enabled


def replace_rule(strategy: Strategy, path: tuple[int, ...], replacement: Rule, registry) -> Strategy:
    """Validate both params and the complete tree before changing the session draft."""
    candidate = strategy.model_copy(deep=True)
    factor = registry.get(replacement.factor, replacement.factor_version)
    replacement = replacement.model_copy(deep=True)
    replacement.params = factor.Parameters.model_validate({**factor.metadata.default_parameters, **replacement.params}).model_dump()
    group = candidate.rules
    for index in path[:-1]:
        group = group.rules[index]
        if not isinstance(group, RuleGroup):
            raise ValueError("规则路径无效，请重新选择策略")
    group.rules[path[-1]] = replacement
    return Strategy.model_validate(candidate.model_dump())


def active_strategy(service: Any) -> Strategy:
    return st.session_state.get("workspace_draft") or service.strategies.list()[0]


def run_screen(service: Any, strategy: Strategy | None = None, *, cached: bool = False):
    from ashare.ui.common import latest_results, remember_results, selected_symbols
    strategy = strategy or active_strategy(service)
    previous = latest_results(service)
    symbols = [r.symbol for r in previous] if cached and previous else selected_symbols()
    if symbols == []:
        raise ValueError("请先选择股票")
    results = service.screen(strategy, symbols=symbols, refresh_quotes=not cached,
                             persist=not st.session_state.get("workspace_dirty", False))
    remember_results(service, results)
    st.session_state["result_strategy_snapshot"] = strategy.model_dump_json()
    return results


def _next_version(service: Any, strategy: Strategy) -> str:
    used = {s.version for s in service.strategies.list() if s.strategy_id == strategy.strategy_id}
    prefix, _, last = strategy.version.rpartition(".")
    number = int(last) + 1 if last.isdigit() else 1
    candidate = f"{prefix}.{number}" if prefix else str(number)
    while candidate in used:
        number += 1
        candidate = f"{prefix}.{number}" if prefix else str(number)
    return candidate


def factor_panel(service: Any) -> None:
    st.subheader("我的筛选因子")
    strategies = service.strategies.list()
    options = {f"{s.strategy_id}@{s.version}": s for s in strategies}
    pending = st.session_state.pop("pending_strategy_selection", None)
    if pending in options:
        st.session_state["workspace_strategy"] = pending
    if st.session_state.get("workspace_strategy") not in options:
        st.session_state.pop("workspace_strategy", None)
    selected = st.selectbox("使用策略", list(options), format_func=lambda key: f"{options[key].name} · {options[key].version}", key="workspace_strategy")
    # A new service (e.g. after switching provider) must discard the old session draft.
    token = (selected, id(service))
    if st.session_state.get("workspace_base_token") != token:
        st.session_state["workspace_base_token"] = token
        st.session_state["workspace_draft"] = options[selected].model_copy(deep=True)
        st.session_state["workspace_dirty"] = False
        st.session_state["workspace_revision"] = 0
        st.session_state["workspace_open_rule"] = None
    base, draft = options[selected], active_strategy(service)
    dirty = st.session_state.get("workspace_dirty", False)
    st.caption(f"{'● 未保存的修改' if dirty else '已保存版本'} · {len(draft.rules.leaves())} 个启用条件 · {draft.rules.logic} 组合")
    st.caption("点开因子即可修改参数、启用状态和筛选条件。")
    if message := st.session_state.pop("workspace_message", None):
        st.success(message)
    if message := st.session_state.pop("workspace_error", None):
        st.error(message)
    revision = st.session_state.get("workspace_revision", 0)
    for path, rule, parent_active in rule_paths(draft.rules):
        factor = service.factors.get(rule.factor, rule.factor_version)
        metadata = factor.metadata
        label = f"{'●' if rule.enabled and parent_active else '○'} {metadata.name}"
        path_key = "_".join(map(str, path))
        key = f"factor_edit_{selected}_{revision}_{path_key}"
        with st.expander(label, expanded=st.session_state.get("workspace_open_rule") == path_key):
            st.caption(f"{PERIODS.get(metadata.timeframe, metadata.timeframe)}线 / v{metadata.version}")
            st.caption(metadata.description)
            if not parent_active:
                st.info("所属规则组已关闭，请在策略构建页启用该组。")
            with st.form(key):
                enabled = st.checkbox("启用这个因子", value=rule.enabled, key=key + "_enabled")
                values = {**metadata.default_parameters, **rule.params}
                params = {}
                for name, value in values.items():
                    title = PARAMETER_LABELS.get(name, name)
                    if metadata.factor_id == "daily_macd_above_zero":
                        title = {"fast_period": "快线 EMA 周期", "slow_period": "慢线 EMA 周期", "signal_period": "信号线周期"}.get(name, title)
                    if type(value) is bool:
                        params[name] = st.checkbox(title, value=value, key=key + "_" + name)
                    elif type(value) in (float, int):
                        scale = 100 if name in PERCENT_PARAMETERS else 1
                        display_value = float(value * scale) if type(value) is float else value
                        params[name] = st.number_input(title, value=display_value, step=1 if type(value) is int else 0.01,
                                                       format="%d" if type(value) is int else "%.4f", key=key + "_" + name) / scale
                        if type(value) is int:
                            params[name] = int(params[name])
                    else:
                        params[name] = st.text_input(title, value=value if isinstance(value, str) else json.dumps(value, ensure_ascii=False), key=key + "_" + name)
                        if not isinstance(value, str):
                            # Parse on submission below so incomplete typing never changes active rules.
                            params[name] = ("__json__", params[name])
                if rule.field == "passed" and rule.operator in ("==", "!="):
                    expected = st.selectbox("筛选条件", [True, False], index=0 if rule.value else 1,
                                            format_func=lambda x: "因子判定为满足" if x else "因子判定为不满足", key=key + "_expect")
                    op, field, threshold = rule.operator, rule.field, expected
                    if op == "!=":
                        st.caption("当前规则为不等于（!=），可在高级策略构建中修改。")
                else:
                    field = "value"
                    op = st.selectbox("比较方式", ["==", "!=", ">", ">=", "<", "<=", "between", "not_between", "in", "not_in"],
                                      index=["==", "!=", ">", ">=", "<", "<=", "between", "not_between", "in", "not_in"].index(rule.operator), key=key + "_op")
                    threshold = st.text_input("比较值（数字 / JSON）", value=json.dumps(rule.value, ensure_ascii=False), key=key + "_threshold")
                left, right = st.columns(2)
                apply = left.form_submit_button("应用修改", width="stretch")
                recalc = right.form_submit_button("应用并重算", type="primary", width="stretch")
            if apply or recalc:
                try:
                    parsed = {name: json.loads(value[1]) if isinstance(value, tuple) else value for name, value in params.items()}
                    replacement = Rule(factor=rule.factor, factor_version=rule.factor_version, enabled=enabled,
                                       params=parsed, field=field, operator=op, value=json.loads(threshold) if field == "value" else threshold)
                    changed = replace_rule(draft, path, replacement, service.factors)
                    new_revision = revision + 1
                    changed.version = f"{base.version}-draft{new_revision}"
                    changed.updated_at = now_shanghai()
                    st.session_state.update(workspace_draft=changed, workspace_revision=new_revision,
                                            workspace_dirty=True, workspace_open_rule=path_key)
                    st.session_state["workspace_message"] = f"已应用「{metadata.name}」的修改"
                    if recalc:
                        from ashare.ui.common import latest_results
                        if latest_results(service):
                            try:
                                run_screen(service, changed, cached=True)
                                st.session_state["workspace_message"] += "，已用缓存行情重算"
                            except Exception as exc:
                                st.session_state["workspace_error"] = f"参数已应用，重算失败：{exc}"
                        else:
                            st.session_state["workspace_message"] += "；请先在主面板运行一次筛选"
                    st.rerun()
                except Exception as exc:
                    st.error(f"未应用：{exc}")
    st.caption("应用修改只影响当前草稿；新版本保存后才会进入策略库。重算使用最近缓存行情。")
    if dirty:
        if st.button("撤销未保存的修改", width="stretch"):
            st.session_state["workspace_base_token"] = None
            st.rerun()
        with st.form("save_workspace_" + selected):
            version = st.text_input("保存为版本", value=_next_version(service, base))
            save = st.form_submit_button("保存当前修改为新版本", type="primary", width="stretch")
        if save:
            try:
                candidate = draft.model_copy(deep=True)
                candidate.version = version.strip()
                candidate.created_at = candidate.updated_at = now_shanghai()
                saved = service.strategies.save(candidate)
                st.session_state["pending_strategy_selection"] = f"{saved.strategy_id}@{saved.version}"
                st.session_state["workspace_message"] = f"已保存 v{saved.version}，原版本保留"
                st.rerun()
            except Exception as exc:
                st.error(f"保存失败：{exc}")
