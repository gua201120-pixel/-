"""Plotly OHLC and volume charts, derived from the exact factor context."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def candle_chart(bars: pd.DataFrame, title: str) -> go.Figure:
    figure = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.03, row_heights=[0.78, 0.22])
    if bars.empty:
        return figure
    view = bars.tail(180)
    axis = pd.to_datetime(view.index)
    figure.add_trace(go.Candlestick(x=axis, open=view["open"], high=view["high"], low=view["low"], close=view["close"], name="K 线", increasing_line_color="#cb664d", decreasing_line_color="#1e9c89"), row=1, col=1)
    for period, color in [(5, "#cf9e39"), (10, "#728ad5"), (20, "#a989b5")]:
        average = bars["close"].rolling(period).mean().reindex(view.index)
        figure.add_trace(go.Scatter(x=axis, y=average, mode="lines", name=f"MA{period}", line={"color": color, "width": 1.4}), row=1, col=1)
    if "volume" in view:
        colors = ["#cb664d" if close >= opening else "#1e9c89" for close, opening in zip(view["close"], view["open"])]
        figure.add_trace(go.Bar(x=axis, y=view["volume"], name="成交量（股）", marker_color=colors, opacity=0.65), row=2, col=1)
    figure.update_layout(title={"text": title, "font": {"size": 15}}, height=560, margin={"t": 45, "l": 10, "r": 10, "b": 10}, xaxis_rangeslider_visible=False, legend={"orientation": "h", "y": 1.10}, hovermode="x unified", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
    figure.update_xaxes(type="category", nticks=8, showgrid=False)
    figure.update_yaxes(gridcolor="rgba(130,140,150,.15)")
    return figure
