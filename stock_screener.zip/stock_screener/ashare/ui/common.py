"""Shared presentation helpers. No provider access or factor calculations."""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Iterable

import pandas as pd
import streamlit as st

from ashare.models import SHANGHAI, ScreenResult, now_shanghai

PAGES = {
    "总览 · Dashboard": "dashboard",
    "因子库 · Factor Library": "factors",
    "策略构建 · Strategy Builder": "strategies",
    "实时筛选 · Realtime Screener": "realtime",
    "个股详情 · Stock Detail": "detail",
    "设置 · Settings": "settings",
}

CSS = """
<style>
:root { --ink:#172a35; --muted:#63717a; --accent:#cc702c; }
.stApp { font-family: 'DM Sans', 'Microsoft YaHei', sans-serif; }
.block-container { max-width:1800px; padding:3.6rem 2rem 3rem; }
[data-testid="stSidebar"] { border-right:1px solid rgba(120,130,140,.18); }
[data-testid="stSidebar"] .block-container { padding-top:2rem; }
h1 { font-size:2.05rem !important; font-weight:650 !important; letter-spacing:-.05em; padding-bottom:.25rem !important; }
h2 { font-size:1.25rem !important; font-weight:600 !important; }
h3 { font-size:1.02rem !important; }
[data-testid="stMetric"] { border:1px solid rgba(120,130,140,.20); padding:1rem 1.15rem; border-radius:10px; }
[data-testid="stMetricValue"] { font-size:1.8rem; }
[data-testid="stMetricLabel"] { color:#7b8994; font-size:.82rem; }
.eyebrow { color:#af703f; font-size:.73rem; letter-spacing:.18em; text-transform:uppercase; font-weight:650; }
.brand { font-size:1.3rem; font-weight:700; letter-spacing:-.04em; margin:.2rem 0; }
.subbrand { color:#7b8994; font-size:.76rem; line-height:1.65; }
.hero-subtitle { color:#7b8994; font-size:.92rem; margin:0 0 1.35rem; }
.section-caption { color:#7b8994; font-size:.79rem; }
div[data-testid="stVerticalBlockBorderWrapper"] { border-radius:12px; }
.stButton > button { border-radius:7px; }
footer { visibility:hidden; }
[data-testid="stSidebar"] { min-width:335px; max-width:335px; }
[data-testid="stSidebar"] h3 { font-size:1.14rem !important; }
[data-testid="stSidebar"] hr { margin:.7rem 0; }
[data-testid="stSidebar"] [data-testid="stExpander"] { background:rgba(255,255,255,.45); border-color:rgba(120,130,140,.16); }
.stock-heading { display:flex; align-items:center; justify-content:space-between; gap:12px; margin:2px 0 12px; flex-wrap:wrap; }
.stock-title { color:#203741; font-weight:700; font-size:1.28rem; }
.stock-code { color:#778790; font-size:.8rem; margin-left:8px; }
.stock-price { font-weight:650; font-size:1.18rem; margin-right:12px; }
.status-pill { font-size:.78rem; padding:5px 10px; border-radius:6px; font-weight:650; }
.empty-results { padding:55px 28px; text-align:center; border:1px dashed #cbd5d9; border-radius:12px; color:#47616c; }
.empty-results b { font-size:1.2rem; }
.empty-results p { font-size:.88rem; line-height:1.85; color:#7b8994; }
@media (max-width:900px) { .block-container { padding-left:1rem; padding-right:1rem; } }
</style>
"""


def stamp(value: Any) -> str:
    if value is None or value == "":
        return "未知 / 未提供"
    try:
        parsed = pd.Timestamp(value)
        if pd.isna(parsed):
            return "未知 / 未提供"
        if parsed.tzinfo is not None:
            parsed = parsed.tz_convert(SHANGHAI)
        return parsed.strftime("%Y-%m-%d %H:%M:%S") + " CST"
    except (TypeError, ValueError):
        return str(value)


def scalar(value: Any) -> Any:
    if isinstance(value, (datetime, pd.Timestamp)):
        return stamp(value)
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return value


def results_frame(results: Iterable[ScreenResult], detailed: bool = False) -> pd.DataFrame:
    """Keep errors distinct and expose all raw factor fields in the expanded table."""
    rows: list[dict[str, Any]] = []
    for result in results:
        row = {
            "Symbol": result.symbol,
            "Name": result.name,
            "Latest Price": result.latest_price,
            "Result": result.status,
            "Quote Timestamp": stamp(result.quote_timestamp),
            "Local Receive Time": stamp(result.received_at),
            "Failed Factors": ", ".join(result.failed_factors),
            "Reason": result.reason,
            "Strategy Version": result.strategy_version,
        }
        if detailed:
            for key, factor in result.factors.items():
                prefix = key
                row[f"{prefix}.value"] = factor.value
                row[f"{prefix}.status"] = factor.status
                row[f"{prefix}.timestamp"] = stamp(factor.timestamp)
                row[f"{prefix}.data_timestamp"] = stamp(factor.data_timestamp)
                row[f"{prefix}.reason"] = factor.reason
                row[f"{prefix}.parameters"] = scalar(factor.parameters)
                row[f"{prefix}.adjustment"] = factor.adjustment
                row[f"{prefix}.version"] = factor.version
                for detail_key, value in factor.details.items():
                    row[f"{prefix}.{detail_key}"] = scalar(value)
        rows.append(row)
    if not rows:
        return pd.DataFrame()
    frame = pd.DataFrame(rows)
    rank = {"PASS": 0, "FAIL": 1, "NOT_ENOUGH_DATA": 2, "SUSPENDED": 3, "STALE": 4, "DATA_ERROR": 5, "EXCLUDED": 6}
    frame["_rank"] = frame["Result"].map(rank).fillna(99)
    return frame.sort_values(["_rank", "Symbol"], kind="stable").drop(columns="_rank").reset_index(drop=True)


def latest_results(service: Any) -> list[ScreenResult]:
    return list(st.session_state.get("screen_results", getattr(service, "last_results", []) or []))


def remember_results(service: Any, results: list[ScreenResult]) -> None:
    st.session_state["screen_results"] = results
    st.session_state["ui_last_update"] = getattr(service, "last_update", None) or now_shanghai()


def page_heading(kicker: str, title: str, subtitle: str) -> None:
    st.markdown(f'<div class="eyebrow">{kicker}</div>', unsafe_allow_html=True)
    st.title(title)
    st.markdown(f'<div class="hero-subtitle">{subtitle}</div>', unsafe_allow_html=True)


def quality_notice(service: Any) -> None:
    quality = getattr(service.provider, "quality", "unknown")
    if quality == "simulated":
        st.warning("模拟数据 · SIMULATED — 仅用于验证系统流程，所有价格与筛选结果均非真实市场行情。", icon="🧪")
    elif quality == "realtime":
        st.info("供应商标记为实时数据；请同时核对交易所时间、接收时间与延迟。", icon="ℹ️")
    elif quality == "delayed":
        st.warning("延迟行情 · DELAYED — 当前数据源不是经过认证的实时行情。", icon="⏱️")
    else:
        st.info("开发行情 · 延迟未认证。供应商未提供的行情时间或延迟显示为未知，不能据此确认交易所实时性。", icon="ℹ️")


def market_text(service: Any) -> str:
    try:
        status = service.calendar.market_status(now_shanghai())
        raw = str(status.get("status", "UNKNOWN")) if isinstance(status, dict) else str(getattr(status, "value", status))
        return {"OPEN": "交易中", "LUNCH_BREAK": "午间休市", "PRE_OPEN": "未开盘", "CLOSED": "已收盘", "NON_TRADING_DAY": "非交易日", "UNKNOWN": "日历未知"}.get(raw, raw)
    except Exception:
        return "日历未知"


def strategy_picker(service: Any, key: str) -> Any:
    if key in {"dashboard_strategy", "realtime_strategy", "detail_strategy"} and "workspace_draft" in st.session_state:
        from ashare.ui.workspace import active_strategy
        strategy = active_strategy(service)
        st.caption(f"当前策略：{strategy.name} · {strategy.version}　｜　在左侧调整因子")
        return strategy
    strategies = service.strategies.list()
    if not strategies:
        st.error("策略库为空，请在策略构建页创建策略。")
        return None
    labels = {f"{s.name} · v{s.version} · {s.strategy_id}": s for s in strategies}
    selection = st.selectbox("当前策略 / Strategy", list(labels), key=key)
    return labels[selection]


def selected_symbols() -> list[str] | None:
    scope = st.session_state.get("screen_scope", "全部 A 股")
    if scope == "全部 A 股":
        return None
    return list(st.session_state.get("watchlist", []))


def show_freshness(results: list[ScreenResult]) -> None:
    quote_times = [r.quote_timestamp for r in results if r.quote_timestamp is not None]
    receive_times = [r.received_at for r in results if r.received_at is not None]
    reported = [r.metadata.get("reported_latency_seconds") for r in results if r.metadata.get("reported_latency_seconds") is not None]
    measured = [(r.received_at - r.quote_timestamp).total_seconds() for r in results if r.received_at and r.quote_timestamp]
    columns = st.columns(3)
    columns[0].caption("交易所 / Quote Timestamp（最新）")
    columns[0].write(stamp(max(quote_times) if quote_times else None))
    columns[1].caption("本地接收时间（最新）")
    columns[1].write(stamp(max(receive_times) if receive_times else None))
    columns[2].caption("延迟 · Reported / Observed")
    if reported:
        columns[2].write(f"供应商报告最高 {max(reported):.1f} 秒")
    elif measured:
        columns[2].write(f"接收 − 行情时间：最高 {max(measured):.1f} 秒")
    else:
        columns[2].write("未知 / 未提供")
    if measured:
        st.caption("时间差受休市、源时间精度与时钟差影响，不等于网络延迟。")
    unknown = sum(r.quote_timestamp is None for r in results)
    if unknown:
        st.caption(f"{unknown} / {len(results)} 条结果缺少可验证的行情时间。")


def show_results(service: Any) -> None:
    from ashare.ui.results import show_results as render
    render(service)

