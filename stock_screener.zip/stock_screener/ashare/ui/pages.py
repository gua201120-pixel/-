"""The six research-console pages. Business logic is delegated to ResearchService."""
from __future__ import annotations

import json
import logging
from typing import Any

import pandas as pd
import streamlit as st

from ashare.models import now_shanghai
from ashare.settings import Settings
from ashare.strategies.schema import Strategy
from ashare.ui.charts import candle_chart
from ashare.ui.common import (
    latest_results, market_text, page_heading, quality_notice, remember_results,
    selected_symbols, show_freshness, show_results, stamp, strategy_picker,
)


def _universe_controls(service: Any) -> None:
    """Explicit downloads: page reruns never trigger historical warm-up."""
    left, right = st.columns([1, 3])
    with left:
        if st.button("加载 / 更新股票池", width="stretch"):
            try:
                with st.spinner("读取供应商股票池…"):
                    st.session_state["stock_universe"] = service.universe(refresh=True)
                st.success(f"股票池已加载：{len(st.session_state['stock_universe']):,} 只")
            except Exception as exc:
                st.error(f"股票池加载失败：{exc}")
    with right:
        st.caption("股票池加载与历史数据准备均由你明确启动；全市场首次下载可能需要较长时间，成功的数据将保存在本地。")
    universe = st.session_state.get("stock_universe", [])
    if not universe:
        return
    st.radio("筛选范围 / Universe", ["全部 A 股", "自选股票"], horizontal=True, key="screen_scope")
    if st.session_state["screen_scope"] == "自选股票":
        labels = {stock.symbol: f"{stock.symbol} · {stock.name}" for stock in universe}
        st.multiselect("自选股票（没有隐藏数量上限）", list(labels), format_func=labels.get, key="watchlist")
    symbols = selected_symbols()
    count = len(universe) if symbols is None else len(symbols)
    st.caption(f"当前范围：{count:,} 只。基础过滤由 Settings 控制，未作为策略条件加入。")
    if st.button("准备 / 增量更新历史数据", disabled=count == 0, type="primary"):
        bar = st.progress(0.0, text=f"准备 {count:,} 只股票的历史数据…")
        progress_count = [0]

        def progress(*args: Any, **kwargs: Any) -> None:
            # Providers may report (completed,total,symbol) or just symbol.
            progress_count[0] += 1
            if len(args) >= 2 and isinstance(args[0], int) and isinstance(args[1], int):
                done, total = args[:2]
            else:
                done, total = progress_count[0], count
            bar.progress(min(1.0, done / max(total, 1)), text=f"准备历史数据：{done:,} / {total:,}")

        try:
            outcome = service.warm_history(symbols=symbols, progress=progress)
            st.session_state["last_warmup"] = outcome
            bar.progress(1.0, text="历史数据任务完成")
            if outcome.get("errors"):
                st.warning(f"历史数据完成 {outcome.get('success', 0):,} / {outcome.get('total', count):,} 只；部分股票失败，详见下方 errors。成功数据已缓存，可继续筛选。")
            else:
                st.success("历史数据任务已完成，可以运行筛选。")
            st.json(outcome)
        except Exception as exc:
            bar.empty()
            st.error(f"历史数据更新失败：{exc}")


def dashboard(service: Any) -> None:
    from ashare.ui.workspace import active_strategy, run_screen
    page_heading("STOCK SCREENING WORKSPACE", "股票筛选工作台", "先看筛选结果，再看每项依据。左侧随时调整因子，应用后立即重新计算。")
    strategy = active_strategy(service)
    with st.expander("股票池与数据", expanded=not bool(st.session_state.get("stock_universe"))):
        _universe_controls(service)
        universe = st.session_state.get("stock_universe", [])
        if universe:
            st.caption(f"已加载 {len(universe):,} 只股票；当前使用 {service.provider.name}，{service.settings.adjustment_mode.upper()} 价格口径。")
    controls = st.columns([2.3, 1])
    with controls[0]:
        st.markdown("**" + strategy.name + "**")
        st.caption(f"{len(strategy.rules.leaves())} 个启用条件 · {strategy.rules.logic} · {strategy.version} · {market_text(service)}")
    ready = bool(st.session_state.get("stock_universe")) and selected_symbols() != []
    if controls[1].button("运行筛选", type="primary", width="stretch", disabled=not ready):
        try:
            with st.spinner("批量获取行情并评估策略…"):
                run_screen(service, strategy)
        except Exception as exc:
            st.error(f"筛选失败：{exc}")
    quality_notice(service)
    show_results(service)


def factors_page(service: Any) -> None:
    page_heading("FACTOR LIBRARY", "因子库", "独立定义、明确参数、保留原始值。每个因子均可复用于不同策略。")
    metadata = service.factors.list()
    cols = st.columns(3)
    cols[0].metric("已注册因子", len(metadata))
    cols[1].metric("支持实时计算", sum(f.supports_realtime for f in metadata))
    cols[2].metric("分类", len({f.category for f in metadata}))
    search = st.text_input("搜索因子", placeholder="输入名称、ID、分类或周期…")
    selected = [f for f in metadata if search.lower() in f"{f.factor_id} {f.name} {f.category} {f.timeframe}".lower()]
    summary = [{"ID": f.factor_id, "名称": f.name, "分类": f.category, "周期": f.timeframe, "输出类型": f.output_type, "实时支持": f.supports_realtime, "版本": f.version} for f in selected]
    st.dataframe(pd.DataFrame(summary), hide_index=True, width="stretch")
    for factor in selected:
        with st.expander(f"{factor.name}  ·  {factor.factor_id}  ·  v{factor.version}"):
            st.write(factor.description)
            st.caption(f"{factor.category} / {factor.timeframe} · {factor.output_type} · supports_realtime={factor.supports_realtime}")
            st.write("默认参数")
            st.json(factor.default_parameters)
            st.caption(f"创建：{stamp(factor.created_at)} · 更新：{stamp(factor.updated_at)}")
    st.info("新增因子：继承 BaseFactor，实现 _calculate(context, params) 并定义 Parameters，注册到 FactorRegistry。保留基类 calculate 的参数校验与异常隔离。无需修改筛选核心；参数修改请保存为新的策略版本。")


def _parse_json_value(value: Any, label: str) -> Any:
    if value is None or (isinstance(value, float) and pd.isna(value)) or str(value).strip() == "":
        raise ValueError(f"{label} 不能为空；布尔值用 true / false，字符串需要双引号。")
    try:
        return json.loads(str(value))
    except (TypeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{label} 必须是有效 JSON 值，例如 true、1.5、[1, 2] 或 \"uptrend\"。") from exc


def strategies_page(service: Any) -> None:
    page_heading("STRATEGY WORKBENCH", "策略构建", "组合已有因子，调整规则与参数，将每次修改保存为独立版本。")
    strategy = strategy_picker(service, "builder_strategy")
    if strategy is None:
        return
    original = strategy.model_dump(mode="json")
    nested = any("rules" in rule for rule in original["rules"]["rules"])
    st.caption(f"当前快照：{strategy.strategy_id} / v{strategy.version} · 创建于 {stamp(strategy.created_at)}")
    mode = st.radio("编辑方式", ["JSON（支持嵌套 AND / OR）"] if nested else ["规则表格", "JSON（支持嵌套 AND / OR）"], horizontal=True)
    factor_ids = sorted(f.factor_id for f in service.factors.list())
    with st.form(f"strategy_editor_{strategy.strategy_id}_{strategy.version}"):
        columns = st.columns([2, 2, 1, 1])
        name = columns[0].text_input("策略名称", value=strategy.name)
        strategy_id = columns[1].text_input("Strategy ID", value=strategy.strategy_id, help="保留 ID 以保存新版本；修改 ID 可另建策略。")
        existing_versions = {item.version for item in service.strategies.list() if item.strategy_id == strategy.strategy_id}
        version_parts = strategy.version.split(".")
        if version_parts[-1].isdigit():
            next_number = int(version_parts[-1]) + 1
            version_parts[-1] = str(next_number)
            next_version = ".".join(version_parts)
            while next_version in existing_versions:
                next_number += 1
                version_parts[-1] = str(next_number)
                next_version = ".".join(version_parts)
        else:
            next_version = strategy.version + "_new"
        version = columns[2].text_input("新版本", value=next_version)
        logic = columns[3].selectbox("组合逻辑", ["AND", "OR"], index=0 if original["rules"]["logic"] == "AND" else 1)
        if mode == "规则表格":
            rows = [{"enabled": r.get("enabled", True), "factor": r["factor"], "factor_version": r.get("factor_version", "1.0.0"), "field": r.get("field", "passed"), "operator": r["operator"], "value": json.dumps(r.get("value"), ensure_ascii=False), "params": json.dumps(r.get("params", {}), ensure_ascii=False)} for r in original["rules"]["rules"]]
            edited = st.data_editor(pd.DataFrame(rows), hide_index=True, width="stretch", num_rows="dynamic", column_config={
                "enabled": st.column_config.CheckboxColumn("Enabled", default=True),
                "factor": st.column_config.SelectboxColumn("Factor", options=factor_ids, required=True, width="large"),
                "factor_version": st.column_config.TextColumn("Factor version", default="1.0.0", required=True),
                "field": st.column_config.SelectboxColumn("输出字段", options=["passed", "value"], default="passed", required=True),
                "operator": st.column_config.SelectboxColumn("Operator", options=["==", "!=", ">", ">=", "<", "<=", "between", "not_between", "in", "not_in"], default="==", required=True),
                "value": st.column_config.TextColumn("Value（JSON）", default="true", required=True),
                "params": st.column_config.TextColumn("Parameters（JSON）", default="{}", width="large"),
            }, key=f"rules_{strategy.strategy_id}_{strategy.version}")
            st.caption('Value 示例：true、1.5、[0.05, 0.25]、"uptrend"。Parameters 示例：{"minimum_ratio": 1.5}。可添加、删除或关闭规则。')
            raw_json = None
        else:
            edited = None
            raw_json = st.text_area("完整 Strategy JSON", value=strategy.model_dump_json(indent=2), height=510)
            st.caption("JSON 模式以 JSON 中的 rules 为准；上方名称与 ID 仍用于保存。支持任意层级 AND / OR。")
        submitted = st.form_submit_button("保存为新版本", type="primary")
    if submitted:
        try:
            data = json.loads(raw_json) if raw_json is not None else dict(original)
            data.update({"strategy_id": strategy_id.strip(), "name": name.strip(), "version": version.strip(), "created_at": now_shanghai(), "updated_at": now_shanghai()})
            if edited is not None:
                rules = []
                for index, row in enumerate(edited.to_dict(orient="records"), start=1):
                    if not row.get("factor"):
                        raise ValueError(f"第 {index} 行请选择 Factor。")
                    params = _parse_json_value(row.get("params") or "{}", f"第 {index} 行 Parameters")
                    if not isinstance(params, dict):
                        raise ValueError(f"第 {index} 行 Parameters 必须是 JSON 对象。")
                    rules.append({"factor": row["factor"], "factor_version": row.get("factor_version") or "1.0.0", "field": row.get("field") or "passed", "operator": row.get("operator") or "==", "value": _parse_json_value(row.get("value"), f"第 {index} 行 Value"), "params": params, "enabled": bool(row.get("enabled", True))})
                data["rules"] = {"logic": logic, "rules": rules}
            candidate = Strategy.model_validate(data)
            saved = service.strategies.save(candidate)
            st.success(f"已保存：{saved.name} / v{saved.version}。已有版本保留。切换策略选择框即可使用新版本。")
            st.session_state["last_saved_strategy"] = saved.model_dump(mode="json")
        except Exception as exc:
            st.error(f"策略未保存：{exc}")
    st.download_button("下载当前策略 JSON", strategy.model_dump_json(indent=2), f"{strategy.strategy_id}_v{strategy.version}.json", "application/json")
    with st.expander("版本库"):
        st.dataframe(pd.DataFrame([{"ID": s.strategy_id, "名称": s.name, "版本": s.version, "创建": stamp(s.created_at), "更新": stamp(s.updated_at)} for s in service.strategies.list()]), hide_index=True, width="stretch")


def realtime_page(service: Any) -> None:
    from ashare.ui.workspace import run_screen as run_workspace_screen
    page_heading("LIVE SCREENING", "实时筛选", "批量行情 → 当前日 / 周 / 月线 → 因子结果 → 策略判断。")
    quality_notice(service)
    strategy = strategy_picker(service, "realtime_strategy")
    if strategy is None:
        return
    with st.expander("股票池与历史数据准备", expanded=not bool(st.session_state.get("stock_universe"))):
        _universe_controls(service)
    interval = st.number_input("刷新间隔（秒）", min_value=1.0, value=float(service.settings.realtime_refresh_seconds), step=1.0, key="refresh_seconds")
    effective_interval = max(interval, float(getattr(service.provider, "min_poll_seconds", interval)))
    service.settings.realtime_refresh_seconds = interval
    st.caption(f"计划刷新 {interval:g} 秒；供应商最小间隔约束后 {effective_interval:g} 秒。实际耗时取决于市场范围、网络及计算量。")
    columns = st.columns([1, 1, 1, 2])
    ready = bool(st.session_state.get("stock_universe")) and selected_symbols() != []
    if columns[0].button("▶ 开始定时扫描", disabled=service.scanner.running or not ready, type="primary", width="stretch"):
        service.scanner.start()
        st.rerun()
    if columns[1].button("■ 停止", disabled=not service.scanner.running, width="stretch"):
        service.scanner.stop()
        st.rerun()
    if columns[2].button("运行一次", disabled=not ready, width="stretch"):
        try:
            with st.spinner("批量刷新并计算…"):
                run_workspace_screen(service, strategy)
        except Exception as exc:
            st.error(f"本次扫描失败：{exc}")
    columns[3].write(f"{'● 扫描已启动' if service.scanner.running else '○ 扫描已停止'} · {market_text(service)}")
    st.caption("定时扫描在此页面保持打开时运行；真实行情非交易时段自动跳过轮询。模拟模式可随时演示。休市时可手动运行一次。")

    @st.fragment(run_every=effective_interval if service.scanner.running else None)
    def render_live() -> None:
        if service.scanner.running:
            try:
                new_results = service.scanner.tick(strategy, symbols=selected_symbols())
                if new_results is not None:
                    remember_results(service, new_results)
                    st.session_state["result_strategy_snapshot"] = strategy.model_dump_json()
            except Exception as exc:
                st.error(f"实时扫描暂未更新：{exc}")
        st.caption("最近完成：" + stamp(st.session_state.get("ui_last_update", getattr(service, "last_update", None))))
        show_results(service)

    render_live()


def stock_detail(service: Any) -> None:
    page_heading("STOCK RESEARCH", "个股详情", "查看本地行情上下文的 K 线、当前未完成周期及每一项判断依据。")
    quality_notice(service)
    universe = st.session_state.get("stock_universe", [])
    results = latest_results(service)
    choices = {stock.symbol: f"{stock.symbol} · {stock.name}" for stock in universe}
    choices.update({result.symbol: f"{result.symbol} · {result.name}" for result in results})
    if not choices:
        st.info("请先在总览或实时筛选页加载股票池。")
        return
    columns = st.columns([1, 2])
    symbol = columns[0].selectbox("股票", list(choices), format_func=choices.get)
    with columns[1]:
        strategy = strategy_picker(service, "detail_strategy")
    if strategy is None:
        return
    if st.button("准备该股历史数据并刷新因子", type="primary"):
        try:
            with st.spinner("准备该股数据…"):
                outcome = service.warm_history(symbols=[symbol])
                st.session_state["detail_warmup"] = outcome
                detail_results = service.screen(strategy, symbols=[symbol])
                st.session_state["detail_result"] = detail_results[0] if detail_results else None
                st.session_state["detail_context"] = service.context(symbol)
        except Exception as exc:
            st.error(f"更新失败：{exc}")
    detail_result = st.session_state.get("detail_result")
    if detail_result is None or detail_result.symbol != symbol or detail_result.strategy_id != strategy.strategy_id or detail_result.strategy_version != strategy.version:
        detail_result = next((result for result in results if result.symbol == symbol and result.strategy_id == strategy.strategy_id and result.strategy_version == strategy.version), None)
    if detail_result:
        status_cols = st.columns(4)
        status_cols[0].metric("最新价格", f"{detail_result.latest_price:.2f}" if detail_result.latest_price is not None else "未知")
        status_cols[1].metric("策略结果", detail_result.status)
        status_cols[2].metric("策略版本", detail_result.strategy_version)
        status_cols[3].metric("复权口径", service.settings.adjustment_mode)
        st.write(detail_result.reason)
        show_freshness([detail_result])
    try:
        saved_context = st.session_state.get("detail_context")
        own_result = st.session_state.get("detail_result")
        context = saved_context if saved_context is not None and own_result is detail_result and saved_context.symbol == symbol else service.context(symbol)
    except Exception as exc:
        st.info(f"K 线暂不可用：{exc}。可点击上方按钮准备该股数据。")
        context = None
    if context is not None:
        if saved_context is not context:
            st.caption("图表使用当前本地缓存；下方因子保留最近一次筛选快照。点击上方刷新按钮可同步当前股票的图表与因子。")
        quote = context.realtime_quote
        if quote is not None:
            with st.expander("行情原始对象与数据时间"):
                st.json(quote.model_dump(mode="json"))
        tabs = st.tabs(["日线 · Daily", "周线 · Weekly", "月线 · Monthly"])
        for tab, timeframe, label in zip(tabs, ["daily", "weekly", "monthly"], ["日线", "周线", "月线"]):
            with tab:
                bars = context.bars(timeframe)
                if bars.empty:
                    st.info("该周期暂无可用历史数据。")
                else:
                    st.plotly_chart(candle_chart(bars, f"{choices[symbol]} · {label} · {context.adjustment}"), width="stretch")
                    st.caption(f"展示最近最多 180 根 K 线。MA5 / MA10 / MA20 使用完整可用历史计算。截至 {stamp(context.as_of)}；未完成周期以数据中的 is_partial 标记为准。")
                    with st.expander(f"查看{label}原始数据 / 未完成周期"):
                        st.dataframe(bars.tail(180), width="stretch")
    if detail_result is None:
        st.info("尚未计算当前股票 / 策略版本。点击上方刷新按钮查看所有 Factor Result。")
        return
    st.subheader("Factor 逐项解释")
    factor_names = {item.factor_id: item.name for item in service.factors.list()}
    for key, factor in detail_result.factors.items():
        title = f"{factor.status} · {factor_names.get(factor.factor_id, factor.factor_id)} · {factor.value}"
        with st.expander(title, expanded=True):
            st.write(factor.reason or "该因子未提供附加说明。")
            st.caption(f"ID: {key} · v{factor.version} · adjustment={factor.adjustment}")
            st.caption(f"计算时间：{stamp(factor.timestamp)} · 数据时间：{stamp(factor.data_timestamp)}")
            values = st.columns([2, 1])
            with values[0]:
                st.write("原始计算值与依据")
                st.json(factor.details)
            with values[1]:
                st.write("参数快照")
                st.json(factor.parameters)
    with st.expander("规则求值与完整结果 JSON"):
        st.json(detail_result.model_dump(mode="json"))


def settings_page(service: Any) -> None:
    page_heading("WORKSPACE SETTINGS", "设置", "配置数据来源、刷新频率、统一价格口径及股票池基础过滤。")
    quality_notice(service)
    settings = service.settings
    with st.form("settings_form"):
        columns = st.columns(2)
        providers = list(dict.fromkeys(["development", "mock", settings.market_data_provider]))
        provider = columns[0].selectbox("Data Provider", providers, index=providers.index(settings.market_data_provider))
        refresh = columns[1].number_input("默认刷新间隔（秒）", min_value=1.0, value=float(settings.realtime_refresh_seconds))
        adjustment = columns[0].selectbox("Adjustment Mode", ["raw", "qfq", "hfq"], index=["raw", "qfq", "hfq"].index(settings.adjustment_mode))
        stale = columns[1].number_input("行情陈旧阈值（秒）", min_value=1.0, value=float(settings.quote_stale_seconds))
        start = columns[0].text_input("历史数据起始日期", value=settings.history_start)
        storage = columns[1].text_input("本地缓存目录", value=str(settings.storage_dir))
        exclude_st = columns[0].checkbox("默认排除 ST / *ST", value=settings.exclude_st)
        exclude_inactive = columns[1].checkbox("默认排除退市 / 暂停上市", value=settings.exclude_inactive)
        listed = columns[0].number_input("最少上市天数（0 = 不启用）", min_value=0, value=settings.min_listed_days)
        amount = columns[1].number_input("20 日平均成交额下限（元；0 = 不启用）", min_value=0.0, value=float(settings.min_average_amount_20d))
        st.caption("raw 为默认统一口径。当前供应商如不支持可验证的复权转换，qfq / hfq 将明确报错。设置仅在本会话生效；持久化请修改 .env。")
        submitted = st.form_submit_button("应用设置并重建数据会话", type="primary")
    if submitted:
        try:
            from ashare.service import ResearchService
            payload = settings.model_dump()
            payload.update(market_data_provider=provider, realtime_refresh_seconds=refresh, quote_stale_seconds=stale, adjustment_mode=adjustment, history_start=start, storage_dir=storage, exclude_st=exclude_st, exclude_inactive=exclude_inactive, min_listed_days=int(listed), min_average_amount_20d=amount)
            pd.Timestamp(start)
            updated = Settings(**payload)
            replacement = ResearchService(updated)
            service.scanner.stop()
            close_provider = getattr(service.provider, "close", None)
            if callable(close_provider):
                try:
                    close_provider()
                except Exception:
                    logging.getLogger(__name__).exception("Previous provider cleanup failed during settings switch")
            for key in ["stock_universe", "screen_results", "ui_last_update", "detail_result", "detail_context", "refresh_seconds", "watchlist", "last_warmup"]:
                st.session_state.pop(key, None)
            st.session_state["research_service"] = replacement
            st.session_state["settings_applied"] = True
            st.rerun()
        except Exception as exc:
            st.error(f"设置未应用：{exc}")
    if st.session_state.pop("settings_applied", False):
        st.success("设置已应用。请重新加载股票池；磁盘历史缓存和策略版本保留。")
    st.subheader("API Credentials 状态")
    st.dataframe(pd.DataFrame([
        {"Credential": "TUSHARE_TOKEN", "状态": "已配置" if settings.tushare_token else "未配置", "说明": "扩展供应商接入预留"},
        {"Credential": "BROKER_API_KEY", "状态": "已配置" if settings.broker_api_key else "未配置", "说明": "券商供应商接入预留"},
    ]), hide_index=True, width="stretch")
    st.caption("密钥仅从 .env / 环境变量读取。界面只显示是否配置，不展示密钥内容。开发源与模拟源不需要密钥。")
    st.subheader("缓存与数据口径")
    st.write(f"历史：Parquet · 策略 / 运行记录：SQLite · Quote Cache：内存")
    st.code(str(settings.storage_dir), language=None)
    st.caption("历史准备支持增量更新。全部 A 股与自选范围在总览 / 实时筛选页选择，不设置隐藏股票数量上限。")
    with st.expander("非敏感配置快照"):
        safe = settings.model_dump(mode="json", exclude={"tushare_token", "broker_api_key"})
        st.json(safe)
