"""Presentation-only Streamlit views; calculations remain in the research service."""
