"""Readable stock results, rule-level comparisons and in-place explanations."""
from __future__ import annotations

import json
from html import escape

import pandas as pd
import streamlit as st

from ashare.ui.common import latest_results, results_frame, stamp

STATUS_LABELS = {"PASS": "已入选", "FAIL": "未入选", "NOT_ENOUGH_DATA": "历史数据不足",
                 "DATA_ERROR": "数据错误", "STALE": "行情已过期", "SUSPENDED": "停牌", "EXCLUDED": "已排除"}
COLORS = {"已入选": "#167347", "未入选": "#aa6223", "已排除": "#667085"}
DETAIL_LABELS = {
    "monthly_ma5": "5月均线", "monthly_ma10": "10月均线", "monthly_ma20": "20月均线",
    "swing_low": "上涨起点", "swing_high": "上涨高点", "swing_gain_pct": "上涨幅度 %",
    "swing_ratio": "高低点倍数", "current_weekly_ma10": "当前周均线", "weekly_ma10_slope": "周均线斜率",
    "recent_high": "近期高点", "drawdown_pct": "回调幅度 %", "ma5_today": "当日短均线",
    "ma10_today": "当日长均线", "ma5_previous": "昨日短均线", "ma10_previous": "昨日长均线",
    "dif": "DIF", "dea": "DEA", "histogram": "MACD 柱", "ratio": "当前量比",
    "today_volume": "当日累计量（股）", "previous_day_volume": "上一日总量（股）", "threshold": "要求量比",
    "latest_price": "当前价格", "distance_to_ma5_pct": "距短月均线 %", "distance_to_ma10_pct": "距长月均线 %",
}


def leaf_evaluations(tree: dict) -> list[dict]:
    if "factor" in tree:
        return [tree]
    return [leaf for child in tree.get("children", []) for leaf in leaf_evaluations(child)]


def short_value(value) -> str:
    if value is None:
        return "—"
    if isinstance(value, bool):
        return "满足" if value else "不满足"
    if isinstance(value, (int, float)):
        return f"{value:,.4f}".rstrip("0").rstrip(".")
    return str(value)


def summary_frame(results, names: dict) -> pd.DataFrame:
    rank = {"PASS": 0, "FAIL": 1, "NOT_ENOUGH_DATA": 2, "SUSPENDED": 3, "STALE": 4, "DATA_ERROR": 5, "EXCLUDED": 6}
    rows = []
    for result in sorted(results, key=lambda r: (rank.get(r.status, 99), r.symbol)):
        leaves = leaf_evaluations(result.rules)
        satisfied = sum(leaf.get("passed") is True for leaf in leaves)
        rows.append({"股票": result.name, "代码": result.symbol, "最新价": result.latest_price,
                     "筛选结果": STATUS_LABELS.get(result.status, result.status),
                     "满足条件": f"{satisfied} / {len(leaves)}" if leaves else "—",
                     "未通过因子 / 异常": "、".join(names.get(name, name) for name in result.failed_factors) or ("全部条件满足" if result.status == "PASS" else result.reason)})
    return pd.DataFrame(rows)


def factor_matrix(results, names: dict) -> pd.DataFrame:
    rows = []
    for result in results:
        row = {"股票": result.name, "代码": result.symbol, "结果": STATUS_LABELS.get(result.status, result.status)}
        seen: dict[str, int] = {}
        for leaf in leaf_evaluations(result.rules):
            name = names.get(leaf["factor"], leaf["factor"])
            seen[name] = seen.get(name, 0) + 1
            column = name if seen[name] == 1 else f"{name} · 条件{seen[name]}"
            row[column] = "✓" if leaf.get("passed") is True else "×" if leaf.get("passed") is False else "—"
        rows.append(row)
    return pd.DataFrame(rows).fillna("—")


def factor_evidence(factor) -> str:
    details = factor.details
    preferred = [key for key in DETAIL_LABELS if key in details]
    if "ma_by_period" in details:
        return " · ".join(f"MA{period} {short_value(value)}" for period, value in details["ma_by_period"].items())
    if preferred:
        return " · ".join(f"{DETAIL_LABELS[key]} {short_value(details[key])}" for key in preferred[:5])
    return factor.reason


def _rule_factor(result, leaf):
    candidates = [f for f in result.factors.values() if f.factor_id == leaf["factor"]]
    return next((f for f in candidates if f.parameters == leaf.get("params")), candidates[0] if candidates else None)


def render_stock_explanation(result, names):
    from ashare.ui.workspace import active_strategy
    status = STATUS_LABELS.get(result.status, result.status)
    color = COLORS.get(status, "#b04445")
    price = f"¥ {result.latest_price:,.2f}" if result.latest_price is not None else "价格未知"
    st.markdown(f'<div class="stock-heading"><div><span class="stock-title">{escape(result.name)}</span> <span class="stock-code">{escape(result.symbol)}</span></div><div><span class="stock-price">{price}</span> <span class="status-pill" style="color:{color};background:{color}14">{escape(status)}</span></div></div>', unsafe_allow_html=True)
    st.caption(f"行情：{stamp(result.quote_timestamp)}　｜　计算：{stamp(result.as_of)}　｜　策略快照：{result.strategy_version}")
    if result.status not in ("PASS", "FAIL"):
        st.warning(result.reason or status)
    elif result.failed_factors:
        st.write("**未满足的条件：** " + "、".join(names.get(name, name) for name in result.failed_factors))
    else:
        st.success("当前策略条件已满足。")
    rows = []
    leaves = leaf_evaluations(result.rules)
    for leaf in leaves:
        factor = _rule_factor(result, leaf)
        rows.append({"因子": names.get(leaf["factor"], leaf["factor"]),
                     "策略判断": "✓ 满足" if leaf.get("passed") is True else "× 未满足" if leaf.get("passed") is False else STATUS_LABELS.get(leaf.get("status"), "数据未知"),
                     "当前值": short_value(factor.value) if factor else "—",
                     "计算依据": factor_evidence(factor) if factor else leaf.get("reason", ""),
                     "规则要求": f"{'因子判定' if leaf.get('field') == 'passed' else '原始值'} {leaf.get('operator')} {short_value(leaf.get('expected'))}"})
    if rows:
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", height=min(430, 38 + len(rows) * 40),
                     column_config={"因子": st.column_config.TextColumn(width="medium"), "计算依据": st.column_config.TextColumn(width="large")})
    st.caption("这里显示的是策略规则的判断；满足项数用于解释结果，不是选股评分。左侧可随时修改相应因子。")
    with st.expander("查看完整参数、数据来源与原始计算明细"):
        for key, factor in result.factors.items():
            st.markdown("**" + names.get(factor.factor_id, key) + "**")
            st.caption(f"计算时间：{stamp(factor.timestamp)} · 数据时间：{stamp(factor.data_timestamp)}")
            st.json({"value": factor.value, "factor_passed": factor.passed, "parameters": factor.parameters, "details": factor.details})


def show_results(service):
    from ashare.ui.workspace import active_strategy
    results = latest_results(service)
    draft = active_strategy(service)
    if not results:
        st.markdown('<div class="empty-results"><b>筛选结果将在这里显示</b><p>先展开“股票池与数据”，加载股票并准备历史数据，然后点击“运行筛选”。<br>左侧的因子可以随时查看和修改。</p></div>', unsafe_allow_html=True)
        return
    snapshot = st.session_state.get("result_strategy_snapshot")
    if snapshot is not None and snapshot != draft.model_dump_json() or any(r.strategy_id != draft.strategy_id or r.strategy_version != draft.version for r in results):
        st.warning("因子或策略已经修改。下方仍是上次筛选结果，请点击“运行筛选”或左侧“应用并重算”查看新结果。")
    names = {meta.factor_id: meta.name for meta in service.factors.list()}
    counts = {status: sum(r.status == status for r in results) for status in STATUS_LABELS}
    metric_cols = st.columns(4)
    metric_cols[0].metric("本次已扫描", f"{len(results):,}")
    metric_cols[1].metric("已入选", f"{counts['PASS']:,}")
    metric_cols[2].metric("未入选", f"{counts['FAIL']:,}")
    metric_cols[3].metric("数据异常 / 不足", sum(v for k, v in counts.items() if k not in {"PASS", "FAIL", "EXCLUDED"}))
    left, middle, right = st.columns([1.6, 1, 1])
    query = left.text_input("搜索股票", placeholder="股票名称或代码", key="result_query")
    status_filter = middle.selectbox("结果分类", ["全部结果", "已入选", "未入选", "数据异常 / 不足", "已排除"], key="result_status_filter")
    view = right.selectbox("查看方式", ["股票列表", "因子对照表"], key="result_view")
    selected = [r for r in results if not query or query.lower() in (r.symbol + r.name).lower()]
    if status_filter in {"已入选", "未入选", "已排除"}:
        code = {"已入选": "PASS", "未入选": "FAIL", "已排除": "EXCLUDED"}[status_filter]
        selected = [r for r in selected if r.status == code]
    elif status_filter == "数据异常 / 不足":
        selected = [r for r in selected if r.status not in {"PASS", "FAIL", "EXCLUDED"}]
    frame = summary_frame(selected, names)
    st.caption(f"显示 {len(selected):,} / {len(results):,} 只 · 入选股票优先 · {counts['EXCLUDED']:,} 只由基础设置排除")
    if not selected:
        st.info("当前分类或搜索条件下没有股票。")
    else:
        lookup = {r.symbol: r for r in selected}
        data = frame if view == "股票列表" else factor_matrix([lookup[symbol] for symbol in frame["代码"]], names)
        st.caption("点击表格中的一行，在下方查看该股的完整判断。" + ("　✓ 满足　× 未满足　— 数据未知" if view == "因子对照表" else ""))
        status_column = "筛选结果" if view == "股票列表" else "结果"
        styled = data.style.map(lambda value: f"color:{COLORS.get(value, '#b04445')};font-weight:600", subset=[status_column])
        event = st.dataframe(styled, hide_index=True, width="stretch", height=min(450, 40 + max(3, len(data)) * 38),
                             key="clear_results_table_" + view + status_filter + query,
                             on_select="rerun", selection_mode="single-row",
                             column_config={"股票": st.column_config.TextColumn(width="small"), "代码": st.column_config.TextColumn(width="small"),
                                            "最新价": st.column_config.NumberColumn(format="%.2f", width="small"),
                                            "满足条件": st.column_config.TextColumn(width="small"),
                                            "未通过因子 / 异常": st.column_config.TextColumn(width="large")})
        indexes = event.selection.rows
        token = (view, status_filter, query, tuple(indexes))
        symbols = list(frame["代码"])
        if indexes and indexes[0] < len(symbols) and token != st.session_state.get("last_result_row_selection"):
            st.session_state["inspect_result_symbol"] = symbols[indexes[0]]
            st.session_state["last_result_row_selection"] = token
        if st.session_state.get("inspect_result_symbol") not in symbols:
            st.session_state["inspect_result_symbol"] = symbols[0]
        selected_symbol = st.selectbox("查看股票的筛选依据", symbols,
                                      format_func=lambda symbol: f"{lookup[symbol].name} · {symbol}", key="inspect_result_symbol")
        result = lookup[selected_symbol]
        with st.container(border=True):
            render_stock_explanation(result, names)
    with st.expander("导出结果与数据时间"):
        from ashare.ui.common import show_freshness
        show_freshness(results)
        a, b = st.columns(2)
        a.download_button("下载完整 CSV", results_frame(results, True).to_csv(index=False).encode("utf-8-sig"), "screen_results.csv", "text/csv")
        b.download_button("下载结果 JSON", json.dumps([r.model_dump(mode="json") for r in results], ensure_ascii=False, indent=2), "screen_results.json", "application/json")
        st.json(service.last_scan_stats)
