from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    market_data_provider: str = "development"
    realtime_refresh_seconds: float = Field(5, ge=1)
    quote_stale_seconds: float = Field(120, ge=1)
    adjustment_mode: Literal["raw", "qfq", "hfq"] = "raw"
    storage_dir: Path = Path("storage")
    history_start: str = "2021-01-01"
    history_workers: int = Field(2, ge=1, le=8)
    request_timeout_seconds: float = Field(12, ge=1)
    exclude_st: bool = True
    exclude_inactive: bool = True
    min_listed_days: int = Field(0, ge=0)
    min_average_amount_20d: float = Field(0, ge=0)
    universe: str = "all"
    tushare_token: str = ""
    broker_api_key: str = ""
    factor_plugins: str = ""
