"""Pure, provider-independent factors and strict, explainable error handling."""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, ClassVar

import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict, ValidationError

from ashare.models import FactorContext, FactorMetadata, FactorResult, SHANGHAI

logger = logging.getLogger(__name__)


class FactorParameters(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class NotEnoughData(ValueError):
    """Known inputs exist but cannot support the factor definition yet."""


class DataError(ValueError):
    """An invalid or non-point-in-time input must not become an ordinary FAIL."""


class BaseFactor(ABC):
    """Add a subclass and register it; factors never import providers or do I/O.

    Plugins normally implement ``_calculate`` and a Pydantic ``Parameters`` class.
    Keeping ``calculate`` unchanged retains validation, provenance and isolation.
    """

    metadata: ClassVar[FactorMetadata]
    Parameters: ClassVar[type[FactorParameters]] = FactorParameters

    def calculate(self, context: FactorContext, params: dict[str, Any] | None = None) -> FactorResult:
        snapshot = dict(self.metadata.default_parameters)
        snapshot.update(params or {})
        common = dict(
            factor_id=self.metadata.factor_id,
            timestamp=context.as_of.to_pydatetime(),
            adjustment=context.adjustment,
            version=self.metadata.version,
        )
        try:
            parsed = self.Parameters.model_validate(snapshot)
            snapshot = parsed.model_dump(mode="json")
            if context.as_of.tzinfo is None:
                raise DataError("context.as_of must be timezone aware")
            passed, value, details, reason = self._calculate(context, parsed)
            if not isinstance(passed, (bool, np.bool_)):
                raise DataError("Successful factor output must include a boolean passed decision")
            passed = bool(passed)
            output_type = self.metadata.output_type
            if output_type == "boolean":
                if not isinstance(value, (bool, np.bool_)):
                    raise DataError("Boolean factor returned a non-boolean raw value")
                value = bool(value)
            elif output_type == "numeric":
                if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.number)) or not np.isfinite(value):
                    raise DataError("Numeric factor returned a non-finite/non-numeric raw value")
                value = float(value)
            elif not isinstance(value, str):
                raise DataError("Categorical factor must return a string raw value")
            data_timestamp = self._data_timestamp(context)
            details.update({
                "symbol": context.symbol,
                "as_of": context.as_of.isoformat(),
                "adjustment_mode": context.adjustment,
                "parameter_snapshot": snapshot,
                "historical_revision": context.metadata.get("historical_revision"),
            })
            return FactorResult(
                **common, parameters=snapshot, passed=passed, value=value,
                status="PASS" if passed else "FAIL", reason=reason,
                details=details, data_timestamp=data_timestamp,
            )
        except NotEnoughData as exc:
            return FactorResult(**common, parameters=snapshot, status="NOT_ENOUGH_DATA", reason=str(exc))
        except (ValidationError, DataError, ValueError, KeyError, TypeError, IndexError) as exc:
            logger.warning("Factor %s on %s: %s", self.metadata.factor_id, context.symbol, exc)
            return FactorResult(**common, parameters=snapshot, status="DATA_ERROR", reason=str(exc))
        except Exception as exc:
            logger.exception("Unexpected factor failure %s on %s", self.metadata.factor_id, context.symbol)
            return FactorResult(**common, parameters=snapshot, status="DATA_ERROR", reason=f"{type(exc).__name__}: {exc}")

    @abstractmethod
    def _calculate(self, context: FactorContext, params: FactorParameters) -> tuple[bool, bool | float | str, dict, str]:
        """Return passed, raw output, calculation details, and explanation."""
        raise NotImplementedError

    def _data_timestamp(self, context: FactorContext):
        timeframe = self.metadata.timeframe
        if timeframe in {"daily", "weekly", "monthly"}:
            frame = context.bars(timeframe)
            if not frame.empty:
                if "available_at" in frame:
                    available = frame.available_at
                    if not isinstance(available.dtype, pd.DatetimeTZDtype):
                        available = pd.to_datetime(available, utc=True)
                    return available.max().to_pydatetime()
                stamp = pd.Timestamp(frame.index[-1])
                stamp = stamp.tz_localize(SHANGHAI) if stamp.tzinfo is None else stamp
                return stamp.to_pydatetime()
        return context.as_of.to_pydatetime()


def checked_bars(context: FactorContext, timeframe: str, minimum: int, columns: tuple[str, ...] = ("close",)) -> pd.DataFrame:
    """Validate the visible prefix; never repair missing/invalid prices by filling."""
    frame = context.bars(timeframe)
    if len(frame) < minimum:
        raise NotEnoughData(f"{timeframe}: need {minimum} observations; have {len(frame)}")
    if not isinstance(frame.index, pd.DatetimeIndex):
        raise DataError(f"{timeframe} index must be a DatetimeIndex")
    if not frame.index.is_monotonic_increasing or not frame.index.is_unique:
        raise DataError(f"{timeframe} observations must be sorted and unique")
    # Sorted/unique index means the final label proves every session is visible.
    # Localizing the entire 5-year index in every factor dominates live latency.
    last_date = frame.index[-1]
    last_date = last_date.tz_localize(SHANGHAI) if last_date.tzinfo is None else last_date
    if last_date > context.as_of:
        raise DataError(f"{timeframe} contains a future observation")
    if "available_at" in frame:
        available = frame.available_at
        if not isinstance(available.dtype, pd.DatetimeTZDtype):
            available = pd.to_datetime(available, utc=True)
        if available.isna().any() or (available > context.as_of).any():
            raise DataError(f"{timeframe} contains missing/future available_at")
    for col in columns:
        if col not in frame:
            raise DataError(f"{timeframe} missing column: {col}")
        values = frame[col].to_numpy(dtype=float, copy=False) if pd.api.types.is_numeric_dtype(frame[col].dtype) else pd.to_numeric(frame[col], errors="coerce").to_numpy(dtype=float)
        if not np.isfinite(values).all():
            raise DataError(f"{timeframe} {col} contains a missing/non-finite value")
        if (values < 0).any() or col in {"open", "close", "high", "low"} and (values == 0).any():
            raise DataError(f"{timeframe} {col} contains an invalid negative/zero value")
    return frame


def current_price(context: FactorContext) -> float:
    frame = checked_bars(context, "daily", 1)
    quote = context.realtime_quote
    if quote is not None:
        if quote.symbol != context.symbol:
            raise DataError("quote symbol does not match context")
        if quote.timestamp is None or pd.Timestamp(quote.timestamp) > context.as_of:
            raise DataError("quote exchange timestamp missing or in future")
        if quote.latest_price is None or not np.isfinite(quote.latest_price) or quote.latest_price <= 0:
            raise DataError("quote latest_price must be a finite positive number")
    # The bar builder owns adjustment conversion. Daily close is its normalized
    # latest quote, so adjusted contexts never accidentally splice in a raw price.
    return float(frame.close.iloc[-1])


def input_details(frame: pd.DataFrame, columns: tuple[str, ...] = ("close",), limit: int = 40) -> dict:
    """A bounded, serializable raw input window plus revision-backed provenance."""
    window = frame.tail(limit)
    # Avoid a pandas Series allocation per raw observation on every live tick.
    raw: dict[str, list] = {"date": [stamp.isoformat() for stamp in window.index]}
    for col in columns:
        raw[col] = window[col].astype(float).tolist()
    if "available_at" in window:
        raw["available_at"] = [pd.Timestamp(stamp).isoformat() for stamp in window.available_at]
    if "is_partial" in window:
        raw["is_partial"] = window.is_partial.astype(bool).tolist()
    records = [dict(zip(raw, values)) for values in zip(*raw.values())]
    return {"raw_inputs": records, "input_rows": len(frame), "raw_inputs_truncated": len(frame) > limit,
            "current_bar_partial": bool(frame.is_partial.iloc[-1]) if "is_partial" in frame else None}
