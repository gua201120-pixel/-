"""Cumulative current-day / previous full trading-day volume, in shares."""
from pydantic import Field

from ashare.factors.base import BaseFactor, FactorParameters, DataError, checked_bars, input_details
from ashare.models import FactorContext, FactorMetadata


class VolumeParameters(FactorParameters):
    minimum_ratio: float = Field(1.5, gt=0)


class DailyVolumeExpansionFactor(BaseFactor):
    Parameters = VolumeParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="daily_volume_expansion", name="当日成交量放大",
        description="今日实时累计成交量 / 上一交易日全天成交量，默认 >= 1.5；不做全天预测。",
        category="volume", timeframe="daily", output_type="numeric",
        default_parameters=VolumeParameters().model_dump(),
    )

    def _calculate(self, context: FactorContext, params: VolumeParameters):
        bars = checked_bars(context, "daily", 2, ("volume",))
        today, previous = float(bars.volume.iloc[-1]), float(bars.volume.iloc[-2])
        if previous <= 0:
            raise DataError("Previous trading day volume is zero; volume ratio is undefined")
        ratio = today / previous
        passed = ratio >= params.minimum_ratio
        details = {"today_volume": today, "previous_day_volume": previous, "previous_volume": previous,
                   "ratio": ratio, "threshold": params.minimum_ratio, "volume_unit": "shares",
                   **input_details(bars, ("volume",), 2)}
        return passed, ratio, details, f"Cumulative volume ratio={ratio:.4f} >= {params.minimum_ratio}: {passed}"
