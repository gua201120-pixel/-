"""Bounded completed-prefix cache; mutable current bar is always evaluated afresh."""
from __future__ import annotations

from collections import OrderedDict
from hashlib import sha256
from typing import Any

import pandas as pd

from ashare.models import FactorContext


class PrefixCache:
    def __init__(self, maxsize: int = 12000):
        self.maxsize = maxsize
        self.values: OrderedDict[tuple, Any] = OrderedDict()
        self.hits = 0
        self.misses = 0

    def get(self, key: tuple):
        if key not in self.values:
            self.misses += 1
            return None
        self.hits += 1
        self.values.move_to_end(key)
        return self.values[key]

    def put(self, key: tuple, value: Any):
        self.values[key] = value
        self.values.move_to_end(key)
        while len(self.values) > self.maxsize:
            self.values.popitem(last=False)


def prefix_key(context: FactorContext, frame: pd.DataFrame, timeframe: str, params: tuple) -> tuple:
    """Revision must change for any historical correction (builder's contract).

    Standalone/plugin callers without that guarantee fall back to a content hash.
    The last observation is excluded: every tick can safely replace its value.
    """
    prefix = frame.iloc[:-1]
    revision = context.metadata.get("historical_revision")
    if revision is None:
        columns = [c for c in ("close", "available_at", "is_partial") if c in prefix]
        revision = sha256(pd.util.hash_pandas_object(prefix[columns], index=True).values.tobytes()).hexdigest()
    return (context.symbol, context.adjustment, timeframe, revision, len(prefix),
            str(prefix.index[-1]) if len(prefix) else "", params)
