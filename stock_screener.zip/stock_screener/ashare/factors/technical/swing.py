"""Causal, forward-only close-based weekly ZigZag.

OHLC bars do not reveal whether the high preceded the low. Using closes avoids
inventing that intrabar ordering. Pivot occurrence and confirmation are distinct;
a pivot never becomes known before its confirmation observation. The final swing
endpoint remains tentative. A reversal using a partial weekly close is explicitly
provisional, since a later tick can retract it. Replays require actual as-of data.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from math import isclose

import pandas as pd
from pydantic import Field

from ashare.factors.base import BaseFactor, FactorParameters, NotEnoughData, checked_bars, input_details
from ashare.factors.technical.cache import PrefixCache, prefix_key
from ashare.models import FactorContext, FactorMetadata, SHANGHAI


class SwingParameters(FactorParameters):
    zigzag_threshold: float = Field(0.10, gt=0, lt=1)
    max_ratio: float = Field(2.0, gt=1)


@dataclass
class ZigZagState:
    direction: int = 0
    candidate: dict | None = None
    first_low: dict | None = None
    first_high: dict | None = None
    confirmed_pivots: list[dict] = field(default_factory=list)


def _point(stamp, row) -> dict:
    date = pd.Timestamp(stamp)
    observed_at = pd.Timestamp(row.get("available_at", date))
    if observed_at.tzinfo is None:
        observed_at = observed_at.tz_localize(SHANGHAI)
    return {"date": date.isoformat(), "price": float(row.close),
            "observed_at": observed_at.isoformat(), "observation_is_partial": bool(row.get("is_partial", False))}


def _confirm(state: ZigZagState, point: dict, kind: str, observation: dict):
    state.confirmed_pivots.append({
        **point, "kind": kind, "confirmed_at": observation["observed_at"],
        "confirmation_is_partial": observation["observation_is_partial"],
        "state": "provisionally_confirmed" if observation["observation_is_partial"] else "confirmed",
    })


def advance_zigzag(state: ZigZagState, point: dict, threshold: float) -> None:
    """One observation, O(1); no negative indexing or future-price inspection."""
    price = point["price"]
    if state.first_low is None:
        state.first_low = state.first_high = state.candidate = point
        return
    if state.direction == 0:
        if price < state.first_low["price"]:
            state.first_low = point
        if price > state.first_high["price"]:
            state.first_high = point
        if _at_least(price, state.first_low["price"] * (1 + threshold)):
            _confirm(state, state.first_low, "low", point)
            state.direction, state.candidate = 1, point
        elif _at_most(price, state.first_high["price"] * (1 - threshold)):
            _confirm(state, state.first_high, "high", point)
            state.direction, state.candidate = -1, point
    elif state.direction == 1:
        if price >= state.candidate["price"]:
            state.candidate = point
        elif _at_most(price, state.candidate["price"] * (1 - threshold)):
            _confirm(state, state.candidate, "high", point)
            state.direction, state.candidate = -1, point
    else:
        if price <= state.candidate["price"]:
            state.candidate = point
        elif _at_least(price, state.candidate["price"] * (1 + threshold)):
            _confirm(state, state.candidate, "low", point)
            state.direction, state.candidate = 1, point


def _at_least(value: float, threshold: float) -> bool:
    return value >= threshold or isclose(value, threshold, rel_tol=1e-12)


def _at_most(value: float, threshold: float) -> bool:
    return value <= threshold or isclose(value, threshold, rel_tol=1e-12)


def causal_zigzag(bars: pd.DataFrame, threshold: float = 0.10) -> ZigZagState:
    """Public reference implementation for prefix invariance tests and research."""
    state = ZigZagState()
    for stamp, row in bars.iterrows():
        advance_zigzag(state, _point(stamp, row), threshold)
    return state


class SwingGainBelow100PctFactor(BaseFactor):
    Parameters = SwingParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="swing_gain_below_100pct", name="最近上涨阶段没有翻倍",
        description="周收盘价10%因果ZigZag：最近上涨段高点/之前有效低点 < 2；末端未确认，盘中确认可撤回。",
        category="technical", timeframe="weekly", output_type="numeric",
        default_parameters=SwingParameters().model_dump(),
    )

    def __init__(self):
        self.cache = PrefixCache()

    def _calculate(self, context: FactorContext, params: SwingParameters):
        bars = checked_bars(context, "weekly", 2)
        key = prefix_key(context, bars, "weekly", (params.zigzag_threshold,))
        saved = self.cache.get(key)
        cache_hit = saved is not None
        if saved is None:
            saved = causal_zigzag(bars.iloc[:-1], params.zigzag_threshold)
            self.cache.put(key, saved)
        state = deepcopy(saved)
        advance_zigzag(state, _point(bars.index[-1], bars.iloc[-1]), params.zigzag_threshold)
        if state.direction == 1:
            high = {**state.candidate, "kind": "high", "confirmed_at": None,
                    "confirmation_is_partial": None, "state": "tentative"}
            low = next((p for p in reversed(state.confirmed_pivots) if p["kind"] == "low"), None)
        else:
            high_index = next((i for i in range(len(state.confirmed_pivots) - 1, -1, -1)
                               if state.confirmed_pivots[i]["kind"] == "high"), None)
            high = state.confirmed_pivots[high_index] if high_index is not None else None
            low = next((p for p in reversed(state.confirmed_pivots[:high_index]) if p["kind"] == "low"), None) if high_index is not None else None
        if low is None or high is None:
            raise NotEnoughData("No causally identified low-to-high upswing; need a threshold-confirmed low")
        ratio = high["price"] / low["price"]
        passed = ratio < params.max_ratio
        details = {"swing_low_date": low["date"], "swing_low": low["price"],
                   "swing_high_date": high["date"], "swing_high": high["price"],
                   "swing_ratio": ratio, "swing_gain_pct": (ratio - 1) * 100,
                   "swing_low_state": low["state"], "swing_high_state": high["state"],
                   "low_confirmed_at": low["confirmed_at"], "high_confirmed_at": high["confirmed_at"],
                   "swing_low_pivot": low, "swing_high_pivot": high,
                   "confirmed_pivots": state.confirmed_pivots,
                   "tentative_pivot": {**state.candidate, "kind": "high" if state.direction == 1 else "low", "state": "tentative", "confirmed_at": None},
                   "price_basis": "weekly_close", "threshold": params.zigzag_threshold,
                   "completed_prefix_cache_hit": cache_hit, **input_details(bars, limit=52)}
        return passed, ratio, details, f"Weekly close upswing ratio={ratio:.4f} < {params.max_ratio}; high={high['state']}: {passed}"
