"""Tail-window MA kernels include the current partial bar, without full rolling."""
from __future__ import annotations

from pydantic import Field, model_validator

from ashare.factors.base import BaseFactor, FactorParameters, checked_bars, current_price, input_details
from ashare.models import FactorContext, FactorMetadata


class AlignmentParameters(FactorParameters):
    fast_period: int = Field(5, ge=1, le=120)
    medium_period: int = Field(10, ge=2, le=240)
    slow_period: int = Field(20, ge=3, le=360)

    @model_validator(mode="after")
    def ordered(self):
        if not self.fast_period < self.medium_period < self.slow_period:
            raise ValueError("fast_period < medium_period < slow_period required")
        return self


class PairParameters(FactorParameters):
    fast_period: int = Field(5, ge=1, le=120)
    slow_period: int = Field(10, ge=2, le=360)

    @model_validator(mode="after")
    def ordered(self):
        if self.fast_period >= self.slow_period:
            raise ValueError("fast_period < slow_period required")
        return self


class RisingParameters(FactorParameters):
    period: int = Field(10, ge=1, le=260)
    slope_lookback_weeks: int = Field(1, ge=1, le=52)


def tail_ma(values, period: int, offset: int = 0) -> float:
    end = len(values) - offset
    return float(values.iloc[end - period:end].mean())


class MonthlyMABullishAlignmentFactor(BaseFactor):
    Parameters = AlignmentParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="monthly_ma_bullish_alignment", name="月线多头排列",
        description="当前月未完成K线参与 MA5 > MA10 > MA20。", category="technical",
        timeframe="monthly", output_type="boolean", default_parameters=AlignmentParameters().model_dump(),
    )

    def _calculate(self, context: FactorContext, params: AlignmentParameters):
        bars = checked_bars(context, "monthly", params.slow_period)
        fast, medium, slow = [tail_ma(bars.close, p) for p in (params.fast_period, params.medium_period, params.slow_period)]
        passed = fast > medium > slow
        details = {"ma5": fast, "ma10": medium, "ma20": slow, "monthly_ma5": fast,
                   "monthly_ma10": medium, "monthly_ma20": slow,
                   "ma_by_period": {str(p): v for p, v in zip((params.fast_period, params.medium_period, params.slow_period), (fast, medium, slow))},
                   **input_details(bars, limit=params.slow_period)}
        return passed, passed, details, f"Monthly MA{params.fast_period}={fast:.4f} > MA{params.medium_period}={medium:.4f} > MA{params.slow_period}={slow:.4f}: {passed}"


class PriceAboveMonthlyMA5MA10Factor(BaseFactor):
    Parameters = PairParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="price_above_monthly_ma5_ma10", name="当前价格站上5月线和10月线",
        description="最新归一化价格高于包含当前月的 MA5 和 MA10。", category="technical",
        timeframe="monthly", output_type="boolean", default_parameters=PairParameters().model_dump(),
    )

    def _calculate(self, context: FactorContext, params: PairParameters):
        bars = checked_bars(context, "monthly", params.slow_period)
        fast, slow = tail_ma(bars.close, params.fast_period), tail_ma(bars.close, params.slow_period)
        price = current_price(context)
        passed = price > fast and price > slow
        details = {"latest_price": price, "monthly_ma5": fast, "monthly_ma10": slow,
                   "distance_to_ma5_pct": (price / fast - 1) * 100, "distance_to_ma10_pct": (price / slow - 1) * 100,
                   **input_details(bars, limit=params.slow_period)}
        return passed, passed, details, f"Price={price:.4f}, monthly MA{params.fast_period}={fast:.4f}, MA{params.slow_period}={slow:.4f}; above both: {passed}"


class WeeklyMA10RisingFactor(BaseFactor):
    Parameters = RisingParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="weekly_ma10_rising", name="10周均线向上",
        description="包含当前周的 MA10 高于此前指定周数的 MA10。", category="technical",
        timeframe="weekly", output_type="boolean", default_parameters=RisingParameters().model_dump(),
    )

    def _calculate(self, context: FactorContext, params: RisingParameters):
        bars = checked_bars(context, "weekly", params.period + params.slope_lookback_weeks)
        current = tail_ma(bars.close, params.period)
        previous = tail_ma(bars.close, params.period, params.slope_lookback_weeks)
        slope = current - previous
        passed = slope > 0
        details = {"current_weekly_ma10": current, "previous_weekly_ma10": previous,
                   "weekly_ma10": current, "slope": slope, "weekly_ma10_slope": slope,
                   **input_details(bars, limit=params.period + params.slope_lookback_weeks)}
        return passed, passed, details, f"Weekly MA{params.period} change over {params.slope_lookback_weeks} week(s)={slope:.6f}; rising: {passed}"


class DailyMA5CrossMA10Factor(BaseFactor):
    Parameters = PairParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="daily_ma5_cross_ma10", name="5日均线当天金叉10日均线",
        description="今日 MA5 > MA10 且上一交易日 MA5 <= MA10；盘中信号可撤回。", category="technical",
        timeframe="daily", output_type="boolean", default_parameters=PairParameters().model_dump(),
    )

    def _calculate(self, context: FactorContext, params: PairParameters):
        bars = checked_bars(context, "daily", params.slow_period + 1)
        fast, slow = tail_ma(bars.close, params.fast_period), tail_ma(bars.close, params.slow_period)
        previous_fast, previous_slow = tail_ma(bars.close, params.fast_period, 1), tail_ma(bars.close, params.slow_period, 1)
        passed = fast > slow and previous_fast <= previous_slow
        details = {"ma5_today": fast, "ma10_today": slow, "ma5_previous": previous_fast,
                   "ma10_previous": previous_slow, "crossed_today": passed,
                   **input_details(bars, limit=params.slow_period + 1)}
        return passed, passed, details, f"Today MA{params.fast_period}={fast:.4f}, MA{params.slow_period}={slow:.4f}; previous={previous_fast:.4f}/{previous_slow:.4f}; crossed today: {passed}"
