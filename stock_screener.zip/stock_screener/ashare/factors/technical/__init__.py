"""Technical factors; providers and strategy evaluation deliberately live elsewhere."""
