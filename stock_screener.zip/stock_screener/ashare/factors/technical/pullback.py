"""A rising weekly average and bounded positive drawdown magnitude."""
from math import isclose
from pydantic import Field, model_validator

from ashare.factors.base import BaseFactor, FactorParameters, checked_bars, current_price, input_details
from ashare.factors.technical.moving_average import tail_ma
from ashare.models import FactorContext, FactorMetadata


class PullbackParameters(FactorParameters):
    lookback_weeks: int = Field(12, ge=1, le=260)
    min_drawdown: float = Field(0.05, ge=0, lt=1)
    max_drawdown: float = Field(0.25, gt=0, lt=1)
    ma_period: int = Field(10, ge=1, le=260)
    slope_lookback_weeks: int = Field(1, ge=1, le=52)

    @model_validator(mode="after")
    def ordered(self):
        if self.min_drawdown > self.max_drawdown:
            raise ValueError("min_drawdown <= max_drawdown required")
        return self


class WeeklyPullbackFactor(BaseFactor):
    Parameters = PullbackParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="weekly_pullback", name="周线回调",
        description="近12周最高价回撤幅度 5%—25%，同时10周均线上行；回撤采用正数幅度。",
        category="technical", timeframe="weekly", output_type="boolean",
        default_parameters=PullbackParameters().model_dump(),
    )

    def _calculate(self, context: FactorContext, params: PullbackParameters):
        minimum = max(params.lookback_weeks, params.ma_period + params.slope_lookback_weeks)
        bars = checked_bars(context, "weekly", minimum, ("close", "high"))
        highs = bars.high.tail(params.lookback_weeks)
        high_date, high = highs.idxmax(), float(highs.max())
        price = current_price(context)
        drawdown = 1 - price / high
        current = tail_ma(bars.close, params.ma_period)
        previous = tail_ma(bars.close, params.ma_period, params.slope_lookback_weeks)
        slope = current - previous
        lower_ok = drawdown >= params.min_drawdown or isclose(drawdown, params.min_drawdown, rel_tol=1e-12)
        upper_ok = drawdown <= params.max_drawdown or isclose(drawdown, params.max_drawdown, rel_tol=1e-12)
        passed = lower_ok and upper_ok and slope > 0
        details = {"recent_high": high, "recent_high_date": high_date.isoformat(), "latest_price": price,
                   "drawdown": drawdown, "drawdown_pct": drawdown * 100,
                   "signed_return_from_high": price / high - 1, "signed_return_from_high_pct": (price / high - 1) * 100,
                   "weekly_ma10_slope": slope, "current_weekly_ma10": current, "previous_weekly_ma10": previous,
                   "drawdown_convention": "positive magnitude: 1 - latest_price / recent_high",
                   **input_details(bars, ("close", "high"), minimum)}
        return passed, passed, details, f"Drawdown={drawdown:.2%} in [{params.min_drawdown:.2%}, {params.max_drawdown:.2%}], weekly MA slope={slope:.6f}: {passed}"
