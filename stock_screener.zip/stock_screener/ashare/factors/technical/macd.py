"""MACD: first-close EMA seed, adjust=False, histogram=2*(DIF-DEA)."""
from pydantic import Field, model_validator

from ashare.factors.base import BaseFactor, FactorParameters, checked_bars, input_details
from ashare.factors.technical.cache import PrefixCache, prefix_key
from ashare.models import FactorContext, FactorMetadata


class MACDParameters(FactorParameters):
    fast_period: int = Field(12, ge=1, le=120)
    slow_period: int = Field(26, ge=2, le=260)
    signal_period: int = Field(9, ge=1, le=120)

    @model_validator(mode="after")
    def ordered(self):
        if self.fast_period >= self.slow_period:
            raise ValueError("fast_period < slow_period required")
        return self


class DailyMACDAboveZeroFactor(BaseFactor):
    Parameters = MACDParameters
    metadata = FactorMetadata(
        cache_policy="quote",
        factor_id="daily_macd_above_zero", name="日线MACD在0轴之上",
        description="EMA(12)-EMA(26) 的 DIF > 0 且 DEA(9) > 0；首个收盘价起算 EMA，柱=2*(DIF-DEA)。",
        category="technical", timeframe="daily", output_type="boolean",
        default_parameters=MACDParameters().model_dump(),
    )

    def __init__(self):
        self.cache = PrefixCache()

    def _calculate(self, context: FactorContext, params: MACDParameters):
        minimum = params.slow_period + params.signal_period - 1
        bars = checked_bars(context, "daily", minimum)
        key = prefix_key(context, bars, "daily", (params.fast_period, params.slow_period, params.signal_period))
        state = self.cache.get(key)
        cache_hit = state is not None
        if state is None:
            close = bars.close.iloc[:-1]
            ema_fast = close.ewm(span=params.fast_period, adjust=False).mean()
            ema_slow = close.ewm(span=params.slow_period, adjust=False).mean()
            dea = (ema_fast - ema_slow).ewm(span=params.signal_period, adjust=False).mean()
            state = (float(ema_fast.iloc[-1]), float(ema_slow.iloc[-1]), float(dea.iloc[-1]))
            self.cache.put(key, state)
        price = float(bars.close.iloc[-1])
        fast = state[0] + (price - state[0]) * 2 / (params.fast_period + 1)
        slow = state[1] + (price - state[1]) * 2 / (params.slow_period + 1)
        dif = fast - slow
        dea = state[2] + (dif - state[2]) * 2 / (params.signal_period + 1)
        histogram = 2 * (dif - dea)
        passed = dif > 0 and dea > 0
        details = {"dif": dif, "dea": dea, "DIF": dif, "DEA": dea, "histogram": histogram,
                   "ema_fast": fast, "ema_slow": slow, "previous_ema_fast": state[0],
                   "previous_ema_slow": state[1], "previous_dea": state[2],
                   "ema_convention": "adjust=False, first observed close seed; histogram=2*(DIF-DEA)",
                   "warmup_observations": minimum, "completed_prefix_cache_hit": cache_hit,
                   **input_details(bars, limit=minimum)}
        return passed, passed, details, f"DIF={dif:.6f} > 0 and DEA={dea:.6f} > 0: {passed}"
