"""Versioned factor classes and explicit plugin registration."""
from __future__ import annotations

import importlib

from packaging.version import Version

from ashare.factors.base import BaseFactor
from ashare.models import FactorMetadata


class FactorRegistry:
    def __init__(self):
        self._classes: dict[tuple[str, str], type[BaseFactor]] = {}
        self._instances: dict[tuple[str, str], BaseFactor] = {}

    def register(self, factor_class: type[BaseFactor]) -> None:
        if not isinstance(factor_class, type) or not issubclass(factor_class, BaseFactor):
            raise TypeError("Registered factor must inherit BaseFactor")
        metadata = factor_class.metadata
        Version(metadata.version)
        factor_class.Parameters.model_validate(metadata.default_parameters)
        key = (metadata.factor_id, metadata.version)
        if key in self._classes:
            raise ValueError(f"Factor version already registered: {key}")
        self._classes[key] = factor_class

    def get(self, factor_id: str, version: str | None = None) -> BaseFactor:
        if version is None:
            available = [ver for fid, ver in self._classes if fid == factor_id]
            if not available:
                raise KeyError(f"Unknown factor: {factor_id}")
            version = max(available, key=Version)
        key = (factor_id, version)
        if key not in self._classes:
            raise KeyError(f"Unknown factor version: {key}")
        if key not in self._instances:
            self._instances[key] = self._classes[key]()
        return self._instances[key]

    def list(self) -> list[FactorMetadata]:
        return [cls.metadata.model_copy(deep=True) for _, cls in sorted(self._classes.items())]


def default_registry(plugin_modules: str = "") -> FactorRegistry:
    from ashare.factors.technical.macd import DailyMACDAboveZeroFactor
    from ashare.factors.technical.moving_average import (
        DailyMA5CrossMA10Factor, MonthlyMABullishAlignmentFactor,
        PriceAboveMonthlyMA5MA10Factor, WeeklyMA10RisingFactor,
    )
    from ashare.factors.technical.pullback import WeeklyPullbackFactor
    from ashare.factors.technical.swing import SwingGainBelow100PctFactor
    from ashare.factors.technical.volume import DailyVolumeExpansionFactor

    registry = FactorRegistry()
    for cls in (MonthlyMABullishAlignmentFactor, PriceAboveMonthlyMA5MA10Factor,
                SwingGainBelow100PctFactor, WeeklyMA10RisingFactor, WeeklyPullbackFactor,
                DailyMA5CrossMA10Factor, DailyMACDAboveZeroFactor, DailyVolumeExpansionFactor):
        registry.register(cls)
    # Configuration imports trusted local Python code, never executes user text.
    for name in (item.strip() for item in plugin_modules.split(",")):
        if name:
            module = importlib.import_module(name)
            module.register(registry)
    return registry
