"""Provider-independent contracts. Prices in CNY, volume in shares, times aware."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any, Literal
from zoneinfo import ZoneInfo

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field, field_validator

SHANGHAI = ZoneInfo("Asia/Shanghai")
Status = Literal["PASS", "FAIL", "NOT_ENOUGH_DATA", "DATA_ERROR", "SUSPENDED", "STALE", "EXCLUDED"]
Adjustment = Literal["raw", "qfq", "hfq"]


def now_shanghai() -> datetime:
    return datetime.now(SHANGHAI)


def as_timestamp(value: str | date | datetime | pd.Timestamp) -> pd.Timestamp:
    """Date-only requests mean 15:00 exchange close; naive timestamps mean Shanghai."""
    stamp = pd.Timestamp(value)
    if isinstance(value, date) and not isinstance(value, datetime) or isinstance(value, str) and len(value) == 10:
        stamp += pd.Timedelta(hours=15)
    return stamp.tz_localize(SHANGHAI) if stamp.tzinfo is None else stamp.tz_convert(SHANGHAI)


class Stock(BaseModel):
    symbol: str
    code: str
    name: str
    exchange: str
    industry: str | None = None
    list_date: date | None = None
    is_st: bool = False
    status: str = "active"
    metadata_as_of: datetime | None = None


class Quote(BaseModel):
    model_config = ConfigDict(allow_inf_nan=False)
    symbol: str
    name: str = ""
    timestamp: datetime | None = None
    provider_timestamp: datetime | None = None
    received_at: datetime = Field(default_factory=now_shanghai)
    latest_price: float | None = None
    open: float | None = None
    high: float | None = None
    low: float | None = None
    previous_close: float | None = None
    volume: float | None = None
    amount: float | None = None
    change: float | None = None
    change_pct: float | None = None
    provider: str = "unknown"
    quality: Literal["realtime", "delayed", "unknown", "simulated"] = "unknown"
    reported_latency_seconds: float | None = None
    suspended: bool = False
    extra: dict[str, Any] = Field(default_factory=dict)

    @field_validator("timestamp", "provider_timestamp", "received_at")
    @classmethod
    def aware(cls, value: datetime | None) -> datetime | None:
        if value is not None and value.tzinfo is None:
            raise ValueError("timestamps must include exchange timezone")
        return value


class FactorMetadata(BaseModel):
    factor_id: str
    name: str
    description: str
    category: str
    timeframe: Literal["daily", "weekly", "monthly", "mixed", "event"]
    output_type: Literal["boolean", "numeric", "categorical"]
    supports_realtime: bool = True
    default_parameters: dict[str, Any] = Field(default_factory=dict)
    required_datasets: list[str] = Field(default_factory=list)
    cache_policy: Literal["as_of", "quote"] = "as_of"
    version: str = "1.0.0"
    created_at: datetime = datetime(2026, 9, 11, tzinfo=SHANGHAI)
    updated_at: datetime = datetime(2026, 9, 11, tzinfo=SHANGHAI)


class FactorResult(BaseModel):
    factor_id: str
    passed: bool | None = None
    value: bool | float | str | None = None
    status: Status = "PASS"
    reason: str = ""
    details: dict[str, Any] = Field(default_factory=dict)
    parameters: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime
    data_timestamp: datetime | None = None
    adjustment: Adjustment = "raw"
    version: str = "1.0.0"


@dataclass
class FactorContext:
    symbol: str
    as_of: pd.Timestamp
    daily_bars: pd.DataFrame
    weekly_bars: pd.DataFrame
    monthly_bars: pd.DataFrame
    realtime_quote: Quote | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    adjustment: Adjustment = "raw"
    financial_data: pd.DataFrame = field(default_factory=pd.DataFrame)
    datasets: dict[str, pd.DataFrame] = field(default_factory=dict)

    def bars(self, timeframe: str) -> pd.DataFrame:
        return {"daily": self.daily_bars, "weekly": self.weekly_bars, "monthly": self.monthly_bars}[timeframe]


class ScreenResult(BaseModel):
    symbol: str
    name: str
    latest_price: float | None = None
    quote_timestamp: datetime | None = None
    received_at: datetime | None = None
    as_of: datetime
    status: Status
    reason: str = ""
    factors: dict[str, FactorResult] = Field(default_factory=dict)
    failed_factors: list[str] = Field(default_factory=list)
    rules: dict[str, Any] = Field(default_factory=dict)
    strategy_id: str
    strategy_version: str
    provider: str
    metadata: dict[str, Any] = Field(default_factory=dict)
