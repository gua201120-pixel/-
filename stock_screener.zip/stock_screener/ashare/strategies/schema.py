"""Strict declarative strategy schema; no evaluated Python expressions."""
from __future__ import annotations

import math
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ashare.models import now_shanghai

Operator = Literal["==", "!=", ">", ">=", "<", "<=", "between", "not_between", "in", "not_in"]


class Rule(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    factor: str = Field(min_length=1)
    factor_version: str = "1.0.0"
    field: Literal["passed", "value"] = "passed"
    operator: Operator = "=="
    value: Any = True
    params: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True

    @model_validator(mode="after")
    def validate_operand(self) -> Rule:
        operands = self.value if isinstance(self.value, list) else [self.value]
        if any(type(v) not in (bool, float, int, str) or type(v) in (int, float) and not math.isfinite(v) for v in operands):
            raise ValueError("rule operands must be finite scalar booleans, numbers or strings")
        if self.operator in ("between", "not_between"):
            if not isinstance(self.value, list) or len(self.value) != 2:
                raise ValueError("between requires [minimum, maximum]")
            if any(type(v) not in (float, int) or not math.isfinite(v) for v in self.value) or self.value[0] > self.value[1]:
                raise ValueError("range must be finite numeric minimum <= maximum")
        elif self.operator in ("in", "not_in"):
            if not isinstance(self.value, list) or not self.value:
                raise ValueError("membership requires a nonempty list")
        elif self.operator in (">", ">=", "<", "<="):
            if type(self.value) not in (float, int) or not math.isfinite(self.value):
                raise ValueError("ordered comparison requires a finite number")
        elif type(self.value) not in (bool, float, int, str):
            raise ValueError("equality requires a scalar boolean, number or string")
        if self.field == "passed" and (self.operator not in ("==", "!=") or type(self.value) is not bool):
            raise ValueError("passed supports only ==/!= with boolean values; numeric rules use field=value")
        return self


class RuleGroup(BaseModel):
    model_config = ConfigDict(extra="forbid")
    logic: Literal["AND", "OR"] = "AND"
    rules: list[Rule | RuleGroup] = Field(default_factory=list)
    enabled: bool = True

    def leaves(self, enabled_only: bool = True) -> list[Rule]:
        if enabled_only and not self.enabled:
            return []
        out: list[Rule] = []
        for rule in self.rules:
            if isinstance(rule, RuleGroup):
                out.extend(rule.leaves(enabled_only))
            elif not enabled_only or rule.enabled:
                out.append(rule)
        return out


class Strategy(BaseModel):
    model_config = ConfigDict(extra="forbid")
    strategy_id: str = Field(pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1)
    version: str = Field(pattern=r"^[A-Za-z0-9_.-]+$")
    description: str = ""
    created_at: datetime = Field(default_factory=now_shanghai)
    updated_at: datetime = Field(default_factory=now_shanghai)
    rules: RuleGroup

    @model_validator(mode="after")
    def nonempty(self) -> Strategy:
        if not self.rules.leaves():
            raise ValueError("strategy requires at least one enabled rule")
        if self.created_at.tzinfo is None or self.updated_at.tzinfo is None:
            raise ValueError("strategy timestamps must be timezone-aware")
        return self
