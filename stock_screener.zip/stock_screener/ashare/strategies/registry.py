"""Immutable JSON strategy snapshots stored transactionally in SQLite."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

from .schema import Strategy

if TYPE_CHECKING:
    from ashare.factors.registry import FactorRegistry


class StrategyRegistry:
    def __init__(self, db_path: Path, factors: FactorRegistry | None = None):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.factors = factors
        with self._connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS strategies (strategy_id TEXT, version TEXT, snapshot TEXT NOT NULL, PRIMARY KEY(strategy_id, version))")
        for path in sorted((Path(__file__).parent / "configs").glob("*.json")):
            strategy = Strategy.model_validate_json(path.read_text(encoding="utf-8"))
            try:
                self.save(strategy)
            except FileExistsError:
                pass

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.db_path, timeout=30)
        try:
            with db:
                yield db
        finally:
            db.close()

    def save(self, strategy: Strategy) -> Strategy:
        strategy = Strategy.model_validate(strategy.model_dump())
        if self.factors is not None:
            for rule in strategy.rules.leaves():
                factor = self.factors.get(rule.factor, rule.factor_version)
                rule.params = factor.Parameters.model_validate({**factor.metadata.default_parameters, **rule.params}).model_dump()
        snapshot = strategy.model_dump_json()
        try:
            with self._connect() as db:
                db.execute("INSERT INTO strategies VALUES (?, ?, ?)", (strategy.strategy_id, strategy.version, snapshot))
        except sqlite3.IntegrityError as exc:
            raise FileExistsError("This strategy version exists; save a new version.") from exc
        return strategy

    def get(self, strategy_id: str, version: str | None = None) -> Strategy:
        with self._connect() as db:
            if version:
                row = db.execute("SELECT snapshot FROM strategies WHERE strategy_id=? AND version=?", (strategy_id, version)).fetchone()
            else:
                row = db.execute("SELECT snapshot FROM strategies WHERE strategy_id=? ORDER BY rowid DESC LIMIT 1", (strategy_id,)).fetchone()
        if row is None:
            raise KeyError(f"Strategy not found: {strategy_id}@{version}")
        return Strategy.model_validate_json(row[0])

    def list(self) -> list[Strategy]:
        with self._connect() as db:
            rows = db.execute("SELECT snapshot FROM strategies ORDER BY rowid DESC").fetchall()
        return [Strategy.model_validate_json(row[0]) for row in rows]
