"""Application facade: I/O at edges, deterministic factor/rule computation inside."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import time
import hashlib
import logging
from time import perf_counter, monotonic
from typing import Callable

import pandas as pd

from ashare.data.bar_store import BarStore
from ashare.data.base_provider import DataError
from ashare.data.calendar import ExchangeCalendar
from ashare.data.context import ContextBuilder
from ashare.data.provider_registry import create_provider
from ashare.data.quote_cache import QuoteCache
from ashare.backtest.point_in_time import known_observations
from ashare.factors.registry import default_registry
from ashare.models import FactorContext, ScreenResult, Stock, as_timestamp, now_shanghai
from ashare.screening.screener import Screener
from ashare.screening.realtime_screener import RealtimeScanner
from ashare.settings import Settings
from ashare.storage import ResearchStore
from ashare.strategies.registry import StrategyRegistry
from ashare.strategies.schema import Strategy

log = logging.getLogger(__name__)


class ResearchService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.provider = create_provider(settings.market_data_provider, settings)
        self.calendar = ExchangeCalendar()
        self.quotes = QuoteCache()
        self.bars = BarStore(settings.storage_dir, provider_name=self.provider.name)
        self.builder = ContextBuilder(self.calendar)
        self.factors = default_registry(settings.factor_plugins)
        self.strategies = StrategyRegistry(settings.storage_dir / "research.sqlite", self.factors)
        self.research = ResearchStore(settings.storage_dir / "research.sqlite")
        self.screener = Screener(self.factors)
        self.scanner = RealtimeScanner(self)
        self.last_results: list[ScreenResult] = []
        self.last_update = None
        self.last_scan_stats: dict = {}
        self._universe: list[Stock] | None = None
        self._stock_map: dict[str, Stock] = {}
        self._universe_date = None
        self._history: dict[str, pd.DataFrame] = {}
        self._result_cache: dict[str, tuple[str, ScreenResult]] = {}
        self._datasets: dict[tuple[str, str], tuple[float, pd.DataFrame]] = {}

    def universe(self, refresh: bool = False) -> list[Stock]:
        today = now_shanghai().date()
        refresh = refresh or self._universe_date is not None and self._universe_date != today
        if self._universe is None or refresh:
            self._universe = self.provider.get_stock_list(force_refresh=True) if refresh else self.provider.get_stock_list()
            self._stock_map = {s.symbol: s for s in self._universe}
            self._universe_date = today
        return self._universe

    def _load_history(self, symbol: str) -> pd.DataFrame:
        if symbol not in self._history:
            self._history[symbol] = self.bars.load(symbol, self.settings.adjustment_mode)
        return self._history[symbol]

    def warm_history(self, symbols=None, progress: Callable | None = None) -> dict:
        self.provider.validate_adjustment(self.settings.adjustment_mode)
        symbols = list(dict.fromkeys(self.provider.normalize_symbol(s) for s in (symbols if symbols is not None else [s.symbol for s in self.universe()])))
        current = now_shanghai()
        day = current.date()
        end = day if self.calendar.is_session(day) and current.time() >= time(15) else self.calendar.previous_session(day)
        errors, success = {}, []

        def download(symbol):
            return self.bars.sync(self.provider, symbol, self.settings.history_start, str(end), self.settings.adjustment_mode)

        with ThreadPoolExecutor(max_workers=self.settings.history_workers) as pool:
            futures = {pool.submit(download, symbol): symbol for symbol in symbols}
            for i, future in enumerate(as_completed(futures), 1):
                symbol = futures[future]
                try:
                    self._history[symbol] = future.result()
                    self._result_cache.pop(symbol, None)
                    success.append(symbol)
                    status = "OK"
                except Exception as exc:
                    log.exception("history_update_error symbol=%s", symbol)
                    errors[symbol] = str(exc)
                    status = str(exc)
                if progress:
                    progress(i, len(symbols), symbol, status)
        return {"success": len(success), "symbols": success, "errors": errors, "total": len(symbols)}

    def _stock(self, symbol: str, historical: bool) -> Stock:
        # Historical explicit-symbol replay never reads today's name/ST/listing status.
        if not historical and symbol in self._stock_map:
            return self._stock_map[symbol]
        return Stock(symbol=symbol, code=symbol, name=symbol, exchange="UNKNOWN")

    def context(self, symbol: str, as_of=None, required_datasets: list[str] | None = None) -> FactorContext:
        symbol = self.provider.normalize_symbol(symbol)
        historical = as_of is not None
        stamp = as_timestamp(as_of if historical else now_shanghai())
        history = self._load_history(symbol)
        self.provider.validate_adjustment(self.settings.adjustment_mode)
        ctx = self.builder.build(symbol, history, stamp, quote=None if historical else self.quotes.get(symbol),
                                 adjustment=self.settings.adjustment_mode,
                                 metadata={"provider": self.provider.name, "quality": self.provider.quality,
                                           "historical_replay": historical,
                                           "universe_basis": "explicit_symbols_not_a_pit_security_master" if historical else "current_universe",
                                           "history_vintage": "retrospective_provider_history_not_revision_vintages"})
        for name in required_datasets or []:
            key = (symbol, name)
            cached = self._datasets.get(key)
            if cached is None or monotonic() - cached[0] > 3600:
                self._datasets[key] = (monotonic(), self.provider.get_dataset(name, symbol))
            visible = known_observations(self._datasets[key][1], stamp)
            ctx.datasets[name] = visible
            if name == "financial":
                ctx.financial_data = visible
        return ctx

    def _excluded(self, stock: Stock, stamp: pd.Timestamp, historical: bool) -> str | None:
        if historical:
            return None
        if self.settings.exclude_st and stock.is_st:
            return "ST/*ST excluded by universe settings"
        if self.settings.exclude_inactive and stock.status.lower() in {"delisted", "inactive", "listing_suspended", "terminated"}:
            return f"Listing status excluded: {stock.status}"
        if self.settings.min_listed_days:
            if stock.list_date is None:
                raise DataError("Listing age filter enabled but list_date unavailable")
            if (stamp.date() - stock.list_date).days < self.settings.min_listed_days:
                return "Listing age below configured minimum"
        return None

    def screen(self, strategy: Strategy | str, symbols=None, as_of=None, refresh_quotes=True, persist=True) -> list[ScreenResult]:
        started = perf_counter()
        if isinstance(strategy, str):
            strategy = self.strategies.get(strategy)
        historical = as_of is not None
        if historical and symbols is None:
            raise ValueError("Historical replay requires explicit symbols; current A-share universe is not point-in-time metadata.")
        if not historical:
            self.universe()  # Apply current metadata filters even to explicit watchlists.
        selected = list(dict.fromkeys(self.provider.normalize_symbol(s) for s in (symbols if symbols is not None else [s.symbol for s in self.universe()])))
        request_errors: dict[str, str] = {}
        if refresh_quotes and not historical:
            try:
                updated = self.provider.get_realtime_quotes(selected) if selected else {}
                self.quotes.update_many(updated)
                request_errors = {s: "Batch quote response omitted this symbol" for s in selected if s not in updated}
                self.last_update = now_shanghai()
            except Exception as exc:
                log.exception("batch_quote_update_error")
                request_errors = dict.fromkeys(selected, str(exc))
        stamp = as_timestamp(as_of if historical else now_shanghai())
        strategy_digest = hashlib.sha256(strategy.model_dump_json().encode()).hexdigest()
        required_datasets = sorted({name for rule in strategy.rules.leaves()
                                   for name in self.factors.get(rule.factor, rule.factor_version).metadata.required_datasets})
        quote_cacheable = all(self.factors.get(rule.factor, rule.factor_version).metadata.cache_policy == "quote"
                              for rule in strategy.rules.leaves())
        market_status = self.calendar.market_status(stamp)
        results, reused = [], 0
        for symbol in selected:
            stock = self._stock(symbol, historical)

            def error(status, reason):
                quote = None if historical else self.quotes.get(symbol)
                return ScreenResult(symbol=symbol, name=stock.name, as_of=stamp.to_pydatetime(), status=status, reason=reason,
                                    latest_price=quote.latest_price if quote else None,
                                    quote_timestamp=quote.timestamp if quote else None, received_at=quote.received_at if quote else None,
                                    strategy_id=strategy.strategy_id, strategy_version=strategy.version, provider=self.provider.name)
            try:
                excluded = self._excluded(stock, stamp, historical)
                if excluded:
                    results.append(error("EXCLUDED", excluded))
                    continue
                if symbol in request_errors:
                    results.append(error("DATA_ERROR", request_errors[symbol]))
                    continue
                quote = None if historical else self.quotes.get(symbol)
                if not historical and quote is None:
                    raise DataError("No quote in cache; run batch quote refresh")
                if quote and quote.suspended:
                    results.append(error("SUSPENDED", "Provider marks stock suspended"))
                    continue
                if quote and quote.timestamp is None:
                    raise DataError("Provider exchange timestamp unavailable; freshness cannot be established")
                if quote and quote.timestamp > stamp:
                    raise DataError("Provider quote timestamp is in the future")
                stale = False
                if quote:
                    age = max(0, (stamp - quote.timestamp).total_seconds())
                    if market_status == "OPEN":
                        stale = age > self.settings.quote_stale_seconds
                    else:
                        expected = self.calendar.last_session(stamp.date())
                        if market_status == "PRE_OPEN":
                            expected = self.calendar.previous_session(stamp.date())
                        expected_time = as_timestamp(expected)
                        if market_status == "LUNCH_BREAK":
                            expected_time = expected_time.replace(hour=11, minute=30)
                        stale = (expected_time - quote.timestamp).total_seconds() > self.settings.quote_stale_seconds
                bars = self._load_history(symbol)
                if bars.empty:
                    results.append(error("NOT_ENOUGH_DATA", "No cached history; download historical data first"))
                    continue
                visible = bars.loc[(bars.index <= pd.Timestamp(stamp.date())) & (bars.available_at <= stamp)]
                if quote:
                    prior = visible.loc[visible.index < pd.Timestamp(quote.timestamp.date())]
                    expected_prior = self.calendar.previous_session(quote.timestamp.date())
                    if prior.empty or prior.index[-1].date() < expected_prior:
                        raise DataError("History cache lacks the previous exchange session; update history or verify a suspension/data gap")
                elif historical:
                    expected_end = self.calendar.last_session(stamp.date())
                    if stamp.time() < time(15) and expected_end == stamp.date():
                        expected_end = self.calendar.previous_session(stamp.date())
                    if visible.empty or visible.index[-1].date() < expected_end:
                        raise DataError("Historical endpoint bar unavailable; cannot silently substitute an earlier session")
                key = strategy_digest + str(stamp if historical else stamp.date()) + self.settings.adjustment_mode + str(id(bars))
                if quote:
                    key += quote.model_dump_json(exclude={"received_at", "timestamp", "provider_timestamp"})
                    key += str(quote.timestamp.date()) + str(quote.timestamp.time() >= time(15))
                cached = self._result_cache.get(symbol)
                if cached and cached[0] == key and quote_cacheable and not required_datasets:
                    result = cached[1].model_copy(deep=True)
                    result.as_of = stamp.to_pydatetime()
                    if quote:
                        result.received_at = quote.received_at
                        result.quote_timestamp = quote.timestamp
                    result.metadata["reused_unchanged_inputs"] = True
                    reused += 1
                else:
                    context = self.context(symbol, stamp if historical else None, required_datasets)
                    if self.settings.min_average_amount_20d:
                        completed = context.daily_bars.loc[~context.daily_bars.is_partial]
                        if len(completed) < 20 or completed.amount.tail(20).isna().any():
                            raise DataError("20-session liquidity filter requires 20 known completed amounts")
                        if completed.amount.tail(20).mean() < self.settings.min_average_amount_20d:
                            results.append(error("EXCLUDED", "20-session mean amount below configured minimum"))
                            continue
                    result = self.screener.screen_context(stock, context, strategy, self.provider.name)
                    self._result_cache[symbol] = (key, result.model_copy(deep=True))
                if stale:
                    result.status = "STALE"
                    result.reason = "Quote older than allowed freshness; factor values shown for inspection only"
                if quote:
                    result.quote_timestamp = quote.timestamp
                    result.received_at = quote.received_at
                    result.metadata.update(quality=quote.quality, provider_timestamp=quote.provider_timestamp.isoformat() if quote.provider_timestamp else None,
                                           quote_age_seconds=age, reported_latency_seconds=quote.reported_latency_seconds,
                                           latency_note="Receive minus exchange timestamp is observed age, not measured transport delay")
                results.append(result)
            except Exception as exc:
                log.exception("symbol_screen_error symbol=%s", symbol)
                results.append(error("DATA_ERROR", str(exc)))
        results.sort(key=lambda r: (r.status != "PASS", r.symbol))
        elapsed = perf_counter() - started
        self.last_results = results
        self.last_scan_stats = {"stocks": len(selected), "scanned": len(results), "passed": sum(r.status == "PASS" for r in results),
                                "errors": sum(r.status not in ("PASS", "FAIL", "EXCLUDED") for r in results),
                                "reused": reused, "elapsed_seconds": round(elapsed, 3), "market_status": market_status}
        if persist and results:
            self.last_scan_stats["run_id"] = self.research.save_run(strategy, results, "historical_replay" if historical else "manual")
        log.info("scan_complete %s", self.last_scan_stats)
        return results
