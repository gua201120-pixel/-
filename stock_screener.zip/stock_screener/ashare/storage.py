"""Historical performance foundation: immutable, reproducible screening snapshots."""
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

from ashare.models import ScreenResult, now_shanghai
from ashare.strategies.schema import Strategy


class ResearchStore:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS runs (
                  run_id TEXT PRIMARY KEY, recorded_at TEXT, strategy_snapshot TEXT, mode TEXT);
                CREATE TABLE IF NOT EXISTS results (
                  run_id TEXT, symbol TEXT, status TEXT, snapshot TEXT,
                  PRIMARY KEY(run_id, symbol));
                CREATE TABLE IF NOT EXISTS outcomes (
                  run_id TEXT, symbol TEXT, horizon INTEGER, return_value REAL,
                  computed_at TEXT, PRIMARY KEY(run_id, symbol, horizon));
            """)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        try:
            with db:
                yield db
        finally:
            db.close()

    def save_run(self, strategy: Strategy, results: list[ScreenResult], mode: str) -> str:
        run_id = str(uuid4())
        with self.connect() as db:
            db.execute("INSERT INTO runs VALUES (?, ?, ?, ?)", (run_id, now_shanghai().isoformat(), strategy.model_dump_json(), mode))
            db.executemany("INSERT INTO results VALUES (?, ?, ?, ?)", [(run_id, r.symbol, r.status, r.model_dump_json()) for r in results])
        return run_id
