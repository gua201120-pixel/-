"""Shared future fundamental adapter utility: knowledge date, not fiscal date."""
import pandas as pd

from ashare.models import as_timestamp


def known_observations(frame: pd.DataFrame, as_of) -> pd.DataFrame:
    if "available_at" not in frame:
        raise ValueError("Point-in-time observations require available_at")
    if any(pd.Timestamp(value).tzinfo is None for value in frame.available_at):
        raise ValueError("available_at must be timezone-aware")
    times = pd.to_datetime(frame.available_at, utc=True, errors="coerce")
    if times.isna().any():
        raise ValueError("Missing/invalid available_at")
    result = frame.loc[times <= as_timestamp(as_of)].copy()
    # Keep original vintages. A revision after as_of cannot overwrite earlier known values.
    return result.sort_values("available_at")
