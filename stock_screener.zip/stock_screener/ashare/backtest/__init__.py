"""Signal replay and outcome labels, deliberately separate from signal inputs."""
