from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ashare.service import ResearchService


def replay(service: ResearchService, strategy, symbols: list[str], dates):
    """Explicit-symbol signal replay; not a survivorship-free universe backtest."""
    if not symbols:
        raise ValueError("Provide explicit historical symbols")
    for day in dates:
        yield service.screen(strategy, symbols=symbols, as_of=str(day)[:10], refresh_quotes=False)
