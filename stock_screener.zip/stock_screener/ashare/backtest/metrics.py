from __future__ import annotations

import numpy as np
import pandas as pd

from ashare.data.calendar import ExchangeCalendar


def forward_returns(bars: pd.DataFrame, signal_date, horizons=(5, 10, 20, 60), calendar=None) -> dict:
    """Close-to-close research labels on exchange sessions, not executable returns.

    No endpoint bar (e.g. suspension) means no label. These future observations
    must never be fed into a FactorContext at signal time.
    """
    calendar = calendar or ExchangeCalendar()
    start = pd.Timestamp(signal_date).tz_localize(None).normalize()
    if start not in bars.index or not np.isfinite(bars.at[start, "close"]) or bars.at[start, "close"] <= 0:
        raise ValueError("Signal date requires a valid closing price")
    sessions = calendar.sessions(start, calendar.last_date)
    answer = {}
    for horizon in horizons:
        if horizon < 1:
            raise ValueError("Forward horizon must be positive")
        endpoint = sessions[horizon] if len(sessions) > horizon else None
        ret, mdd = None, None
        if endpoint is not None and endpoint in bars.index:
            price = float(bars.at[endpoint, "close"])
            if np.isfinite(price) and price > 0:
                ret = price / float(bars.at[start, "close"]) - 1
                path = bars.loc[start:endpoint, "close"].to_numpy(dtype=float)
                mdd = float(np.min(path / np.maximum.accumulate(path) - 1))
        answer[str(horizon)] = {"endpoint": str(endpoint.date()) if endpoint is not None else None,
                                "return": ret, "maximum_drawdown": mdd,
                                "basis": "exchange-session close-to-close, no costs or execution model"}
    return answer


def summarize(returns: list[float | None]) -> dict:
    valid = np.array([r for r in returns if r is not None and np.isfinite(r)], dtype=float)
    if not len(valid):
        return {"count": 0, "win_rate": None, "average_return": None, "median_return": None, "hit_ratio": None}
    return {"count": len(valid), "win_rate": float((valid > 0).mean()), "average_return": float(valid.mean()),
            "median_return": float(np.median(valid)), "hit_ratio": float((valid > 0).mean())}
