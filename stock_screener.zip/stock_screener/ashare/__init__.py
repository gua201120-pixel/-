"""Personal A-Share Quantitative Research & Screening System."""
__version__ = "0.1.0"
