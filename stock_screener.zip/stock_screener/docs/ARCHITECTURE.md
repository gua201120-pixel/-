# Architecture decision record — 2026-09-11

This is a new repository. Implementation follows this review; no pre-existing code was found.

## Boundaries

`MarketDataProvider -> QuoteCache + BarStore -> ContextBuilder -> FactorRegistry -> RuleEngine -> Screener -> UI`

1. Python 3.12+, pandas/numpy, Pydantic, Parquet, SQLite, Streamlit, Plotly, pytest; no trading or order execution.
2. `ashare/data` owns supplier adapters, timestamp/unit normalization, calendar, incremental storage and aggregation. `ashare/factors` sees only FactorContext. `ashare/strategies` owns versioned JSON schemas. `ashare/screening` orchestrates without factor-specific branches. `ashare/backtest` separates future outcome labels from signal inputs.
3. Providers expose stock universe, historical daily bars, batch quotes, optional financial observations and streaming protocol. Quotes carry exchange/provider/receive time separately. Unknown timestamps stay unknown. Default development feed is public, delay uncertified; mock is visibly synthetic.
4. Historical bars have session date index and `available_at`. Realtime context excludes the historical current day then replaces it with one cumulative quote-derived bar. Repeated ticks replace volume, never add the daily cumulative volume again.
5. Weekly/monthly bars are derived from the same daily price series. Current calendar period is partial until its last exchange session closes. Missing/suspended days are never forward-filled as new transactions.
6. Factors return typed raw value, passed, status, reason, parameters, version, input details and data timestamp. Boolean, numeric and categorical outputs use the same interface. Error/insufficient data is not ordinary FAIL.
7. A registry instantiates registered factors. Plugin modules allow adding factor #100 without changing the screener or existing strategies.
8. Strategy JSON supports recursive AND/OR, typed operators, enabled rules, per-rule factor parameters and pinned factor versions. New immutable versions preserve reproducible parameter snapshots.
9. Screener fetches quotes in batches. Historical warm-up is explicit and throttled; a refresh does no network history downloads. Completed-period aggregates and unchanged factor results are cached. The five-second refresh is a target, not a guaranteed full-universe public-API SLA.
10. Scanner schedules outside continuous trading at lower frequency/no quote polling. Exceptions are isolated by symbol. Streamlit uses a timed fragment and start/stop state.
11. SQLite stores immutable strategy/run/result snapshots. Parquet holds normalized historical series and acquisition provenance. Quote cache is in-memory and rejects out-of-order updates; intraday persistence is an extension point for same-time volume.
12. Historical requests only see bars/financial observations available by `as_of`. A daily OHLC cannot reconstruct a past 10:30 quote; past intraday without a recorded quote fails closed. Fundamentals require publication/available timestamps, not report-period dates.
13. Raw is the default coherent price basis. qfq/hfq require a provider policy capable of converting both bars and realtime prices and proving point-in-time corporate-action factors; unsupported combinations fail explicitly. Never splice a raw quote onto adjusted history. Retrospectively adjusted public history is not asserted point-in-time safe.
14. ZigZag runs forward on the available prefix with explicit pivot occurrence and confirmation times. Current endpoint is tentative; no completed future week is used for earlier signals. Historical daily final values appear only after session close. Public current-universe replay carries a survivorship-bias limitation and is not an audited historical-universe backtest.
15. Tests cover aggregation/holidays/suspension, eight factor definitions, operators and nested groups, strategy immutability, quote updates, batching/cache behavior and prefix invariance. Live adapter probe and UI smoke are reported separately from deterministic tests.

## Acceptance review

New factors require subclass + registry/plugin registration; new suppliers implement the provider contract. The same context/factor path serves historical and realtime. Partial week/month are included, whole-universe scans are supported after cache warm-up, and explanations retain raw values. Backtest outcomes are computed outside the factor context. Data that cannot meet point-in-time guarantees is explicitly identified or rejected.

## Technical risks

- Public feeds have no contractual latency, uptime or rate-limit guarantee; provide visible timestamps and errors, bounded retries, backoff and a paid-provider replacement point.
- Full-market initial history requires many requests and can be slow. Persist successful symbols; resume warm-up, do not redownload every refresh.
- Current public constituent metadata is not a historical security master. Delisted names, ST history and announcement vintages require a licensed PIT dataset.
- Raw prices cross ex-rights gaps. Adjusted mode requires synchronized corporate actions. Unsupported adjustment is an error, never a silent fallback.
- An exchange calendar has a finite validated range; outside it return UNKNOWN instead of treating weekdays as certainly open.
- MVP incrementality caches completed data and unchanged evaluations; arbitrary future plugins may require additional vectorized kernels. Benchmark before promising 5-second all-market latency.

## References

- AKShare official documentation: https://akshare.akfamily.xyz/data/stock/stock.html
- SSE 2026 calendar: https://www.sse.com.cn/disclosure/announcement/general/c/c_20251222_10802507.shtml
