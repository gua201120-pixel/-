"""Run with: streamlit run app.py"""
from __future__ import annotations

import logging

import streamlit as st

from ashare.service import ResearchService
from ashare.settings import Settings
from ashare.ui.common import CSS, PAGES, market_text
from ashare.ui.pages import dashboard, factors_page, realtime_page, settings_page, stock_detail, strategies_page
from ashare.ui.workspace import factor_panel

st.set_page_config(page_title="A-SHARE LAB · 因子研究与实时筛选", page_icon="◈", layout="wide", initial_sidebar_state="expanded")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
st.markdown(CSS, unsafe_allow_html=True)

if "research_service" not in st.session_state:
    try:
        st.session_state["research_service"] = ResearchService(Settings())
    except Exception as exc:
        st.error(f"研究系统初始化失败：{exc}")
        st.info("请检查 .env 的 MARKET_DATA_PROVIDER、ADJUSTMENT_MODE 与 STORAGE_DIR。离线演示可显式设置 MARKET_DATA_PROVIDER=mock。")
        st.stop()

service = st.session_state["research_service"]
with st.sidebar:
    st.markdown('<div class="eyebrow">PERSONAL QUANT WORKSPACE</div><div class="brand">◈ A-SHARE LAB</div><div class="subbrand">因子研究 · 策略构建 · 实时观察</div>', unsafe_allow_html=True)
    st.divider()
    page = st.selectbox("研究工作台", list(PAGES), label_visibility="collapsed", key="page_navigation")
    st.divider()
    factor_panel(service)
    st.divider()
    st.caption("DATA CONNECTION")
    st.write(service.provider.name)
    quality = getattr(service.provider, "quality", "unknown")
    st.caption({"simulated": "🧪 SIMULATED · 模拟数据", "realtime": "REALTIME · 供应商标记实时", "delayed": "DELAYED · 延迟行情", "unknown": "DEVELOPMENT · 延迟未认证"}.get(quality, str(quality)))
    st.caption(f"市场：{market_text(service)}")
    st.caption(f"价格口径：{service.settings.adjustment_mode.upper()} · Asia/Shanghai")
    st.divider()
    st.caption("修改左侧因子后，可立即重算或另存新版本。")
    st.caption("研究工具 · 不包含下单或账户功能")

views = {"dashboard": dashboard, "factors": factors_page, "strategies": strategies_page, "realtime": realtime_page, "detail": stock_detail, "settings": settings_page}
views[PAGES[page]](service)
