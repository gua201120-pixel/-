# Personal A-Share Quantitative Research & Screening System

这是一个可扩展的 A 股因子研究与盘中筛选工作台。数据接入、K 线、Factor、Strategy、Rule Engine 和 UI 独立；第一套多周期策略只是配置文件。支持沪、深、北交所股票池，批量行情，日/周/月未完成 K 线，因子解释，策略版本和历史信号记录。

**当前默认开发源是真实公开行情，但延迟、交易所时钟精度及服务等级未经认证。`mock` 是明确标注的模拟数据。** 不包含交易下单。免费 API 不保证全市场每 5 秒完成一轮；实际耗时在 UI 显示。

## 安装 / Installation

需要 Python 3.12 或更新版本。已在 Windows + Python 3.13 验证。进入本项目目录，在 PowerShell 执行：

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m streamlit run app.py
```

本次交付目录已经安装 `.venv`，可以直接执行最后一行，或双击 `启动界面.cmd`。浏览器地址为 `http://localhost:8501`。Linux/macOS 用 `python3 -m venv .venv` 和 `.venv/bin/python`。`requirements-lock.txt` 记录本次验收环境的精确依赖；跨平台建议优先 `requirements.txt`。

## 第一次运行

新版首页是「股票筛选工作台」：中央显示中文股票结果，左侧固定「我的筛选因子」。可按股票名称/代码搜索，筛选入选、未入选、数据异常，或切换到因子对照表。点选股票后，下面直接显示每项判断、当前值和计算依据。

展开左侧因子即可输入参数并启用/关闭。`应用修改` 创建会话草稿；`应用并重算` 用最近缓存行情重算上次股票范围。结果尚未重算时会显示提示。用「保存当前修改为新版本」写入策略库，原版本保留；所有页面共享这个当前策略。

1. Settings 选择 `development` 真实开发源，或明确选择 `mock` 模拟源。
2. Realtime Screener 点击加载股票池。全市场模式不截取前 N 只。
3. 首次运行点击下载/更新历史。全市场历史需要大量请求，建议先用 `sh600000,sz000001,sh688001,bj920001` 验证网络，再下载全部。成功下载的股票保留缓存，中断后重试会补未完成区间。
4. 左侧选择 `multi_timeframe_trend_setup_v1 @ 1.0.0`，点击「运行筛选」。没有历史的股票标 `NOT_ENOUGH_DATA`，不会冒充扫描通过。
5. 点击 Start 开始定时刷新，Stop 停止。非连续交易时间开发源进入等待状态；Run Once 仍可手动查看最近行情。Mock 可在休市时演示流程。
6. Stock Detail 查看日/周/月 K 线和所有因子输入、输出、参数及失败原因。
7. Strategy Builder 修改规则/阈值/参数，填写新版本后保存。已存在版本拒绝覆盖。

## 配置 / Environment / API Credentials

复制 `.env.example` 为 `.env`；不提交 `.env`。应用不显示 token 原文。

| 配置 | 默认 | 说明 |
|---|---|---|
| `MARKET_DATA_PROVIDER` | development | development / mock；正式供应商通过注册扩展 |
| `REALTIME_REFRESH_SECONDS` | 5 | 调度间隔；取与供应商最小间隔的较大值，上一轮完成后再调度 |
| `QUOTE_STALE_SECONDS` | 120 | 连续交易时行情最大可接受年龄；超时为 STALE |
| `ADJUSTMENT_MODE` | raw | 当前只实现统一 raw；qfq/hfq 明确拒绝 |
| `HISTORY_START` | 2021-01-01 | 至少需要 20 个有交易的月观察值才能计算 MA20 |
| `HISTORY_WORKERS` | 2 | 有界历史下载并发，并有供应商总请求节流 |
| `STORAGE_DIR` | storage | Parquet、股票池缓存和 SQLite |
| `EXCLUDE_ST` / `EXCLUDE_INACTIVE` | true | 当前股票池的基础过滤，不写进策略 |
| `MIN_LISTED_DAYS` | 0 | 默认关闭；公开源缺少上市日期时，启用后明确报数据不足 |
| `MIN_AVERAGE_AMOUNT_20D` | 0 | 默认关闭，单位元 |
| `FACTOR_PLUGINS` | 空 | 逗号分隔的插件模块，如 examples.custom_factor |
| `TUSHARE_TOKEN` / `BROKER_API_KEY` | 空 | 预留凭证槽；仅填写 token 不会自动安装/启用适配器 |

UI 的 Settings 修改当前会话配置，不静默写入 `.env`。持久默认值请编辑 `.env`。

## Data Provider / Realtime vs Delayed Data

`development` 通过腾讯公开接口获取沪深北全 A 股票池、批量最新行情和不复权日线，使用带超时的 httpx 适配器。每批最多 200 个代码；没有逐股票取实时 quote 的扫描循环。请求采用有界重试和间隔控制，单批/单股异常在结果中展示。

行情字段包括 OHLC、昨收、累计成交量/额、涨跌、买卖价和供应商时间。内部价格单位元，成交量单位股，成交额单位元。STAR 与其他板块的上游成交量单位不同，适配器统一转换，并对历史成交额/量隐含均价做校验。

- `Quote.timestamp`：上游报价记录时间；公开接口不能证明是交易所原始撮合时间。
- `provider_timestamp`：供应商时间；此开发源与报价记录时间相同。
- `received_at`：本机收到数据的时间。
- 估算年龄是本机接收/计算时间减供应商时间，**不是经过认证的网络延迟**。不提供独立 `reported_latency_seconds` 时显示未知。
- 股票池缓存 24 小时；公开列表不能提供完整历史上市/退市/暂停上市状态。行业、上市日未提供时为空，不能猜测填值。
- 供应商失败绝不自动切换为 mock；UI 显示具体失败。

数据格式参考 [AKShare 官方源码（腾讯股票）](https://github.com/akfamily/akshare/blob/main/akshare/stock/stock_zh_a_tx.py)及[历史行情源码](https://github.com/akfamily/akshare/blob/main/akshare/stock_feature/stock_hist_tx.py)。交易日历使用 exchange_calendars 历史日期，加上[上交所 2026 年休市安排](https://www.sse.com.cn/disclosure/announcement/general/c/c_20251222_10802507.shtml)。当前明确覆盖 2000–2026；超出覆盖范围返回 UNKNOWN/错误，不把工作日自动当开市。

## 下载历史 / Download Historical Data

```powershell
# 先验证真实源；股票代码规范是 sh/sz/bj + 六位数字
.\.venv\Scripts\python.exe main.py probe --provider development --symbols sh600000,sz000001,sh688001,bj920001

# 全部 A 股初始下载；后续相同命令仅补未覆盖的区间
.\.venv\Scripts\python.exe main.py download --provider development

# 少量观察名单
.\.venv\Scripts\python.exe main.py download --provider development --symbols sh600000,sz000001

# 完全离线的模拟数据流程
.\.venv\Scripts\python.exe main.py download --provider mock
.\.venv\Scripts\python.exe main.py screen --provider mock --output storage/mock-results.json
```

日线保存在 `storage/bars/<provider>/<adjustment>/`，附来源、获取时间、覆盖区间与内容 revision。历史下载与实时刷新分开；第二次下载不会重复请求已完成的覆盖区间。只存已完成日线，当前 partial quote 不覆盖历史文件。

每天开盘前或收盘后更新一次历史缓存；跨交易日连续运行时，先 Stop → 更新历史 → Start。当前不会在 5 秒行情循环里隐式下载缺失的日线。

## Run Screen / Historical Mode

```powershell
.\.venv\Scripts\python.exe main.py screen --provider development --output storage/results.json
.\.venv\Scripts\python.exe main.py screen --provider development --symbols sh600000,sz000001 --as-of 2025-06-30 --output storage/replay.json
.\.venv\Scripts\python.exe main.py factors
.\.venv\Scripts\python.exe main.py strategies
```

日期 `2025-06-30` 表示北京时间当天 15:00。历史筛选必须提供明确的股票代码，以免把今天的 ST/成分股属性当成历史事实；这只是显式股票的历史信号回放，**不是无幸存者偏差的全市场回测**。

日线按日期和 `available_at <= as_of` 双重截断。过去 10:30 的状态无法从最终日 OHLC 重建，没有保存的同期 quote 时明确报错。当前周/月由可见日线重新聚合；月末日期不能让整个月数据提前出现。未来财务数据必须带公告可知时间，`known_observations()` 演示按可知时间选择版本，不能使用报告期结束日替代。

公开历史 K 线的可知时间暂按收盘 15:00 建模，无法证明历史修订版的真实发布时间。真实的机构级 PIT 需要历史数据版本、复权事件版本、历史证券主表和记录的盘中行情；这些限制保存在结果 metadata 中。

## Architecture Summary

| 模块 | 责任 |
|---|---|
| `ashare/data` | Provider 接口/注册、开发与模拟源、Quote Cache、Parquet、交易日历、日周月聚合 |
| `ashare/factors` | 纯计算接口、参数校验、版本注册、8 个因子、缓存 |
| `ashare/strategies` | JSON schema、递归规则组、SQLite 不可变版本 |
| `ashare/screening` | 通用规则引擎、单股隔离、调度/退避/状态变化记录 |
| `ashare/service.py` | 应用编排，批量行情、缓存复用、股票池过滤 |
| `ashare/ui` / `app.py` | 六个 Streamlit 页面、图表、参数编辑及结果导出 |
| `ashare/backtest` | 历史信号回放、未来收益标签和统计；不把未来标签传给因子 |
| `ashare/storage.py` | 历史信号、策略快照和研究数据库基础 |

详细决策与验收映射见 `docs/ARCHITECTURE.md`。所有 Factor 都只接收 `FactorContext`；切换供应商不更改 Factor 或 Screener。

## Current Factors / Strategy #1

策略 `multi_timeframe_trend_setup_v1`，初始版本 `1.0.0`，名称「多周期趋势回调启动」。以下八项全部 `passed == true`，AND 硬筛选，无评分：

| Factor ID | 默认定义 |
|---|---|
| monthly_ma_bullish_alignment | 当前月 MA5 > MA10 > MA20 |
| price_above_monthly_ma5_ma10 | 当前价分别大于 5 月/10 月 MA |
| swing_gain_below_100pct | 周收盘 ZigZag 阈值 10%，最近有效低点到上涨高点比例 < 2 |
| weekly_ma10_rising | 当前 10 周 MA > 上一周 10 周 MA |
| weekly_pullback | 12 周 high 回撤幅度 5%–25%，且 10 周 MA 斜率 > 0 |
| daily_ma5_cross_ma10 | 当日 MA5 > MA10，前一交易观察日 MA5 <= MA10 |
| daily_macd_above_zero | 12/26/9，DIF > 0 且 DEA > 0 |
| daily_volume_expansion | 今日累计成交量 / 前一交易观察日总量 >= 1.5 |

均线为简单算术平均。MACD 使用 pandas `ewm(adjust=False)` 的递推定义，首个 close 初始化 EMA，histogram = 2 × (DIF−DEA)，并要求足够 warm-up 数据。金叉使用今日 partial close；成交量不进行全天预测。

回调同时输出负值 signed return 和正值回调幅度 `1-price/high`，阈值作用于正幅度。周 ZigZag 使用 **周收盘路径**，不是周内影线最高/最低：只凭周 OHLC 不知道高低点的先后顺序，不能声称识别了该顺序。pivot 出现时间、确认时间、当前 tentative/provisional 状态明确区分。当前未完成周形成的确认仍为临时状态，可以随价格变化撤回；历史计算只读取当时前缀。此定义和以后基于日内路径的 ZigZag 可以分别注册为不同因子版本。

## Adjustment Mode

当前只支持统一 `raw`。默认日线、周月聚合、quote 和所有技术指标均为不复权价格。除权除息会造成 raw 价格跳变，可能影响 MA、MACD、ZigZag 信号。

Settings 保留 `raw/qfq/hfq`。选择未支持的模式会明确失败，不会偷偷退回 raw。未来适配器需同时提供截至 `as_of` 已知的公司行动、基准锚点、历史/实时价格转换；公共接口当下的前复权历史不能直接宣称是过去的 PIT 数据。

## Add a New Factor：完整可运行示例

示例文件 `examples/custom_factor.py` 已包含以下完整实现：

```python
from pydantic import Field
from ashare.factors.base import BaseFactor, FactorParameters, checked_bars
from ashare.models import FactorMetadata

class Params(FactorParameters):
    lookback_days: int = Field(20, ge=1, le=252)
    maximum_return: float = Field(0.15, gt=-1)

class ReturnLimit(BaseFactor):
    Parameters = Params
    metadata = FactorMetadata(
        factor_id="daily_return_below_limit", name="阶段涨幅不超过上限",
        description="最新价相对N个交易观察日前的涨幅",
        category="custom", timeframe="daily", output_type="numeric",
        supports_realtime=True, version="1.0.0",
        default_parameters=Params().model_dump(),
    )

    def _calculate(self, context, params):
        bars = checked_bars(context, "daily", params.lookback_days + 1)
        base = float(bars.close.iloc[-params.lookback_days - 1])
        price = float(bars.close.iloc[-1])
        value = price / base - 1
        passed = value <= params.maximum_return
        return passed, value, {"base_price": base, "price": price}, f"Return {value:.2%}"

def register(registry):
    registry.register(ReturnLimit)
```

在 `.env` 设置 `FACTOR_PLUGINS=examples.custom_factor`，重启应用。新因子会出现在 Factor Library 和 Strategy Builder，无需修改 Screener。示例中的涨幅因子只演示涨幅条件；不冒充“量逐渐放大且涨幅受限”的完整策略。实际示例文件还包含输入窗口明细。

Factor 支持 boolean/numeric/categorical 输出；规则用 `field="value"` 比较原始结果，或 `field="passed"` 比较因子自己的判定。参数使用 Pydantic，未知参数拒绝。新增 fundamental/valuation 等类别沿用同一接口，通过 `financial_data`/`metadata` 获取已准备好的 PIT 数据；严禁因子自行请求 API。

需要财务数据的因子在 metadata 声明 `required_datasets=["financial"]`。Service 自动调用 Provider 的 `get_dataset()`、缓存并按 `available_at` 截断，通过 `context.financial_data` / `context.datasets` 提供数据；新增该类因子不需要修改 Screener。当前开发源尚未提供真实财务数据，空数据应返回 NOT_ENOUGH_DATA。辅助数据当前缓存 1 小时，盘中事件/同时间量比正式接入时需配置专用刷新与持久化政策。

新因子默认 `cache_policy="as_of"`，会随评估时间重新计算，适合预测全天量等依赖时间的因子。只有确认输出完全取决于行情及历史输入时才声明 `cache_policy="quote"`，以复用未变化的结果；当前 8 个技术因子采用这一策略。复用时保留原始计算时间，并显示本轮最新 Quote 时间，不伪造重新计算记录。

## Add a New Strategy：完整示例

在 Strategy Builder 选择 JSON 编辑器；上方名称填写「量能确认示例」、Strategy ID 填写 `volume_confirmation`、新版本填写 `1.0.0`，再粘贴下列配置保存。上方的名称、ID 和版本会覆盖 JSON 的同名字段：

```json
{
  "strategy_id": "volume_confirmation",
  "name": "量能确认示例",
  "version": "1.0.0",
  "rules": {
    "logic": "AND",
    "rules": [{
      "factor": "daily_volume_expansion",
      "factor_version": "1.0.0",
      "field": "value",
      "operator": ">=",
      "value": 1.8,
      "params": {"minimum_ratio": 1.5},
      "enabled": true
    }]
  }
}
```

这里策略阈值 1.8 与 Factor 自己的默认判定 1.5 是独立的，两者都会显示。也可以通过 Python 保存：

```python
from ashare.service import ResearchService
from ashare.settings import Settings
from ashare.strategies.schema import Strategy

service = ResearchService(Settings())
strategy = Strategy.model_validate_json(open("my_strategy.json", encoding="utf-8").read())
service.strategies.save(strategy)
```

支持 `== != > >= < <= between not_between in not_in` 与递归 AND/OR。`between` 两端包含；`not_between` 是其补集。`passed` 仅允许布尔比较，数值条件使用 `value`。规则禁用不会执行该因子；禁止保存没有有效规则的策略。相同 Factor 可在不同规则中使用不同参数。保存时固化默认参数和 Factor version；旧策略不因默认值变化而改变。

## 正式 Provider 接入

继承 `MarketDataProvider`，实现 `get_stock_list`、`get_daily_bars`、`get_realtime_quotes`，可选财务数据。返回统一 `Stock`/`Quote` 和日线 DataFrame：日期索引、OHLC、volume、amount、available_at、is_partial。通过 `register_provider("licensed", Factory)` 注册，然后创建 Settings。适配器读取 `.env` 凭证；不要将 SDK 调用放到因子中。

预留 `StreamingMarketDataProvider` 的订阅、退订、异步 quote 流协议。当前开发源仅轮询；没有宣称已实现 WebSocket 消费。未来流消费者应先更新 QuoteCache，再调用相同 ContextBuilder/Screener。盘中累计量和明确定时的原始 quote 可以持久化，扩展同一时刻量比/全天投影，无需改 Factor 接口。

## 数据新鲜度、异常和数据库

PASS 排在最前。FAIL 表示规则已计算但未满足。`NOT_ENOUGH_DATA`、`DATA_ERROR`、`SUSPENDED`、`STALE`、`EXCLUDED` 单独展示。任何未知/无效价格不得进入 PASS；单股错误不影响其余股票。一个 OR 分支已确认 PASS 时允许 OR 通过，其余分支的异常仍在明细中保留；必需 AND 分支数据未知时保留异常状态。

SQLite 保存手动/历史扫描的完整快照。实时模式保存首次状态和 PASS/FAIL/异常状态变化，**不会每 5 秒无限重复写入所有明细**；这是信号数据库基础，并非逐笔行情数据库。future-return 标签与信号输入隔离；`forward_returns()` 支持 5/10/20/60 个交易所交易日后收盘价、最大回撤，终点缺数据返回空。`summarize()` 提供胜率/均值/中位数/正收益占比。它们是收盘到收盘研究标签，尚无成交、滑点、费用或组合模型。

## Testing Status

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m pytest --cov=ashare --cov-report=term-missing
```

验收记录见 `docs/VALIDATION.md`。离线测试与真实接口探测分开；CI 不依赖免费接口在线。测试覆盖日周月部分周期、假期/停牌、8 因子、所有操作符、规则组合、版本不可变、真实解析格式、批量和缓存、盘中更新、历史截断及 UI。

## Known Limitations / Next Steps

1. P0：接入有授权、时延和频率保证的行情服务；添加行情健康监控、历史证券状态和交易所原始时间戳。
2. P0：接入可追溯公司行动和复权基准，实现 raw/qfq/hfq 一致的历史与实时转换。
3. P1：构建证券主表/公告/财报版本历史，以及原始 intraday quote 归档，完成可审计 PIT 回放和同时间量比。
4. P1：全市场预热后持续基准测试，按实际供应商容量优化列式批量因子计算和缓存；当前不承诺全股票都发生变化时 5 秒完成。
5. P1：历史缓存跨交易日刷新需要显式操作；缺数据不能当停牌自动填平，公开源也无法完全区分无交易和供应商漏数据。
6. P2：扩大因子库，接入财务/估值数据并增加参数版本对比与未来收益报表；自然语言生成因子尚未实现。
