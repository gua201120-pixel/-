@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please install the environment using README.md first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m streamlit run app.py
