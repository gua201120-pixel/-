"""Synthetic changed-quote microbenchmark; not a full-universe SLA measurement."""
import argparse
import json
from pathlib import Path
from time import perf_counter

from ashare.data.calendar import ExchangeCalendar
from ashare.data.context import ContextBuilder
from ashare.data.mock_provider import MockProvider
from ashare.data.resample import history_revision
from ashare.factors.registry import default_registry
from ashare.models import as_timestamp


def run(iterations=100):
    provider=MockProvider(as_of="2025-06-30 13:30")
    symbol="sh600000"
    bars=provider.get_daily_bars(symbol,"2021-01-01","2025-06-27")
    bars.attrs["historical_revision"]=history_revision(bars)
    quote=provider.get_realtime_quote(symbol)
    builder=ContextBuilder(ExchangeCalendar())
    factors=default_registry()
    context_seconds=factor_seconds=0
    for i in range(iterations+1):
        stamp=as_timestamp("2025-06-30 13:30")
        price=quote.latest_price*(1+(i%10)*.0001)
        updated=quote.model_copy(update={"latest_price":price,"high":max(quote.high,price),"volume":quote.volume+i*100})
        started=perf_counter()
        context=builder.build(symbol,bars,stamp,updated)
        elapsed_context=perf_counter()-started
        started=perf_counter()
        for metadata in factors.list():
            factors.get(metadata.factor_id).calculate(context)
        elapsed_factors=perf_counter()-started
        if i:
            context_seconds+=elapsed_context
            factor_seconds+=elapsed_factors
    return {"synthetic":True,"scope":"single-symbol changed-quote warm microbenchmark, not end-to-end full-market",
            "iterations":iterations,"history_rows":len(bars),"factors":len(factors.list()),
            "context_ms_per_symbol":context_seconds/iterations*1000,
            "eight_factors_ms_per_symbol":factor_seconds/iterations*1000,
            "total_ms_per_symbol":(context_seconds+factor_seconds)/iterations*1000,
            "excludes":"quote network, full-universe memory pressure, strategy evaluation, SQLite, UI rendering"}


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--iterations",type=int,default=100)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    if args.iterations<1:
        parser.error("iterations must be positive")
    result=json.dumps(run(args.iterations),indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(result,encoding="utf-8")
    print(result)
