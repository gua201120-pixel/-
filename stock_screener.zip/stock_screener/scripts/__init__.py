"""Reproducible diagnostics, separate from application logic."""
