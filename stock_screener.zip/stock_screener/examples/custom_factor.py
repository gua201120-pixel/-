"""Load with FACTOR_PLUGIN_MODULES=examples.custom_factor; no screener edit.

Example rule:
{"factor": "daily_return_below_limit", "factor_version": "1.0.0",
 "field": "passed", "operator": "==", "value": true,
 "params": {"lookback_days": 20, "maximum_return": 0.15}}
"""
from pydantic import Field

from ashare.factors.base import BaseFactor, FactorParameters, checked_bars, input_details
from ashare.models import FactorContext, FactorMetadata


class ReturnParameters(FactorParameters):
    lookback_days: int = Field(20, ge=1, le=252)
    maximum_return: float = Field(0.15, gt=-1)


class DailyReturnBelowLimitFactor(BaseFactor):
    Parameters = ReturnParameters
    metadata = FactorMetadata(
        factor_id="daily_return_below_limit", name="阶段涨幅不超过上限",
        description="最新价相对N个交易观察日前收盘价的涨幅，不超过可配置上限。",
        category="custom", timeframe="daily", output_type="numeric", version="1.0.0",
        default_parameters=ReturnParameters().model_dump(),
    )

    def _calculate(self, context: FactorContext, params: ReturnParameters):
        bars = checked_bars(context, "daily", params.lookback_days + 1)
        previous, latest = float(bars.close.iloc[-params.lookback_days - 1]), float(bars.close.iloc[-1])
        value = latest / previous - 1
        passed = value <= params.maximum_return
        return passed, value, {
            "base_price": previous, "latest_price": latest, "return_pct": value * 100,
            **input_details(bars, limit=params.lookback_days + 1),
        }, f"Return {value:.2%} <= {params.maximum_return:.2%}: {passed}"


def register(registry):
    registry.register(DailyReturnBelowLimitFactor)
