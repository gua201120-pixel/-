"""Executable extension examples."""
