"""CLI entry point. No network calls occur on import."""
import argparse
import json
import logging
import sys
from pathlib import Path

from ashare.service import ResearchService
from ashare.settings import Settings


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Personal A-Share factor research and screening")
    parser.add_argument("command", choices=["universe", "download", "screen", "factors", "strategies", "probe"])
    parser.add_argument("--provider", choices=["development", "mock"], default=None)
    parser.add_argument("--symbols", help="Comma-separated provider symbols; omit for all A shares")
    parser.add_argument("--strategy", default="multi_timeframe_trend_setup_v1")
    parser.add_argument("--version")
    parser.add_argument("--as-of", help="Historical date (close) or Shanghai-aware timestamp; explicit symbols required")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--storage-dir", type=Path)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    overrides = {}
    if args.provider:
        overrides["market_data_provider"] = args.provider
    if args.storage_dir:
        overrides["storage_dir"] = args.storage_dir
    service = ResearchService(Settings(**overrides))
    symbols = [s.strip() for s in args.symbols.split(",") if s.strip()] if args.symbols else None
    if args.command == "universe":
        output = [s.model_dump(mode="json") for s in service.universe()]
    elif args.command == "download":
        output = service.warm_history(symbols, progress=lambda i, n, s, status: print(f"[{i}/{n}] {s}: {status}", flush=True))
    elif args.command == "factors":
        output = [f.model_dump(mode="json") for f in service.factors.list()]
    elif args.command == "strategies":
        output = [s.model_dump(mode="json") for s in service.strategies.list()]
    elif args.command == "probe":
        universe = service.universe()
        selected = symbols if symbols is not None else [s.symbol for s in universe[:3]]
        quotes = service.provider.get_realtime_quotes(selected)
        output = {"provider": service.provider.name, "quality": service.provider.quality,
                  "minimum_poll_seconds": service.provider.min_poll_seconds, "universe_count": len(universe),
                  "quotes": {s: q.model_dump(mode="json") for s, q in quotes.items()}}
    else:
        strategy = service.strategies.get(args.strategy, args.version)
        results = service.screen(strategy, symbols=symbols, as_of=args.as_of)
        output = {"stats": service.last_scan_stats, "results": [r.model_dump(mode="json") for r in results]}
    text = json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
        print(f"Saved {args.output}")
    else:
        print(text)


if __name__ == "__main__":
    main()
